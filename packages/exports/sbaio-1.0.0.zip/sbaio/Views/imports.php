<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$preview = is_array($preview ?? null) ? $preview : null;
$history = is_array($history ?? null) ? $history : [];
$csrf = (string)($csrf ?? '');
$previewPayload = is_array($preview['preview'] ?? null) ? $preview['preview'] : [];
$salaryPreview = is_array($previewPayload['salary_preview'] ?? null) ? $previewPayload['salary_preview'] : [];
$fixedPreview = is_array($previewPayload['fixed_preview'] ?? null) ? $previewPayload['fixed_preview'] : [];
?>

<div class="card">
  <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
    <div>
      <h2 style="margin:0 0 6px">SBAIO Legacy Imports</h2>
      <div class="muted">Upload the legacy payroll workbook, validate the workbook-backed sheets, review row mapping, then commit the import. This is separate from setup and demo data.</div>
    </div>
    <a class="btn" href="/apps/sbaio">Back to SBAIO</a>
  </div>
</div>

<?php if (($flash_ok ?? '') !== ''): ?>
  <div class="card" style="border-color:rgba(0,200,120,.4);color:#7df0b0"><?= e((string)$flash_ok) ?></div>
<?php endif; ?>
<?php if (($flash_err ?? '') !== ''): ?>
  <div class="card" style="border-color:rgba(255,80,80,.45);color:#ffb3b3"><?= e((string)$flash_err) ?></div>
<?php endif; ?>

<div style="display:grid;gap:12px;grid-template-columns:minmax(280px,420px) minmax(320px,1fr)">
  <form method="post" action="/apps/sbaio/imports/preview" enctype="multipart/form-data" class="card" style="margin:0">
    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
    <h3 style="margin:0 0 8px">Workbook Upload</h3>
    <div class="muted" style="margin-bottom:10px">Start with the legacy `.xlsx` workbook. The preview checks salary monthly rates, fixed payroll profiles, staff mapping, duplicates, and sheet availability before anything is committed.</div>
    <label style="display:block;margin-bottom:10px">
      <div class="muted" style="margin-bottom:6px">Legacy workbook (.xlsx)</div>
      <input type="file" name="workbook" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" required>
    </label>
    <button class="btn ok" type="submit">Preview Workbook Import</button>
  </form>

  <div class="card" style="margin:0">
    <h3 style="margin:0 0 8px">What This Import Covers</h3>
    <div class="muted" style="margin-bottom:10px">Current workbook import scope is intentionally focused on payroll/timecard reference tables already backed by the legacy workbook.</div>
    <div style="display:grid;gap:8px;grid-template-columns:repeat(auto-fit,minmax(180px,1fr))">
      <div class="card" style="margin:0">
        <strong>Salary Monthly Rates</strong>
        <div class="muted">Imports workbook Salary-sheet month values into `sbaio_salary_monthly_rates`.</div>
      </div>
      <div class="card" style="margin:0">
        <strong>Fixed Payroll Profiles</strong>
        <div class="muted">Imports FulltimeRates values into `sbaio_payroll_fixed_profiles`.</div>
      </div>
      <div class="card" style="margin:0">
        <strong>Preview Checks</strong>
        <div class="muted">Valid rows, invalid rows, skipped blanks, duplicates, and unmapped NameRef rows.</div>
      </div>
    </div>
  </div>
</div>

<?php if (is_array($preview)): ?>
  <div class="card">
    <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
      <div>
        <h3 style="margin:0 0 8px">Preview Summary</h3>
        <div class="muted">Source file: <?= e((string)($preview['source_file'] ?? '')) ?><?= !empty($previewPayload['year']) ? ' · Salary year ' . e((string)$previewPayload['year']) : '' ?></div>
      </div>
      <form method="post" action="/apps/sbaio/imports/commit">
        <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
        <input type="hidden" name="preview_token" value="<?= e((string)($preview['preview_token'] ?? '')) ?>">
        <button class="btn ok" type="submit">Commit SBAIO Import</button>
      </form>
    </div>

    <div style="display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));margin-top:12px">
      <div class="card" style="margin:0"><strong>Valid Rows</strong><div class="muted"><?= e((string)($previewPayload['valid_rows'] ?? 0)) ?></div></div>
      <div class="card" style="margin:0"><strong>Invalid Rows</strong><div class="muted"><?= e((string)($previewPayload['invalid_rows'] ?? 0)) ?></div></div>
      <div class="card" style="margin:0"><strong>Skipped Rows</strong><div class="muted"><?= e((string)($previewPayload['skipped_rows'] ?? 0)) ?></div></div>
      <div class="card" style="margin:0"><strong>Duplicates</strong><div class="muted"><?= e((string)($previewPayload['duplicate_rows'] ?? 0)) ?></div></div>
    </div>

    <?php if (!empty($previewPayload['warnings'])): ?>
      <div class="muted" style="margin-top:10px;color:#ffcc8a"><?= e(implode(' ', array_map('strval', (array)$previewPayload['warnings']))) ?></div>
    <?php endif; ?>
  </div>

  <div style="display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(320px,1fr))">
    <div class="card" style="margin:0">
      <h3 style="margin:0 0 8px">Salary Monthly Rates Preview</h3>
      <div class="muted" style="margin-bottom:8px">Valid: <?= e((string)($salaryPreview['valid_rows'] ?? 0)) ?> · Invalid: <?= e((string)($salaryPreview['invalid_rows'] ?? 0)) ?> · Duplicates: <?= e((string)($salaryPreview['duplicate_rows'] ?? 0)) ?></div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Source</th>
              <th>NameRef</th>
              <th>Month</th>
              <th>Amount</th>
              <th>Issues</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ((array)($salaryPreview['sample_rows'] ?? []) as $row): ?>
              <tr>
                <td><?= e((string)($row['source_row'] ?? '')) ?></td>
                <td><?= e((string)($row['legacy_name_ref'] ?? '')) ?></td>
                <td><?= e((string)($row['period_month'] ?? '')) ?></td>
                <td><?= e((string)($row['reference_amount'] ?? '')) ?></td>
                <td><?= e(!empty($row['errors']) ? implode(' | ', array_map('strval', (array)$row['errors'])) : (!empty($row['duplicate']) ? 'Will update existing row' : 'Ready')) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card" style="margin:0">
      <h3 style="margin:0 0 8px">Fixed Payroll Profiles Preview</h3>
      <div class="muted" style="margin-bottom:8px">Valid: <?= e((string)($fixedPreview['valid_rows'] ?? 0)) ?> · Invalid: <?= e((string)($fixedPreview['invalid_rows'] ?? 0)) ?> · Duplicates: <?= e((string)($fixedPreview['duplicate_rows'] ?? 0)) ?></div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Source</th>
              <th>NameRef</th>
              <th>Basic Salary</th>
              <th>Net Pay</th>
              <th>Issues</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ((array)($fixedPreview['sample_rows'] ?? []) as $row): ?>
              <tr>
                <td><?= e((string)($row['source_column'] ?? '')) ?></td>
                <td><?= e((string)($row['legacy_name_ref'] ?? '')) ?></td>
                <td><?= e((string)($row['basic_salary_amount'] ?? '')) ?></td>
                <td><?= e((string)($row['net_pay_amount'] ?? '')) ?></td>
                <td><?= e(!empty($row['errors']) ? implode(' | ', array_map('strval', (array)$row['errors'])) : (!empty($row['duplicate']) ? 'Will update existing row' : 'Ready')) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php endif; ?>

<div class="card">
  <h3 style="margin:0 0 8px">Import History</h3>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>When</th>
          <th>Type</th>
          <th>Source</th>
          <th>Status</th>
          <th>Rows</th>
          <th>User</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($history as $run): ?>
          <tr>
            <td><?= e((string)($run['created_at'] ?? '')) ?></td>
            <td><?= e((string)($run['import_type'] ?? '')) ?></td>
            <td><?= e((string)($run['source_file'] ?? '')) ?></td>
            <td><?= e((string)($run['status'] ?? '')) ?></td>
            <td><?= e((string)($run['imported_rows'] ?? 0)) ?> imported / <?= e((string)($run['invalid_rows'] ?? 0)) ?> invalid / <?= e((string)($run['duplicate_rows'] ?? 0)) ?> duplicates</td>
            <td><?= e((string)($run['created_by'] ?? '')) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
