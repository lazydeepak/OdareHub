<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$suite = is_array($suite ?? null) ? $suite : [];
$modules = is_array($modules ?? null) ? $modules : [];
$history = is_array($history ?? null) ? $history : [];
$csrf = (string)($csrf ?? '');
?>

<div class="card">
  <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
    <div>
      <h2 style="margin:0 0 6px">SBAIO Exports</h2>
      <div class="muted">Create suite-level and module-level exports without mixing package/code export, business data export, and full backup snapshots.</div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <a class="btn" href="/apps/sbaio">Back to SBAIO</a>
      <a class="btn" href="/apps/sbaio/imports">Legacy Imports</a>
    </div>
  </div>
</div>

<?php if (($flash_ok ?? '') !== ''): ?>
  <div class="card" style="border-color:rgba(0,200,120,.4);color:#7df0b0"><?= e((string)$flash_ok) ?></div>
<?php endif; ?>
<?php if (($flash_err ?? '') !== ''): ?>
  <div class="card" style="border-color:rgba(255,80,80,.45);color:#ffb3b3"><?= e((string)$flash_err) ?></div>
<?php endif; ?>

<div class="card">
  <h3 style="margin:0 0 8px">Suite Export / Backup</h3>
  <div class="muted" style="margin-bottom:10px">SBAIO suite exports include the bundle metadata, installed child modules, and optional business data depending on the export type you choose.</div>
  <form method="post" action="/apps/sbaio/exports/suite" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end">
    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
    <label>
      <div class="muted" style="margin-bottom:6px">Export type</div>
      <select name="export_type">
        <?php foreach ((array)($suite['export_types'] ?? []) as $key => $label): ?>
          <option value="<?= e((string)$key) ?>"><?= e((string)$label) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <button class="btn ok" type="submit">Create Suite Export</button>
  </form>
</div>

<div class="card">
  <h3 style="margin:0 0 8px">Module Export / Backup</h3>
  <div class="muted" style="margin-bottom:10px">Export one module at a time when you only need a specific workflow area like Payroll, Timecards, or Attendance.</div>
  <div style="display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(260px,1fr))">
    <?php foreach ($modules as $module): ?>
      <form method="post" action="/apps/sbaio/exports/module" class="card" style="margin:0">
        <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
        <input type="hidden" name="module_name" value="<?= e((string)($module['module_name'] ?? '')) ?>">
        <strong><?= e((string)($module['display_name'] ?? '')) ?></strong>
        <div class="muted" style="margin:6px 0">Status: <?= e((string)($module['status'] ?? 'missing')) ?></div>
        <div class="muted" style="margin-bottom:10px">Tables: <?= e(implode(', ', array_map('strval', (array)($module['required_tables'] ?? [])))) ?></div>
        <label>
          <div class="muted" style="margin-bottom:6px">Export type</div>
          <select name="export_type">
            <?php foreach ((array)($module['export_types'] ?? []) as $key => $label): ?>
              <option value="<?= e((string)$key) ?>"><?= e((string)$label) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <button class="btn" type="submit" style="margin-top:10px">Create Module Export</button>
      </form>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <h3 style="margin:0 0 8px">Export History</h3>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>When</th>
          <th>Target</th>
          <th>Type</th>
          <th>Status</th>
          <th>File</th>
          <th>User</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($history as $row): ?>
          <tr>
            <td><?= e((string)($row['created_at'] ?? '')) ?></td>
            <td><?= e((string)($row['target_type'] ?? '')) ?>: <?= e((string)($row['target_key'] ?? '')) ?></td>
            <td><?= e((string)($row['export_type'] ?? '')) ?></td>
            <td><?= e((string)($row['status'] ?? '')) ?></td>
            <td>
              <?php if (!empty($row['file_name'])): ?>
                <a href="/apps/sbaio/exports/download?id=<?= (int)($row['id'] ?? 0) ?>"><?= e((string)($row['file_name'] ?? 'download')) ?></a>
              <?php else: ?>
                <span class="muted">n/a</span>
              <?php endif; ?>
            </td>
            <td><?= e((string)($row['created_by'] ?? '')) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
