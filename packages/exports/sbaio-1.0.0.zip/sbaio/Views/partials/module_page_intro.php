<?php
declare(strict_types=1);

$moduleTitle = trim((string)($moduleTitle ?? 'SBAIO'));
$moduleDescription = trim((string)($moduleDescription ?? ''));
$suiteActions = is_array($suiteActions ?? null) ? $suiteActions : [];
$suiteLinks = is_array($suiteLinks ?? null) ? $suiteLinks : [];
?>
<div class="section-head">
  <div>
    <h2 style="margin:0"><?= e($moduleTitle) ?></h2>
    <?php if ($moduleDescription !== ''): ?>
      <div class="muted" style="margin-top:6px"><?= e($moduleDescription) ?></div>
    <?php endif; ?>
  </div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <?php foreach ($suiteActions as $action): ?>
      <a class="btn" href="<?= e((string)($action['url'] ?? '/apps/sbaio')) ?>"><?= e((string)($action['label'] ?? '')) ?></a>
    <?php endforeach; ?>
  </div>
</div>
<?php if ($suiteLinks !== []): ?>
  <div class="row" style="gap:8px;flex-wrap:wrap;margin-top:10px">
    <?php foreach ($suiteLinks as $link): ?>
      <span class="pill"><?= e((string)($link['label'] ?? '')) ?><?php if (!empty($link['value'])): ?>: <?= e((string)$link['value']) ?><?php endif; ?></span>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
