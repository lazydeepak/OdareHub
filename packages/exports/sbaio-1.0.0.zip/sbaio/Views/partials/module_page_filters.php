<?php
declare(strict_types=1);

$moduleFilters = is_array($moduleFilters ?? null) ? $moduleFilters : [];
?>
<section class="card" style="margin-bottom:14px">
  <div class="section-head">
    <div>
      <h3 style="margin:0">Filters</h3>
      <div class="muted" style="margin-top:6px">Current scope and view context for this module page.</div>
    </div>
  </div>
  <?php if ($moduleFilters === []): ?>
    <div class="muted">No filters configured. Showing the default module view.</div>
  <?php else: ?>
    <div class="row" style="gap:8px;flex-wrap:wrap">
      <?php foreach ($moduleFilters as $filter): ?>
        <span class="pill">
          <?= e((string)($filter['label'] ?? 'Filter')) ?>
          <?php if (!empty($filter['value'])): ?>
            : <?= e((string)$filter['value']) ?>
          <?php endif; ?>
        </span>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>
