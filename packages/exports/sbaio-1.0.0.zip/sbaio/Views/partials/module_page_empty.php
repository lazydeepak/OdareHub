<?php
declare(strict_types=1);

$emptyTitle = trim((string)($emptyTitle ?? 'Nothing here yet'));
$emptyMessage = trim((string)($emptyMessage ?? ''));
?>
<section class="card">
  <h3 style="margin-top:0"><?= e($emptyTitle) ?></h3>
  <div class="muted"><?= e($emptyMessage) ?></div>
</section>
