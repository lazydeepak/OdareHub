<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$attendanceSeries = is_array($attendanceSeries ?? null) ? $attendanceSeries : [];
$timecardSeries = is_array($timecardSeries ?? null) ? $timecardSeries : [];
$payrollSeries = is_array($payrollSeries ?? null) ? $payrollSeries : [];
$needsAttention = is_array($needsAttention ?? null) ? $needsAttention : [];
$suiteActions = [
  ['label' => t('nav.sbaio_dashboard'), 'url' => '/apps/sbaio'],
  ['label' => t('nav.sbaio_payroll_parity'), 'url' => '/apps/sbaio/payroll/parity'],
];
$suiteLinks = [
  ['label' => 'Attendance Months', 'value' => (string)count($attendanceSeries)],
  ['label' => 'Timecard Months', 'value' => (string)count($timecardSeries)],
  ['label' => 'Payroll Months', 'value' => (string)count($payrollSeries)],
];
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_intro.php';

$chartMax = static function(array $rows, string $key): float {
  $max = 0.0;
  foreach ($rows as $row) {
    $max = max($max, (float)($row[$key] ?? 0));
  }
  return $max > 0 ? $max : 1.0;
};

$renderBars = function(array $rows, string $labelKey, string $valueKey, string $barColor = '#5aa9ff', ?string $secondaryKey = null, string $secondaryColor = '#9b8cff') use ($chartMax): void {
  $max = $chartMax($rows, $valueKey);
  $secondaryMax = $secondaryKey !== null ? $chartMax($rows, $secondaryKey) : 1.0;
  ?>
  <div style="display:grid;gap:10px">
    <?php foreach ($rows as $row): ?>
      <?php
        $label = (string)($row[$labelKey] ?? '');
        $primary = (float)($row[$valueKey] ?? 0);
        $secondary = $secondaryKey !== null ? (float)($row[$secondaryKey] ?? 0) : null;
      ?>
      <div>
        <div class="row" style="justify-content:space-between;gap:8px">
          <strong><?= e($label) ?></strong>
          <span class="muted"><?= e(number_format($primary, 2, '.', ',')) ?><?php if ($secondary !== null): ?> · <?= e(number_format($secondary, 2, '.', ',')) ?><?php endif; ?></span>
        </div>
        <div style="margin-top:6px;height:10px;background:rgba(255,255,255,.06);border-radius:999px;overflow:hidden">
          <div style="height:10px;width:<?= e((string)max(4.0, ($primary / $max) * 100.0)) ?>%;background:<?= e($barColor) ?>;border-radius:999px"></div>
        </div>
        <?php if ($secondary !== null): ?>
          <div style="margin-top:4px;height:6px;background:rgba(255,255,255,.04);border-radius:999px;overflow:hidden">
            <div style="height:6px;width:<?= e((string)max(4.0, ($secondary / $secondaryMax) * 100.0)) ?>%;background:<?= e($secondaryColor) ?>;border-radius:999px"></div>
          </div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
  <?php
};
?>

<section class="card">
  <div class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:12px">
    <?php foreach ($needsAttention as $item): ?>
      <a class="dashboard-link-card" href="<?= e((string)($item['url'] ?? '/apps/sbaio')) ?>">
        <div class="dashboard-link-top">
          <strong><?= e((string)($item['label'] ?? '')) ?></strong>
        </div>
        <div class="hero-meta-value"><?= e((string)($item['value'] ?? '0')) ?></div>
      </a>
    <?php endforeach; ?>
  </div>
</section>

<section class="card">
  <div class="section-head">
    <div>
      <h3 style="margin:0">Attendance Quality</h3>
      <div class="muted" style="margin-top:6px">Monthly attendance volume and missing-punch signal.</div>
    </div>
  </div>
  <?php if ($attendanceSeries === []): ?>
    <div class="muted">No attendance report data yet.</div>
  <?php else: ?>
    <?php $renderBars($attendanceSeries, 'ym', 'rows_count', '#44c4a1', 'missing_count', '#ff9b6b'); ?>
  <?php endif; ?>
</section>

<section class="card">
  <div class="section-head">
    <div>
      <h3 style="margin:0">Timecard Throughput</h3>
      <div class="muted" style="margin-top:6px">Monthly worked minutes and overtime minutes from generated periods.</div>
    </div>
  </div>
  <?php if ($timecardSeries === []): ?>
    <div class="muted">No timecard report data yet.</div>
  <?php else: ?>
    <?php $renderBars($timecardSeries, 'ym', 'worked_minutes', '#5aa9ff', 'overtime_minutes', '#ffd166'); ?>
  <?php endif; ?>
</section>

<section class="card">
  <div class="section-head">
    <div>
      <h3 style="margin:0">Payroll Totals</h3>
      <div class="muted" style="margin-top:6px">Monthly gross and net totals from generated payroll records.</div>
    </div>
  </div>
  <?php if ($payrollSeries === []): ?>
    <div class="muted">No payroll report data yet.</div>
  <?php else: ?>
    <?php $renderBars($payrollSeries, 'ym', 'gross_total', '#9b8cff', 'net_total', '#44c4a1'); ?>
  <?php endif; ?>
</section>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
