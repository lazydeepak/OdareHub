<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$suiteRoleTemplateLabels = is_array($suite_role_template_labels ?? null) ? $suite_role_template_labels : [];
$modulePermissionTemplateLabels = is_array($module_permission_template_labels ?? null) ? $module_permission_template_labels : [];
?>

<section class="card">
  <div class="section-head">
    <div>
      <h2 style="margin:0"><?= e(t('nav.sbaio_dashboard')) ?></h2>
      <div class="muted" style="margin-top:6px">Small-business operations suite for staff, attendance, scheduling, timecards, payroll, and workbook-backed payroll parity.</div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <a class="btn" href="/apps/sbaio/imports">Legacy Imports</a>
      <a class="btn" href="/apps/sbaio/exports">Exports</a>
      <a class="btn" href="/apps/sbaio/restores">Restores</a>
    </div>
  </div>

  <?php if (!empty($heroStats)): ?>
    <div class="hero-meta" style="margin-top:12px">
      <?php foreach ((array)$heroStats as $stat): ?>
        <div class="hero-meta-card">
          <div class="muted"><?= e((string)($stat['label'] ?? '')) ?></div>
          <div class="hero-meta-value"><?= e((string)($stat['value'] ?? '0')) ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
  <?php if ($suiteRoleTemplateLabels !== [] || $modulePermissionTemplateLabels !== []): ?>
    <div class="row" style="gap:6px;flex-wrap:wrap;margin-top:12px">
      <?php foreach ($suiteRoleTemplateLabels as $label): ?>
        <span class="pill"><?= e((string)$label) ?></span>
      <?php endforeach; ?>
      <?php foreach ($modulePermissionTemplateLabels as $label): ?>
        <span class="pill"><?= e((string)$label) ?></span>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>

<?php foreach ((array)($sections ?? []) as $section): ?>
  <section class="card">
    <div class="section-head">
      <div>
        <h3 style="margin:0"><?= e((string)($section['title'] ?? 'SBAIO')) ?></h3>
        <?php if (!empty($section['subtitle'])): ?>
          <div class="muted" style="margin-top:6px"><?= e((string)$section['subtitle']) ?></div>
        <?php endif; ?>
      </div>
    </div>

    <div class="app-quicklink-row" style="align-items:stretch">
      <?php foreach ((array)($section['cards'] ?? []) as $card): ?>
        <?php $quickLinks = is_array($card['quick_links'] ?? null) ? (array)$card['quick_links'] : []; ?>
        <div class="app-quicklink-card" style="display:flex;flex-direction:column;gap:10px">
          <a href="<?= e((string)($card['url'] ?? '/apps/sbaio')) ?>" style="text-decoration:none;color:inherit">
            <span class="app-quicklink-label"><?= e((string)($card['label'] ?? '')) ?></span>
            <span class="app-quicklink-sub muted"><?= e((string)($card['desc'] ?? '')) ?></span>
          </a>
          <div style="display:flex;align-items:flex-end;justify-content:space-between;gap:10px">
            <div>
              <div class="muted" style="font-size:.78em;text-transform:uppercase;letter-spacing:.08em">Count</div>
              <div style="font-size:1.6rem;font-weight:700;line-height:1"><?= e((string)($card['count'] ?? '0')) ?></div>
            </div>
            <?php if (!empty($card['state'])): ?>
              <span class="pill"><?= e((string)$card['state']) ?></span>
            <?php endif; ?>
          </div>
          <?php if ($quickLinks !== []): ?>
            <div style="display:flex;flex-wrap:wrap;gap:8px">
              <?php foreach ($quickLinks as $link): ?>
                <a class="btn" href="<?= e((string)($link['url'] ?? ($card['url'] ?? '/apps/sbaio'))) ?>" style="padding:6px 10px">
                  <?= e((string)($link['label'] ?? 'Open')) ?>
                </a>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  </section>
<?php endforeach; ?>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
