<?php
declare(strict_types=1);

namespace SBAIO\Controllers;

use App\Core\Auth;
use App\Core\DB;
use Plugins\Base\Services\UserDashboardAssignmentService;

final class SbaioDashboardController
{
    public static function index($view): void
    {
        $ctx = UserDashboardAssignmentService::resolveUserContext(Auth::user());
        $moduleVisibility = array_values(array_map('strval', (array)($ctx['module_visibility'] ?? [])));
        $suiteRoleLabels = array_values(array_map('strval', (array)($ctx['suite_role_template_labels'] ?? [])));
        $moduleTemplateLabels = array_values(array_map('strval', (array)($ctx['module_permission_template_labels'] ?? [])));

        $leaveRequests = self::count('sbaio_leave_requests');
        $holidayEntries = self::count('sbaio_holiday_calendar');
        $counts = [
            'staff' => self::count('sbaio_staff'),
            'attendance' => self::count('sbaio_attendance_daily'),
            'schedules' => self::count('sbaio_schedule_assignments'),
            'timecards_periods' => self::count('sbaio_timecard_periods'),
            'payroll_runs' => self::count('sbaio_payroll_runs'),
            'payroll_records' => self::count('sbaio_payroll_records'),
            'customers' => self::count('sbaio_customers'),
            'tasks' => self::count('sbaio_tasks'),
            'sales' => self::count('sbaio_sales'),
            'expenses' => self::count('sbaio_expenses'),
            'notices' => self::count('sbaio_notices'),
            'salary_rates' => self::count('sbaio_salary_monthly_rates'),
            'fixed_profiles' => self::count('sbaio_payroll_fixed_profiles'),
            'leave_requests' => $leaveRequests,
            'holiday_entries' => $holidayEntries,
        ];

        $draftTimecards = self::countWhere(
            'sbaio_timecard_periods',
            "LOWER(COALESCE(approval_status, 'draft')) IN ('draft','generated','pending')"
        );
        $draftPayroll = self::countWhere(
            'sbaio_payroll_runs',
            "LOWER(COALESCE(run_status, 'draft')) IN ('draft','generated','pending')"
        );
        $pendingLeave = self::countWhere(
            'sbaio_leave_requests',
            "LOWER(COALESCE(leave_status, 'draft')) IN ('draft','pending','submitted')"
        );
        $missingPunches = self::countWhere(
            'sbaio_attendance_daily',
            "(work_start_at IS NULL OR work_end_at IS NULL) AND LOWER(COALESCE(day_marker, 'workday')) NOT IN ('holiday','leave','off_day','closed')"
        );

        $sections = [
            [
                'title' => 'People & Time',
                'subtitle' => 'Core workforce records and daily time inputs that feed the rest of the suite.',
                'module_keys' => ['sbaio_staff', 'sbaio_schedules', 'sbaio_attendance', 'sbaio_leave', 'sbaio_timecards'],
                'cards' => [
                    [
                        'label' => 'Staff',
                        'module_key' => 'sbaio_staff',
                        'url' => '/apps/sbaio/staff',
                        'desc' => 'Staff master records with employment and payroll references.',
                        'count' => $counts['staff'],
                        'state' => $counts['staff'] > 0 ? 'Live' : 'Ready',
                        'quick_links' => [
                            ['label' => 'Open Staff', 'url' => '/apps/sbaio/staff'],
                        ],
                    ],
                    [
                        'label' => 'Schedules',
                        'module_key' => 'sbaio_schedules',
                        'url' => '/apps/sbaio/schedules',
                        'desc' => 'Shift templates and assignment coverage for working days.',
                        'count' => $counts['schedules'],
                        'state' => $counts['schedules'] > 0 ? 'Assigned' : 'Ready',
                        'quick_links' => [
                            ['label' => 'Open Schedules', 'url' => '/apps/sbaio/schedules'],
                            ['label' => 'Open Staff', 'url' => '/apps/sbaio/staff'],
                        ],
                    ],
                    [
                        'label' => 'Attendance',
                        'module_key' => 'sbaio_attendance',
                        'url' => '/apps/sbaio/attendance',
                        'desc' => 'Raw daily punches, breaks, and day markers.',
                        'count' => $counts['attendance'],
                        'state' => $missingPunches > 0 ? $missingPunches . ' Missing' : 'Clean',
                        'quick_links' => [
                            ['label' => 'Open Attendance', 'url' => '/apps/sbaio/attendance'],
                            ['label' => 'Open Timecards', 'url' => '/apps/sbaio/timecards'],
                        ],
                    ],
                    [
                        'label' => 'Leave',
                        'module_key' => 'sbaio_leave',
                        'url' => '/apps/sbaio/leave',
                        'desc' => 'Leave requests and holiday calendar entries that affect time generation.',
                        'count' => $counts['leave_requests'] + $counts['holiday_entries'],
                        'state' => $pendingLeave > 0 ? $pendingLeave . ' Pending' : 'Current',
                        'quick_links' => [
                            ['label' => 'Open Leave', 'url' => '/apps/sbaio/leave'],
                            ['label' => 'Open Schedules', 'url' => '/apps/sbaio/schedules'],
                        ],
                    ],
                    [
                        'label' => 'Timecards',
                        'module_key' => 'sbaio_timecards',
                        'url' => '/apps/sbaio/timecards',
                        'desc' => 'Derived daily rows and period-level summaries for review.',
                        'count' => $counts['timecards_periods'],
                        'state' => $draftTimecards > 0 ? $draftTimecards . ' Draft' : 'Current',
                        'quick_links' => [
                            ['label' => 'Open Timecards', 'url' => '/apps/sbaio/timecards'],
                            ['label' => 'Open Attendance', 'url' => '/apps/sbaio/attendance'],
                        ],
                    ],
                ],
            ],
            [
                'title' => 'Pay & Review',
                'subtitle' => 'Payroll construction, parity validation, and salary-reference review surfaces.',
                'module_keys' => ['sbaio_payroll', 'sbaio_timecards'],
                'cards' => [
                    [
                        'label' => 'Payroll Runs',
                        'module_key' => 'sbaio_payroll',
                        'url' => '/apps/sbaio/payroll',
                        'desc' => 'Scaffolded payroll runs built from approved timecard periods.',
                        'count' => $counts['payroll_runs'],
                        'state' => $draftPayroll > 0 ? $draftPayroll . ' Draft' : 'Current',
                        'quick_links' => [
                            ['label' => 'Open Payroll', 'url' => '/apps/sbaio/payroll'],
                            ['label' => 'Payroll Parity', 'url' => '/apps/sbaio/payroll/parity'],
                        ],
                    ],
                    [
                        'label' => 'Payroll Records',
                        'module_key' => 'sbaio_payroll',
                        'url' => '/apps/sbaio/payroll',
                        'desc' => 'Generated employee payroll rows and output totals.',
                        'count' => $counts['payroll_records'],
                        'state' => $counts['payroll_records'] > 0 ? 'Generated' : 'Waiting',
                        'quick_links' => [
                            ['label' => 'Open Payroll', 'url' => '/apps/sbaio/payroll'],
                        ],
                    ],
                    [
                        'label' => 'Payroll Parity',
                        'module_key' => 'sbaio_payroll',
                        'url' => '/apps/sbaio/payroll/parity',
                        'desc' => 'Workbook-backed comparison surface for generated payroll output.',
                        'count' => $counts['payroll_records'],
                        'state' => 'Review',
                        'quick_links' => [
                            ['label' => 'Open Parity', 'url' => '/apps/sbaio/payroll/parity'],
                            ['label' => 'Open Payroll', 'url' => '/apps/sbaio/payroll'],
                        ],
                    ],
                    [
                        'label' => 'Salary References',
                        'module_key' => 'sbaio_payroll',
                        'url' => '/apps/sbaio/payroll',
                        'desc' => 'Imported monthly salary reference rows from the legacy workbook.',
                        'count' => $counts['salary_rates'],
                        'state' => $counts['salary_rates'] > 0 ? 'Imported' : 'Empty',
                        'quick_links' => [
                            ['label' => 'Open Payroll', 'url' => '/apps/sbaio/payroll'],
                        ],
                    ],
                    [
                        'label' => 'Fixed Profiles',
                        'module_key' => 'sbaio_payroll',
                        'url' => '/apps/sbaio/payroll',
                        'desc' => 'Fixed-pay profile rows used during payroll parity and scaffold logic.',
                        'count' => $counts['fixed_profiles'],
                        'state' => $counts['fixed_profiles'] > 0 ? 'Imported' : 'Empty',
                        'quick_links' => [
                            ['label' => 'Open Payroll', 'url' => '/apps/sbaio/payroll'],
                            ['label' => 'Open Parity', 'url' => '/apps/sbaio/payroll/parity'],
                        ],
                    ],
                ],
            ],
            [
                'title' => 'Business Ops',
                'subtitle' => 'Customer-facing and internal support modules that live alongside the people/payroll stack.',
                'module_keys' => ['sbaio_customers', 'sbaio_tasks', 'sbaio_sales', 'sbaio_expenses', 'sbaio_notices'],
                'cards' => [
                    [
                        'label' => 'Customers',
                        'module_key' => 'sbaio_customers',
                        'url' => '/apps/sbaio/customers',
                        'desc' => 'Customer records and relationship tracking.',
                        'count' => $counts['customers'],
                        'state' => $counts['customers'] > 0 ? 'Live' : 'Ready',
                        'quick_links' => [
                            ['label' => 'Open Customers', 'url' => '/apps/sbaio/customers'],
                        ],
                    ],
                    [
                        'label' => 'Sales',
                        'module_key' => 'sbaio_sales',
                        'url' => '/apps/sbaio/sales',
                        'desc' => 'Sales-side records and suite-level commercial operations.',
                        'count' => $counts['sales'],
                        'state' => $counts['sales'] > 0 ? 'Live' : 'Ready',
                        'quick_links' => [
                            ['label' => 'Open Sales', 'url' => '/apps/sbaio/sales'],
                            ['label' => 'Open Customers', 'url' => '/apps/sbaio/customers'],
                        ],
                    ],
                    [
                        'label' => 'Expenses',
                        'module_key' => 'sbaio_expenses',
                        'url' => '/apps/sbaio/expenses',
                        'desc' => 'Expense capture and review workflow.',
                        'count' => $counts['expenses'],
                        'state' => $counts['expenses'] > 0 ? 'Live' : 'Ready',
                        'quick_links' => [
                            ['label' => 'Open Expenses', 'url' => '/apps/sbaio/expenses'],
                        ],
                    ],
                    [
                        'label' => 'Tasks',
                        'module_key' => 'sbaio_tasks',
                        'url' => '/apps/sbaio/tasks',
                        'desc' => 'Follow-up work and operational task tracking.',
                        'count' => $counts['tasks'],
                        'state' => $counts['tasks'] > 0 ? 'Active' : 'Ready',
                        'quick_links' => [
                            ['label' => 'Open Tasks', 'url' => '/apps/sbaio/tasks'],
                            ['label' => 'Open Notices', 'url' => '/apps/sbaio/notices'],
                        ],
                    ],
                    [
                        'label' => 'Notices',
                        'module_key' => 'sbaio_notices',
                        'url' => '/apps/sbaio/notices',
                        'desc' => 'Shared reminders, announcements, and review notes.',
                        'count' => $counts['notices'],
                        'state' => $counts['notices'] > 0 ? 'Active' : 'Ready',
                        'quick_links' => [
                            ['label' => 'Open Notices', 'url' => '/apps/sbaio/notices'],
                            ['label' => 'Open Tasks', 'url' => '/apps/sbaio/tasks'],
                        ],
                    ],
                ],
            ],
            [
                'title' => 'Needs Attention',
                'subtitle' => 'App-level operational hotspots and review queues. This stays summary-only so it does not duplicate `/me`.',
                'module_keys' => ['sbaio_attendance', 'sbaio_timecards', 'sbaio_payroll', 'sbaio_leave'],
                'cards' => [
                    [
                        'label' => 'Missing Punches',
                        'module_key' => 'sbaio_attendance',
                        'url' => '/apps/sbaio/attendance',
                        'desc' => 'Attendance rows missing a start or end time on active workdays.',
                        'count' => $missingPunches,
                        'state' => $missingPunches > 0 ? 'Review' : 'Clear',
                        'quick_links' => [
                            ['label' => 'Fix Attendance', 'url' => '/apps/sbaio/attendance'],
                        ],
                    ],
                    [
                        'label' => 'Draft Timecards',
                        'module_key' => 'sbaio_timecards',
                        'url' => '/apps/sbaio/timecards',
                        'desc' => 'Generated periods still waiting for review or approval.',
                        'count' => $draftTimecards,
                        'state' => $draftTimecards > 0 ? 'Needs Review' : 'Clear',
                        'quick_links' => [
                            ['label' => 'Review Timecards', 'url' => '/apps/sbaio/timecards'],
                        ],
                    ],
                    [
                        'label' => 'Draft Payroll',
                        'module_key' => 'sbaio_payroll',
                        'url' => '/apps/sbaio/payroll',
                        'desc' => 'Payroll runs scaffolded but not yet finalized or reviewed.',
                        'count' => $draftPayroll,
                        'state' => $draftPayroll > 0 ? 'Needs Review' : 'Clear',
                        'quick_links' => [
                            ['label' => 'Review Payroll', 'url' => '/apps/sbaio/payroll'],
                            ['label' => 'Open Parity', 'url' => '/apps/sbaio/payroll/parity'],
                        ],
                    ],
                    [
                        'label' => 'Pending Leave',
                        'module_key' => 'sbaio_leave',
                        'url' => '/apps/sbaio/leave',
                        'desc' => 'Leave requests still in draft, submitted, or pending status.',
                        'count' => $pendingLeave,
                        'state' => $pendingLeave > 0 ? 'Needs Review' : 'Clear',
                        'quick_links' => [
                            ['label' => 'Review Leave', 'url' => '/apps/sbaio/leave'],
                        ],
                    ],
                ],
            ],
        ];

        if ($moduleVisibility !== []) {
            $sections = array_values(array_filter(array_map(static function (array $section) use ($moduleVisibility): array {
                $cards = array_values(array_filter((array)($section['cards'] ?? []), static function (array $card) use ($moduleVisibility): bool {
                    $moduleKey = (string)($card['module_key'] ?? '');
                    return $moduleKey === '' || in_array($moduleKey, $moduleVisibility, true);
                }));
                $section['cards'] = $cards;
                return $section;
            }, $sections), static fn(array $section): bool => (array)($section['cards'] ?? []) !== []));
        }

        $view->render('sbaio::dashboard.php', [
            'pageTitle' => 'SBAIO',
            'heroStats' => [
                ['label' => 'Staff', 'value' => $counts['staff']],
                ['label' => 'Missing Punches', 'value' => $missingPunches],
                ['label' => 'Draft Timecards', 'value' => $draftTimecards],
                ['label' => 'Draft Payroll', 'value' => $draftPayroll],
            ],
            'sections' => $sections,
            'suite_role_template_labels' => $suiteRoleLabels,
            'module_permission_template_labels' => $moduleTemplateLabels,
        ]);
    }

    public static function reports($view): void
    {
        $attendance = DB::fetchAll(
            "SELECT DATE_FORMAT(attendance_date, '%Y-%m') AS ym,
                    COUNT(*) AS rows_count,
                    SUM(CASE WHEN work_start_at IS NULL OR work_end_at IS NULL THEN 1 ELSE 0 END) AS missing_count
             FROM sbaio_attendance_daily
             GROUP BY DATE_FORMAT(attendance_date, '%Y-%m')
             ORDER BY ym DESC
             LIMIT 12"
        );

        $timecards = DB::fetchAll(
            "SELECT DATE_FORMAT(period_start, '%Y-%m') AS ym,
                    COUNT(*) AS periods,
                    SUM(total_worked_minutes) AS worked_minutes,
                    SUM(overtime_minutes) AS overtime_minutes
             FROM sbaio_timecard_periods
             GROUP BY DATE_FORMAT(period_start, '%Y-%m')
             ORDER BY ym DESC
             LIMIT 12"
        );

        $payroll = DB::fetchAll(
            "SELECT DATE_FORMAT(r.period_start, '%Y-%m') AS ym,
                    COUNT(pr.id) AS records,
                    SUM(pr.gross_amount) AS gross_total,
                    SUM(pr.net_amount) AS net_total
             FROM sbaio_payroll_runs r
             LEFT JOIN sbaio_payroll_records pr ON pr.payroll_run_id = r.id
             GROUP BY DATE_FORMAT(r.period_start, '%Y-%m')
             ORDER BY ym DESC
             LIMIT 12"
        );

        $needsAttention = [
            ['label' => 'Missing Punches', 'value' => self::countWhere('sbaio_attendance_daily', "(work_start_at IS NULL OR work_end_at IS NULL) AND LOWER(COALESCE(day_marker, 'workday')) NOT IN ('holiday','leave','off_day','closed')"), 'url' => '/apps/sbaio/attendance'],
            ['label' => 'Draft Timecards', 'value' => self::countWhere('sbaio_timecard_periods', "LOWER(COALESCE(approval_status, 'draft')) IN ('draft','generated','pending')"), 'url' => '/apps/sbaio/timecards'],
            ['label' => 'Draft Payroll', 'value' => self::countWhere('sbaio_payroll_runs', "LOWER(COALESCE(run_status, 'draft')) IN ('draft','generated','pending')"), 'url' => '/apps/sbaio/payroll'],
            ['label' => 'Pending Leave', 'value' => self::countWhere('sbaio_leave_requests', "LOWER(COALESCE(leave_status, 'draft')) IN ('draft','pending','submitted')"), 'url' => '/apps/sbaio/leave'],
        ];

        $view->render('sbaio::reports.php', [
            'pageTitle' => 'SBAIO Reports',
            'moduleTitle' => 'SBAIO Reports',
            'moduleDescription' => 'Operational reporting surface for attendance quality, timecard throughput, payroll totals, and suite attention signals.',
            'attendanceSeries' => array_reverse($attendance),
            'timecardSeries' => array_reverse($timecards),
            'payrollSeries' => array_reverse($payroll),
            'needsAttention' => $needsAttention,
        ]);
    }

    private static function count(string $table): int
    {
        if (!self::tableExists($table)) {
            return 0;
        }
        $row = DB::fetchOne("SELECT COUNT(*) AS total FROM {$table}");
        return (int)($row['total'] ?? 0);
    }

    private static function countWhere(string $table, string $where): int
    {
        if (!self::tableExists($table)) {
            return 0;
        }
        $row = DB::fetchOne("SELECT COUNT(*) AS total FROM {$table} WHERE {$where}");
        return (int)($row['total'] ?? 0);
    }

    private static function tableExists(string $table): bool
    {
        try {
            return DB::fetchOne(
                'SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? LIMIT 1',
                [$table]
            ) !== null;
        } catch (\Throwable $e) {
            return false;
        }
    }
}
