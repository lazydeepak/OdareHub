<?php
declare(strict_types=1);

namespace Apps\SBAIO\Services;

use App\Core\DB;

final class HostSurfaceContributionService
{
    /**
     * @param array<string,mixed> $request
     * @return array<string,mixed>|array<int,array<string,mixed>>
     */
    public static function contribute(array $request): array
    {
        $surface = trim((string)($request['surface'] ?? ''));
        $region = trim((string)($request['region'] ?? ''));
        if (!self::isVisibleForRequest($request)) {
            return [];
        }

        return match ($surface . ':' . $region) {
            'me:header_actions' => self::meHeaderActions(),
            'me:summary_cards' => self::meSummaryCards(),
            'me:quick_links' => self::meQuickLinks(),
            'me:monitoring_sections' => self::meMonitoringSections(),
            default => [],
        };
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function meHeaderActions(): array
    {
        return [
            [
                'label' => t('nav.sbaio_dashboard'),
                'url' => '/apps/sbaio',
                'weight' => 50,
            ],
        ];
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function meSummaryCards(): array
    {
        $missingPunches = self::missingPunchEntries(3);
        $draftPeriods = self::draftPeriodEntries(3);
        $draftPayrollRuns = self::draftPayrollEntries(3);
        $pendingLeave = self::pendingLeaveEntries(3);

        return [
            [
                'title' => t('sbaio.host.missing_punches'),
                'value' => self::missingPunchCount(),
                'meta' => t('sbaio.host.attendance_attention'),
                'url' => '/apps/sbaio/attendance',
                'tone' => self::missingPunchCount() > 0 ? 'warn' : 'info',
                'entries' => $missingPunches,
                'weight' => 50,
            ],
            [
                'title' => t('sbaio.host.draft_timecards'),
                'value' => self::draftTimecardCount(),
                'meta' => t('sbaio.host.timecards_attention'),
                'url' => '/apps/sbaio/timecards',
                'tone' => self::draftTimecardCount() > 0 ? 'warn' : 'info',
                'entries' => $draftPeriods,
                'weight' => 51,
            ],
            [
                'title' => t('sbaio.host.draft_payroll'),
                'value' => self::draftPayrollCount(),
                'meta' => t('sbaio.host.payroll_attention'),
                'url' => '/apps/sbaio/payroll',
                'tone' => self::draftPayrollCount() > 0 ? 'warn' : 'info',
                'entries' => $draftPayrollRuns,
                'weight' => 52,
            ],
            [
                'title' => t('sbaio.host.pending_leave'),
                'value' => self::pendingLeaveCount(),
                'meta' => t('sbaio.host.leave_attention'),
                'url' => '/apps/sbaio/leave',
                'tone' => self::pendingLeaveCount() > 0 ? 'warn' : 'info',
                'entries' => $pendingLeave,
                'weight' => 53,
            ],
        ];
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function meQuickLinks(): array
    {
        return [
            [
                'label' => t('nav.sbaio_staff'),
                'url' => '/apps/sbaio/staff',
                'description' => t('sbaio.host.staff_meta'),
                'weight' => 50,
            ],
            [
                'label' => t('nav.sbaio_attendance'),
                'url' => '/apps/sbaio/attendance',
                'description' => t('sbaio.host.attendance_attention'),
                'weight' => 51,
            ],
            [
                'label' => t('nav.sbaio_timecards'),
                'url' => '/apps/sbaio/timecards',
                'description' => t('sbaio.host.timecards_attention'),
                'weight' => 52,
            ],
            [
                'label' => t('nav.sbaio_payroll'),
                'url' => '/apps/sbaio/payroll',
                'description' => t('sbaio.host.payroll_attention'),
                'weight' => 53,
            ],
            [
                'label' => t('nav.sbaio_leave'),
                'url' => '/apps/sbaio/leave',
                'description' => t('sbaio.host.leave_attention'),
                'weight' => 54,
            ],
            [
                'label' => t('sbaio.host.parity_validation'),
                'url' => '/apps/sbaio/payroll/parity',
                'description' => t('sbaio.host.parity_meta'),
                'weight' => 55,
            ],
        ];
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function meMonitoringSections(): array
    {
        return [
            [
                'title' => t('sbaio.host.monitoring_title'),
                'kind' => 'table',
                'columns' => [
                    t('common.type'),
                    t('common.item'),
                    t('common.status'),
                    t('common.actions'),
                ],
                'rows' => self::monitoringRows(),
                'empty_message' => t('sbaio.host.monitoring_empty'),
                'weight' => 60,
            ],
        ];
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function monitoringRows(): array
    {
        $rows = [];

        if (self::missingPunchCount() > 0) {
            $rows[] = [
                'cells' => [
                    t('nav.sbaio_attendance'),
                    t('sbaio.host.missing_punches'),
                    (string)self::missingPunchCount(),
                ],
                'url' => '/apps/sbaio/attendance',
                'url_label' => t('common.open'),
            ];
        }

        foreach (self::draftPeriods(3) as $period) {
            $rows[] = [
                'cells' => [
                    t('nav.sbaio_timecards'),
                    trim((string)($period['period_key'] ?? '')),
                    ucfirst(trim((string)($period['approval_status'] ?? 'draft'))),
                ],
                'url' => '/apps/sbaio/timecards',
                'url_label' => t('common.open'),
            ];
        }

        foreach (self::draftPayrollRuns(3) as $run) {
            $label = trim((string)($run['period_month_label'] ?? ''));
            if ($label === '') {
                $year = (string)($run['period_year'] ?? '');
                $month = (string)($run['period_month'] ?? '');
                $label = trim($year . '-' . str_pad($month, 2, '0', STR_PAD_LEFT), '-');
            }

            $rows[] = [
                'cells' => [
                    t('nav.sbaio_payroll'),
                    $label !== '' ? $label : trim((string)($run['period_key'] ?? '')),
                    ucfirst(trim((string)($run['run_status'] ?? 'draft'))),
                ],
                'url' => '/apps/sbaio/payroll',
                'url_label' => t('common.open'),
            ];
        }

        if (self::pendingLeaveCount() > 0) {
            $rows[] = [
                'cells' => [
                    t('nav.sbaio_leave'),
                    t('sbaio.host.pending_leave'),
                    (string)self::pendingLeaveCount(),
                ],
                'url' => '/apps/sbaio/leave',
                'url_label' => t('common.open'),
            ];
        }

        if ($rows === [] && self::activeNoticesCount() > 0) {
            $rows[] = [
                'cells' => [
                    t('nav.sbaio_notices'),
                    t('sbaio.host.active_notices'),
                    (string)self::activeNoticesCount(),
                ],
                'url' => '/apps/sbaio/notices',
                'url_label' => t('common.open'),
            ];
        }

        return $rows;
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function draftPeriods(int $limit): array
    {
        if (!self::tableExists('sbaio_timecard_periods')) {
            return [];
        }

        return DB::fetchAll(
            "SELECT period_key, approval_status
             FROM sbaio_timecard_periods
             WHERE LOWER(COALESCE(approval_status, 'draft')) IN ('draft','generated','pending')
             ORDER BY period_start DESC
             LIMIT " . (int)$limit
        );
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function draftPayrollRuns(int $limit): array
    {
        if (!self::tableExists('sbaio_payroll_runs')) {
            return [];
        }

        return DB::fetchAll(
            "SELECT period_key, period_year, period_month, period_month_label, run_status
             FROM sbaio_payroll_runs
             WHERE LOWER(COALESCE(run_status, 'draft')) IN ('draft','generated','pending')
             ORDER BY period_start DESC
             LIMIT " . (int)$limit
        );
    }

    private static function countTable(string $table): int
    {
        if (!self::tableExists($table)) {
            return 0;
        }

        $row = DB::fetchOne("SELECT COUNT(*) AS total FROM {$table}");
        return (int)($row['total'] ?? 0);
    }

    private static function draftTimecardCount(): int
    {
        if (!self::tableExists('sbaio_timecard_periods')) {
            return 0;
        }

        $row = DB::fetchOne(
            "SELECT COUNT(*) AS total
             FROM sbaio_timecard_periods
             WHERE LOWER(COALESCE(approval_status, 'draft')) IN ('draft','generated','pending')"
        );

        return (int)($row['total'] ?? 0);
    }

    private static function draftPayrollCount(): int
    {
        if (!self::tableExists('sbaio_payroll_runs')) {
            return 0;
        }

        $row = DB::fetchOne(
            "SELECT COUNT(*) AS total
             FROM sbaio_payroll_runs
             WHERE LOWER(COALESCE(run_status, 'draft')) IN ('draft','generated','pending')"
        );

        return (int)($row['total'] ?? 0);
    }

    private static function missingPunchCount(): int
    {
        if (!self::tableExists('sbaio_attendance_daily')) {
            return 0;
        }

        $row = DB::fetchOne(
            "SELECT COUNT(*) AS total
             FROM sbaio_attendance_daily
             WHERE (work_start_at IS NULL OR work_end_at IS NULL)
               AND LOWER(COALESCE(day_marker, 'workday')) NOT IN ('holiday','leave','off_day','closed')"
        );

        return (int)($row['total'] ?? 0);
    }

    private static function activeNoticesCount(): int
    {
        if (!self::tableExists('sbaio_notices')) {
            return 0;
        }

        $row = DB::fetchOne(
            "SELECT COUNT(*) AS total
             FROM sbaio_notices
             WHERE COALESCE(is_active, 1) = 1"
        );

        return (int)($row['total'] ?? 0);
    }

    private static function pendingLeaveCount(): int
    {
        if (!self::tableExists('sbaio_leave_requests')) {
            return 0;
        }

        $row = DB::fetchOne(
            "SELECT COUNT(*) AS total
             FROM sbaio_leave_requests
             WHERE LOWER(COALESCE(leave_status, 'draft')) IN ('draft','pending','submitted')"
        );

        return (int)($row['total'] ?? 0);
    }

    /**
     * @return array<int,array<string,string>>
     */
    private static function missingPunchEntries(int $limit): array
    {
        if (!self::tableExists('sbaio_attendance_daily')) {
            return [];
        }

        $rows = DB::fetchAll(
            "SELECT a.attendance_date, s.full_name, s.employee_code, a.work_start_at, a.work_end_at
             FROM sbaio_attendance_daily a
             LEFT JOIN sbaio_staff s ON s.id = a.staff_id
             WHERE (a.work_start_at IS NULL OR a.work_end_at IS NULL)
               AND LOWER(COALESCE(a.day_marker, 'workday')) NOT IN ('holiday','leave','off_day','closed')
             ORDER BY a.attendance_date DESC, a.id DESC
             LIMIT " . (int)$limit
        );

        return array_values(array_map(static function (array $row): array {
            $name = trim((string)($row['full_name'] ?? ''));
            $code = trim((string)($row['employee_code'] ?? ''));
            $date = trim((string)($row['attendance_date'] ?? ''));
            $missing = [];
            if (($row['work_start_at'] ?? null) === null || trim((string)($row['work_start_at'] ?? '')) === '') {
                $missing[] = 'start';
            }
            if (($row['work_end_at'] ?? null) === null || trim((string)($row['work_end_at'] ?? '')) === '') {
                $missing[] = 'end';
            }

            return [
                'label' => trim(($code !== '' ? $code . ' ' : '') . ($name !== '' ? $name : 'Unknown staff')),
                'meta' => trim($date . ($missing !== [] ? ' · Missing ' . implode(' + ', $missing) : '')),
                'url' => '/apps/sbaio/attendance',
            ];
        }, $rows));
    }

    /**
     * @return array<int,array<string,string>>
     */
    private static function draftPeriodEntries(int $limit): array
    {
        $rows = self::draftPeriods($limit);

        return array_values(array_map(static function (array $row): array {
            $periodKey = trim((string)($row['period_key'] ?? ''));
            $status = ucfirst(trim((string)($row['approval_status'] ?? 'draft')));

            return [
                'label' => $periodKey !== '' ? $periodKey : 'Draft period',
                'meta' => $status,
                'url' => '/apps/sbaio/timecards',
            ];
        }, $rows));
    }

    /**
     * @return array<int,array<string,string>>
     */
    private static function draftPayrollEntries(int $limit): array
    {
        $rows = self::draftPayrollRuns($limit);

        return array_values(array_map(static function (array $row): array {
            $label = trim((string)($row['period_month_label'] ?? ''));
            if ($label === '') {
                $year = trim((string)($row['period_year'] ?? ''));
                $month = trim((string)($row['period_month'] ?? ''));
                $label = trim($year . ($month !== '' ? '-' . str_pad($month, 2, '0', STR_PAD_LEFT) : ''), '-');
            }
            $periodKey = trim((string)($row['period_key'] ?? ''));
            $status = ucfirst(trim((string)($row['run_status'] ?? 'draft')));

            return [
                'label' => $label !== '' ? $label : ($periodKey !== '' ? $periodKey : 'Draft payroll'),
                'meta' => trim(($periodKey !== '' ? $periodKey . ' · ' : '') . $status),
                'url' => '/apps/sbaio/payroll',
            ];
        }, $rows));
    }

    /**
     * @return array<int,array<string,string>>
     */
    private static function pendingLeaveEntries(int $limit): array
    {
        if (!self::tableExists('sbaio_leave_requests')) {
            return [];
        }

        $rows = DB::fetchAll(
            "SELECT l.start_date, l.end_date, l.leave_type, l.leave_status, s.full_name, s.employee_code
             FROM sbaio_leave_requests l
             LEFT JOIN sbaio_staff s ON s.id = l.staff_id
             WHERE LOWER(COALESCE(l.leave_status, 'draft')) IN ('draft','pending','submitted')
             ORDER BY l.start_date DESC, l.id DESC
             LIMIT " . (int)$limit
        );

        return array_values(array_map(static function (array $row): array {
            $name = trim((string)($row['full_name'] ?? ''));
            $code = trim((string)($row['employee_code'] ?? ''));
            $start = trim((string)($row['start_date'] ?? ''));
            $end = trim((string)($row['end_date'] ?? ''));
            $status = ucfirst(trim((string)($row['leave_status'] ?? 'draft')));
            $leaveType = trim((string)($row['leave_type'] ?? 'leave'));
            $dateLabel = $start;
            if ($end !== '' && $end !== $start) {
                $dateLabel .= ' → ' . $end;
            }

            return [
                'label' => trim(($code !== '' ? $code . ' ' : '') . ($name !== '' ? $name : 'Unknown staff')),
                'meta' => trim($dateLabel . ' · ' . ucfirst($leaveType) . ' · ' . $status),
                'url' => '/apps/sbaio/leave',
            ];
        }, $rows));
    }

    /**
     * @param array<string,mixed> $request
     */
    private static function isVisibleForRequest(array $request): bool
    {
        $outerContext = is_array($request['context'] ?? null) ? (array)$request['context'] : [];
        $resolvedContext = is_array($outerContext['context'] ?? null) ? (array)$outerContext['context'] : [];
        $activeAssignedApps = array_map(
            static fn($value): string => strtolower(trim((string)$value)),
            (array)($resolvedContext['active_assigned_apps'] ?? [])
        );

        if (array_key_exists('active_assigned_apps', $resolvedContext)) {
            return in_array('sbaio', $activeAssignedApps, true);
        }

        return true;
    }

    private static function tableExists(string $table): bool
    {
        try {
            return DB::fetchOne(
                'SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? LIMIT 1',
                [$table]
            ) !== null;
        } catch (\Throwable $e) {
            return false;
        }
    }
}
