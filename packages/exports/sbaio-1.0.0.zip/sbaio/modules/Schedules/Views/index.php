<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$templateRows = is_array($templateRows ?? null) ? $templateRows : [];
$assignmentRows = is_array($assignmentRows ?? null) ? $assignmentRows : [];
$staffRows = is_array($staffRows ?? null) ? $staffRows : [];
$suiteActions = [
  ['label' => t('nav.sbaio_dashboard'), 'url' => '/apps/sbaio'],
  ['label' => t('nav.sbaio_attendance'), 'url' => '/apps/sbaio/attendance'],
  ['label' => t('nav.sbaio_leave'), 'url' => '/apps/sbaio/leave'],
];
$suiteLinks = [
  ['label' => 'Templates', 'value' => (string)count($templateRows)],
  ['label' => 'Assignments', 'value' => (string)count($assignmentRows)],
  ['label' => 'Active Staff', 'value' => (string)count($staffRows)],
];
$moduleFilters = [
  ['label' => 'View', 'value' => 'Templates + assignments'],
  ['label' => 'Scope', 'value' => 'Active staff scheduling'],
];
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_intro.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_feedback.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_filters.php';
?>
<section class="card">
  <div class="grid" style="grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-bottom:14px">
    <section class="card">
      <h3 style="margin-top:0">Create Shift Template</h3>
      <div class="muted" style="margin-bottom:10px">Define expected working windows, break structure, and workbook-aligned range metadata.</div>
      <form method="post" action="/apps/sbaio/schedules/templates" class="grid" style="grid-template-columns:repeat(2,minmax(0,1fr));gap:10px">
        <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
        <label>Template Name<input type="text" name="template_name" required></label>
        <label>Shift Code<input type="text" name="shift_code"></label>
        <label>Day Of Week<input type="text" name="day_of_week" placeholder="Mon"></label>
        <label>Legacy Name Ref<input type="text" name="legacy_name_ref"></label>
        <label>Range Start<input type="date" name="range_start_date"></label>
        <label>Range End<input type="date" name="range_end_date"></label>
        <label>Expected Start<input type="time" name="expected_start_time"></label>
        <label>Expected End<input type="time" name="expected_end_time"></label>
        <label>Break Start<input type="time" name="break_start_time"></label>
        <label>Break End<input type="time" name="break_end_time"></label>
        <label>Break Minutes<input type="number" name="expected_break_minutes" min="0" value="0"></label>
        <label>Job Label<input type="text" name="job_label"></label>
        <label>Scheduled Minutes<input type="number" name="scheduled_minutes" min="0" value="0"></label>
        <label style="display:flex;align-items:center;gap:8px;margin-top:24px"><input type="checkbox" name="is_active" value="1" checked> Active</label>
        <div style="grid-column:1 / -1"><button class="btn btn-primary" type="submit">Create Template</button></div>
      </form>
    </section>
    <section class="card">
      <h3 style="margin-top:0">Assign Schedule Range</h3>
      <div class="muted" style="margin-bottom:10px">Assign planned work expectations by staff and date range before comparing against attendance.</div>
      <form method="post" action="/apps/sbaio/schedules/assign" class="grid" style="grid-template-columns:repeat(2,minmax(0,1fr));gap:10px">
        <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
        <label>Staff
          <select name="staff_id" required>
            <option value="">Select staff</option>
            <?php foreach ($staffRows as $staff): ?>
              <option value="<?= (int)($staff['id'] ?? 0) ?>"><?= e(trim((string)($staff['employee_code'] ?? '') . ' ' . (string)($staff['full_name'] ?? ''))) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <label>Template
          <select name="template_id">
            <option value="">Manual / none</option>
            <?php foreach ($templateRows as $template): ?>
              <option value="<?= (int)($template['id'] ?? 0) ?>"><?= e((string)($template['template_name'] ?? '')) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <label>Start Date<input type="date" name="start_date" required></label>
        <label>End Date<input type="date" name="end_date" required></label>
        <label>Day Of Week<input type="text" name="day_of_week" placeholder="Mon"></label>
        <label>Legacy Name Ref<input type="text" name="legacy_name_ref"></label>
        <label>Override Start<input type="time" name="expected_start_time"></label>
        <label>Override End<input type="time" name="expected_end_time"></label>
        <label>Break Start<input type="time" name="break_start_time"></label>
        <label>Break End<input type="time" name="break_end_time"></label>
        <label>Override Break Minutes<input type="number" name="expected_break_minutes" min="0"></label>
        <label>Job Label<input type="text" name="job_label"></label>
        <label>Scheduled Minutes<input type="number" name="scheduled_minutes" min="0"></label>
        <label>Workbook Range Start<input type="date" name="range_start_date"></label>
        <label>Workbook Range End<input type="date" name="range_end_date"></label>
        <div style="grid-column:1 / -1"><button class="btn btn-primary" type="submit">Assign Range</button></div>
      </form>
    </section>
  </div>

  <h3 style="margin-top:0">Shift Templates</h3>
  <?php if ($templateRows === []): ?>
    <?php
    $emptyTitle = 'Shift Templates';
    $emptyMessage = 'No schedule templates yet. This module is ready for expected start, end, and break definitions.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Template</th><th>Shift Code</th><th>Day</th><th>Range</th><th>Expected Start</th><th>Expected End</th><th>Break</th><th>Job</th><th>Minutes</th><th>Active</th></tr></thead>
        <tbody>
          <?php foreach ($templateRows as $row): ?>
            <tr>
              <td><?= e((string)($row['template_name'] ?? '')) ?></td>
              <td><?= e((string)($row['shift_code'] ?? '')) ?></td>
              <td><?= e((string)($row['day_of_week'] ?? '')) ?></td>
              <td><?= e(trim((string)($row['range_start_date'] ?? '') . ' - ' . (string)($row['range_end_date'] ?? ''))) ?></td>
              <td><?= e((string)($row['expected_start_time'] ?? '')) ?></td>
              <td><?= e((string)($row['expected_end_time'] ?? '')) ?></td>
              <td><?= e(trim((string)($row['break_start_time'] ?? '') . ' - ' . (string)($row['break_end_time'] ?? ''))) ?> <?= e((string)($row['expected_break_minutes'] ?? '0')) ?>m</td>
              <td><?= e((string)($row['job_label'] ?? '')) ?></td>
              <td><?= e((string)($row['scheduled_minutes'] ?? '0')) ?></td>
              <td><?= !empty($row['is_active']) ? 'Yes' : 'No' ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>

  <h3>Assigned Schedules</h3>
  <?php if ($assignmentRows === []): ?>
    <?php
    $emptyTitle = 'Assigned Schedules';
    $emptyMessage = 'No schedule assignments yet. Staff/date expectations can be recorded here for future expected-versus-actual comparison.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Date</th><th>Staff</th><th>Legacy Name Ref</th><th>Template</th><th>Day</th><th>Range</th><th>Expected Start</th><th>Expected End</th><th>Break</th><th>Job</th><th>Minutes</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($assignmentRows as $row): ?>
            <tr>
              <td><?= e((string)($row['schedule_date'] ?? '')) ?></td>
              <td><?= e((string)($row['full_name'] ?? '')) ?></td>
              <td><?= e((string)($row['legacy_name_ref'] ?? '')) ?></td>
              <td><?= e((string)($row['template_name'] ?? '')) ?></td>
              <td><?= e((string)($row['day_of_week'] ?? '')) ?></td>
              <td><?= e(trim((string)($row['range_start_date'] ?? '') . ' - ' . (string)($row['range_end_date'] ?? ''))) ?></td>
              <td><?= e((string)($row['expected_start_time'] ?? '')) ?></td>
              <td><?= e((string)($row['expected_end_time'] ?? '')) ?></td>
              <td><?= e(trim((string)($row['break_start_time'] ?? '') . ' - ' . (string)($row['break_end_time'] ?? ''))) ?> <?= e((string)($row['expected_break_minutes'] ?? '0')) ?>m</td>
              <td><?= e((string)($row['job_label'] ?? '')) ?></td>
              <td><?= e((string)($row['scheduled_minutes'] ?? '0')) ?></td>
              <td><?= e((string)($row['assignment_status'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
