<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\Schedules\Controllers\SchedulesController;

require_once __DIR__ . '/Controllers/SchedulesController.php';

$router->get('/apps/sbaio/schedules', function () use ($view) {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    SchedulesController::index($view);
    return null;
});

$router->post('/apps/sbaio/schedules/templates', function () {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    SchedulesController::createTemplate();
    return null;
});

$router->post('/apps/sbaio/schedules/assign', function () {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    SchedulesController::assignRange();
    return null;
});
