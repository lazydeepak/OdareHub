<?php
declare(strict_types=1);

namespace Plugins\Sales\Controllers;

use App\Core\Auth;
use Plugins\Sales\Services\SalesService;

require_once __DIR__ . '/../Services/SalesService.php';

final class SalesController
{
    public static function index($view): void
    {
        $view->render('Sales::index.php', [
            'pageTitle' => 'Sales',
            'moduleTitle' => 'Sales',
            'moduleDescription' => 'Sales activity and revenue tracking for SBAIO.',
            'rows' => SalesService::recent(),
            'message' => (string)($_GET['ok'] ?? ''),
            'error' => (string)($_GET['err'] ?? ''),
        ]);
    }

    public static function create(): void
    {
        Auth::requireCsrf((string)($_POST['csrf'] ?? ''));

        $saleRef = trim((string)($_POST['sale_ref'] ?? ''));
        if ($saleRef === '') {
            self::redirect('err', 'Sale reference is required.');
        }

        SalesService::create($_POST);

        self::redirect('ok', 'Sales record created.');
    }

    private static function redirect(string $key, string $message): void
    {
        header('Location: /apps/sbaio/sales?' . $key . '=' . rawurlencode($message));
        exit;
    }
}
