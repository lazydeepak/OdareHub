<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$rows = is_array($rows ?? null) ? $rows : [];
$suiteActions = [
  ['label' => t('nav.sbaio_dashboard'), 'url' => '/apps/sbaio'],
  ['label' => t('nav.sbaio_customers'), 'url' => '/apps/sbaio/customers'],
];
$suiteLinks = [['label' => 'Records', 'value' => (string)count($rows)]];
$moduleFilters = [
  ['label' => 'View', 'value' => 'Recent sales'],
  ['label' => 'Related', 'value' => 'Customer activity'],
];
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_intro.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_feedback.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_filters.php';
?>
<section class="card">
  <div class="card" style="margin-bottom:14px">
    <h3 style="margin-top:0">Add Sales Record</h3>
    <div class="muted" style="margin-bottom:10px">Capture customer-facing sales activity so SBAIO reports can show operational and revenue movement together.</div>
    <form method="post" action="/apps/sbaio/sales/create" class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:10px">
      <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
      <label>Reference<input type="text" name="sale_ref" required></label>
      <label>Customer<input type="text" name="customer_name"></label>
      <label>Amount<input type="number" name="amount" step="0.01" min="0" required></label>
      <label>Status<input type="text" name="sale_status" value="open"></label>
      <label>Sale Date<input type="date" name="sale_date"></label>
      <div style="grid-column:1 / -1">
        <button class="btn btn-primary" type="submit">Create Sale</button>
      </div>
    </form>
  </div>
  <?php if ($rows === []): ?>
    <?php
    $emptyTitle = 'Sales Records';
    $emptyMessage = 'No sales records yet. This module is installed and ready.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <h3 style="margin-top:0">Sales Records</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Reference</th><th>Customer</th><th>Amount</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($rows as $row): ?>
            <tr>
              <td><?= e((string)($row['sale_ref'] ?? '')) ?></td>
              <td><?= e((string)($row['customer_name'] ?? '')) ?></td>
              <td><?= e(number_format((float)($row['amount'] ?? 0), 2, '.', ',')) ?></td>
              <td><?= e((string)($row['sale_status'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
