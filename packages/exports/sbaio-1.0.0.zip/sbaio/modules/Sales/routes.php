<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\Sales\Controllers\SalesController;

require_once __DIR__ . '/Controllers/SalesController.php';

$router->get('/apps/sbaio/sales', function () use ($view) {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    SalesController::index($view);
    return null;
});

$router->post('/apps/sbaio/sales/create', function () {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    SalesController::create();
    return null;
});
