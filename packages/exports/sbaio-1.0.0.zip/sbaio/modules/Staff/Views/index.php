<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$rows = is_array($rows ?? null) ? $rows : [];
$suiteActions = [
  ['label' => t('nav.sbaio_dashboard'), 'url' => '/apps/sbaio'],
  ['label' => t('nav.sbaio_schedules'), 'url' => '/apps/sbaio/schedules'],
  ['label' => t('nav.sbaio_payroll'), 'url' => '/apps/sbaio/payroll'],
];
$suiteLinks = [
  ['label' => 'Records', 'value' => (string)count($rows)],
];
$moduleFilters = [
  ['label' => 'View', 'value' => 'Recent staff records'],
  ['label' => 'Sort', 'value' => 'Newest first'],
];
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_intro.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_feedback.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_filters.php';
?>
<section class="card">
  <div class="card" style="margin-bottom:14px">
    <h3 style="margin-top:0">Add Staff Record</h3>
    <div class="muted" style="margin-bottom:10px">Staff is the foundation for schedules, attendance, timecards, payroll, and workbook NameRef mapping.</div>
    <form method="post" action="/apps/sbaio/staff/create" class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:10px">
      <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
      <label>Legacy SN<input type="text" name="legacy_sn"></label>
      <label>Employee Code<input type="text" name="employee_code"></label>
      <label>Full Name<input type="text" name="full_name" required></label>
      <label>Name Ref<input type="text" name="name_ref" placeholder="Workbook join name"></label>
      <label>Email<input type="email" name="email"></label>
      <label>Role Label<input type="text" name="role_label"></label>
      <label>Staff Type<input type="text" name="staff_type" placeholder="worker, helper, office"></label>
      <label>Salary Type<input type="text" name="salary_type" placeholder="hourly, daily, monthly"></label>
      <label>Salary Rate<input type="number" name="salary_rate" step="0.01" min="0"></label>
      <label>Helper Classification<input type="text" name="helper_classification"></label>
      <label>Nationality<input type="text" name="nationality"></label>
      <label>Gender<input type="text" name="gender"></label>
      <label>Date Of Birth<input type="date" name="date_of_birth"></label>
      <label>Employment Status<input type="text" name="employment_status" value="active"></label>
      <label>Department<input type="text" name="department_name"></label>
      <label>Branch<input type="text" name="branch_name"></label>
      <label>Hire Date<input type="date" name="hire_date"></label>
      <label>Join Date<input type="date" name="join_date"></label>
      <label>Exit Date<input type="date" name="exit_date"></label>
      <label>Legacy Job Details<input type="text" name="legacy_job_details"></label>
      <label>Residence Card Front<input type="text" name="residence_card_front"></label>
      <label>Residence Card Back<input type="text" name="residence_card_back"></label>
      <div style="grid-column:1 / -1">
        <button class="btn btn-primary" type="submit">Create Staff</button>
      </div>
    </form>
  </div>
  <?php if ($rows === []): ?>
    <?php
    $emptyTitle = 'Staff Directory';
    $emptyMessage = 'No staff records yet. This module is ready for employee master data used by attendance, timecards, and payroll.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <h3 style="margin-top:0">Staff Directory</h3>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Legacy SN</th>
            <th>Code</th>
            <th>Name</th>
            <th>Name Ref</th>
            <th>Email</th>
            <th>Type</th>
            <th>Salary Type</th>
            <th>Rate</th>
            <th>Employment</th>
            <th>Department</th>
            <th>Join</th>
            <th>Exit</th>
            <th>Job</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $row): ?>
            <tr>
              <td><?= e((string)($row['legacy_sn'] ?? '')) ?></td>
              <td><?= e((string)($row['employee_code'] ?? '')) ?></td>
              <td><?= e((string)($row['full_name'] ?? '')) ?></td>
              <td><?= e((string)($row['name_ref'] ?? '')) ?></td>
              <td><?= e((string)($row['email'] ?? '')) ?></td>
              <td><?= e((string)($row['staff_type'] ?? '')) ?></td>
              <td><?= e((string)($row['salary_type'] ?? '')) ?></td>
              <td><?= e($row['salary_rate'] === null ? '' : number_format((float)$row['salary_rate'], 2, '.', ',')) ?></td>
              <td><?= e((string)($row['employment_status'] ?? '')) ?></td>
              <td><?= e((string)($row['department_name'] ?? '')) ?></td>
              <td><?= e((string)($row['join_date'] ?? '')) ?></td>
              <td><?= e((string)($row['exit_date'] ?? '')) ?></td>
              <td><?= e((string)($row['legacy_job_details'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
