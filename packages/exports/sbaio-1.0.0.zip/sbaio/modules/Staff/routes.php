<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\Staff\Controllers\StaffController;

require_once __DIR__ . '/Controllers/StaffController.php';

$router->get('/apps/sbaio/staff', function () use ($view) {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    StaffController::index($view);
    return null;
});

$router->post('/apps/sbaio/staff/create', function () {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    StaffController::create();
    return null;
});
