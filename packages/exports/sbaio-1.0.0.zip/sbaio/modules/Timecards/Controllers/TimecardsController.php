<?php
declare(strict_types=1);

namespace Plugins\Timecards\Controllers;

use App\Core\Auth;
use App\Core\DB;
use Plugins\Timecards\Services\TimecardGenerationService;

final class TimecardsController
{
    public static function index($view): void
    {
        $dailyRows = DB::fetchAll(
            'SELECT t.work_date, s.full_name, t.legacy_name_ref, t.worked_minutes, t.scheduled_minutes, t.day_status, t.attendance_marker, t.salary_type, t.salary_rate, t.month_label, t.weekday_label, t.helper_flag, t.exception_status, t.approval_status
             FROM sbaio_timecards_daily t
             LEFT JOIN sbaio_staff s ON s.id = t.staff_id
             ORDER BY t.work_date DESC, t.id DESC
             LIMIT 40'
        );

        $periodRows = DB::fetchAll(
            'SELECT p.period_key, p.period_start, p.period_end, p.staff_id, s.full_name, p.legacy_name_ref, p.total_days, p.total_worked_minutes, p.total_worked_hours, p.workday_count, p.leave_days, p.holiday_days, p.exception_count, p.salary_type, p.salary_rate, p.approval_status
             FROM sbaio_timecard_periods p
             LEFT JOIN sbaio_staff s ON s.id = p.staff_id
             ORDER BY p.period_start DESC, p.id DESC
             LIMIT 24'
        );

        $view->render('Timecards::index.php', [
            'pageTitle' => 'Timecards',
            'moduleTitle' => 'Timecards',
            'moduleDescription' => 'Derived daily and monthly timecards built from attendance, schedules, leave, and review adjustments.',
            'dailyRows' => $dailyRows,
            'periodRows' => $periodRows,
            'message' => (string)($_GET['ok'] ?? ''),
            'error' => (string)($_GET['err'] ?? ''),
        ]);
    }

    public static function generate(): void
    {
        Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
        $startDate = (string)($_POST['period_start'] ?? '');
        $endDate = (string)($_POST['period_end'] ?? '');
        if ($startDate === '' || $endDate === '') {
            self::redirect('err', 'Period start and end are required.');
        }

        $result = TimecardGenerationService::generate($startDate, $endDate);
        self::redirect('ok', 'Generated period ' . $result['period_key'] . ' for ' . $result['staff_count'] . ' staff.');
    }

    public static function approvePeriod(): void
    {
        Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
        $staffId = (int)($_POST['staff_id'] ?? 0);
        $periodKey = (string)($_POST['period_key'] ?? '');
        $periodStart = (string)($_POST['period_start'] ?? '');
        $periodEnd = (string)($_POST['period_end'] ?? '');
        if ($staffId <= 0 || $periodKey === '' || $periodStart === '' || $periodEnd === '') {
            self::redirect('err', 'Period approval requires staff and period details.');
        }

        DB::query(
            "UPDATE sbaio_timecards_daily SET approval_status='approved', approved_at=NOW() WHERE staff_id = ? AND work_date BETWEEN ? AND ?",
            [$staffId, $periodStart, $periodEnd]
        );
        DB::query(
            "UPDATE sbaio_timecard_periods SET approval_status='approved' WHERE staff_id = ? AND period_key = ?",
            [$staffId, $periodKey]
        );

        self::redirect('ok', 'Timecard period approved.');
    }

    private static function redirect(string $key, string $message): void
    {
        header('Location: /apps/sbaio/timecards?' . $key . '=' . rawurlencode($message));
        exit;
    }
}
