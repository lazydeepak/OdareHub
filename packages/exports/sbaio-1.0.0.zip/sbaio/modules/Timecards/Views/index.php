<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$dailyRows = is_array($dailyRows ?? null) ? $dailyRows : [];
$periodRows = is_array($periodRows ?? null) ? $periodRows : [];
$suiteActions = [
  ['label' => t('nav.sbaio_dashboard'), 'url' => '/apps/sbaio'],
  ['label' => t('nav.sbaio_attendance'), 'url' => '/apps/sbaio/attendance'],
  ['label' => t('nav.sbaio_payroll'), 'url' => '/apps/sbaio/payroll'],
];
$suiteLinks = [
  ['label' => 'Daily Rows', 'value' => (string)count($dailyRows)],
  ['label' => 'Periods', 'value' => (string)count($periodRows)],
];
$moduleFilters = [
  ['label' => 'View', 'value' => 'Daily rows + monthly summaries'],
  ['label' => 'Sort', 'value' => 'Newest period first'],
];
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_intro.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_feedback.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_filters.php';
?>
<section class="card">
  <div class="card" style="margin-bottom:14px">
    <h3 style="margin-top:0">Generate Timecard Period</h3>
    <div class="muted" style="margin-bottom:10px">Generate conservative, workbook-aligned timecard rows from attendance, schedules, leave, and holiday inputs.</div>
    <form method="post" action="/apps/sbaio/timecards/generate" class="grid" style="grid-template-columns:repeat(3,minmax(0,1fr));gap:10px">
      <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
      <label>Period Start<input type="date" name="period_start" required></label>
      <label>Period End<input type="date" name="period_end" required></label>
      <div style="display:flex;align-items:flex-end"><button class="btn btn-primary" type="submit">Generate Timecards</button></div>
    </form>
    <div class="muted" style="margin-top:8px">Generation now carries workbook-compatible daily fields like name ref, salary type/rate, weekday/month labels, helper flag, and attendance markers. Overtime, rounding, and premium logic remain deferred until full workbook/VBA extraction.</div>
  </div>
  <h3 style="margin-top:0">Daily Timecards</h3>
  <?php if ($dailyRows === []): ?>
    <?php
    $emptyTitle = 'Daily Timecards';
    $emptyMessage = 'No daily timecards yet. This module is ready to derive daily rows from attendance, leave, and schedule sources.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Date</th><th>Staff</th><th>Name Ref</th><th>Weekday</th><th>Worked Minutes</th><th>Scheduled</th><th>Marker</th><th>Day Status</th><th>Salary Type</th><th>Rate</th><th>Helper</th><th>Exception</th><th>Approval</th></tr></thead>
        <tbody>
          <?php foreach ($dailyRows as $row): ?>
            <tr>
              <td><?= e((string)($row['work_date'] ?? '')) ?></td>
              <td><?= e((string)($row['full_name'] ?? '')) ?></td>
              <td><?= e((string)($row['legacy_name_ref'] ?? '')) ?></td>
              <td><?= e((string)($row['weekday_label'] ?? '')) ?></td>
              <td><?= e((string)($row['worked_minutes'] ?? '0')) ?></td>
              <td><?= e((string)($row['scheduled_minutes'] ?? '0')) ?></td>
              <td><?= e((string)($row['attendance_marker'] ?? '')) ?></td>
              <td><?= e((string)($row['day_status'] ?? '')) ?></td>
              <td><?= e((string)($row['salary_type'] ?? '')) ?></td>
              <td><?= e($row['salary_rate'] === null ? '' : number_format((float)$row['salary_rate'], 2, '.', ',')) ?></td>
              <td><?= !empty($row['helper_flag']) ? 'Yes' : 'No' ?></td>
              <td><?= e((string)($row['exception_status'] ?? '')) ?></td>
              <td><?= e((string)($row['approval_status'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
  <h3>Monthly Summaries</h3>
  <?php if ($periodRows === []): ?>
    <?php
    $emptyTitle = 'Monthly Summaries';
    $emptyMessage = 'No timecard periods yet. Monthly summary, approval, and locking structure is ready for future generation logic.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Period</th><th>Staff</th><th>Name Ref</th><th>Total Days</th><th>Workdays</th><th>Worked Minutes</th><th>Worked Hours</th><th>Leave Days</th><th>Holiday Days</th><th>Salary Type</th><th>Rate</th><th>Exceptions</th><th>Approval</th><th>Action</th></tr></thead>
        <tbody>
          <?php foreach ($periodRows as $row): ?>
            <tr>
              <td><?= e((string)($row['period_key'] ?? '')) ?></td>
              <td><?= e((string)($row['full_name'] ?? '')) ?></td>
              <td><?= e((string)($row['legacy_name_ref'] ?? '')) ?></td>
              <td><?= e((string)($row['total_days'] ?? '0')) ?></td>
              <td><?= e((string)($row['workday_count'] ?? '0')) ?></td>
              <td><?= e((string)($row['total_worked_minutes'] ?? '0')) ?></td>
              <td><?= e((string)($row['total_worked_hours'] ?? '0')) ?></td>
              <td><?= e((string)($row['leave_days'] ?? '0')) ?></td>
              <td><?= e((string)($row['holiday_days'] ?? '0')) ?></td>
              <td><?= e((string)($row['salary_type'] ?? '')) ?></td>
              <td><?= e($row['salary_rate'] === null ? '' : number_format((float)$row['salary_rate'], 2, '.', ',')) ?></td>
              <td><?= e((string)($row['exception_count'] ?? '0')) ?></td>
              <td><?= e((string)($row['approval_status'] ?? '')) ?></td>
              <td>
                <?php if ((string)($row['approval_status'] ?? '') !== 'approved'): ?>
                  <form method="post" action="/apps/sbaio/timecards/approve">
                    <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
                    <input type="hidden" name="staff_id" value="<?= (int)($row['staff_id'] ?? 0) ?>">
                    <input type="hidden" name="period_key" value="<?= e((string)($row['period_key'] ?? '')) ?>">
                    <input type="hidden" name="period_start" value="<?= e((string)($row['period_start'] ?? '')) ?>">
                    <input type="hidden" name="period_end" value="<?= e((string)($row['period_end'] ?? '')) ?>">
                    <button class="btn" type="submit">Approve</button>
                  </form>
                <?php else: ?>
                  <span class="muted">Approved</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
  <div class="muted" style="margin-top:8px">Deferred placeholders: overtime, rounding, holiday premiums, helper classification pay impacts, and final salary rules.</div>
</section>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
