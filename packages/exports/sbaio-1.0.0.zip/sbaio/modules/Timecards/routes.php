<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\Timecards\Controllers\TimecardsController;

require_once __DIR__ . '/Controllers/TimecardsController.php';
require_once __DIR__ . '/Services/TimecardGenerationService.php';

$router->get('/apps/sbaio/timecards', function () use ($view) {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    TimecardsController::index($view);
    return null;
});

$router->post('/apps/sbaio/timecards/generate', function () {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    TimecardsController::generate();
    return null;
});

$router->post('/apps/sbaio/timecards/approve', function () {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    TimecardsController::approvePeriod();
    return null;
});
