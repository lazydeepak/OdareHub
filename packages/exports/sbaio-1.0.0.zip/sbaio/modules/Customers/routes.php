<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\Customers\Controllers\CustomersController;

require_once __DIR__ . '/Controllers/CustomersController.php';

$router->get('/apps/sbaio/customers', function () use ($view) {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    CustomersController::index($view);
    return null;
});

$router->post('/apps/sbaio/customers/create', function () {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    CustomersController::create();
    return null;
});
