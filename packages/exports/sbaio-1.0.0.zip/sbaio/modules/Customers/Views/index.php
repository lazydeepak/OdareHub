<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$rows = is_array($rows ?? null) ? $rows : [];
$suiteActions = [
  ['label' => t('nav.sbaio_dashboard'), 'url' => '/apps/sbaio'],
  ['label' => t('nav.sbaio_sales'), 'url' => '/apps/sbaio/sales'],
];
$suiteLinks = [['label' => 'Records', 'value' => (string)count($rows)]];
$moduleFilters = [
  ['label' => 'View', 'value' => 'Recent customers'],
  ['label' => 'Sort', 'value' => 'Newest first'],
];
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_intro.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_feedback.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_filters.php';
?>
<section class="card">
  <div class="card" style="margin-bottom:14px">
    <h3 style="margin-top:0">Add Customer</h3>
    <div class="muted" style="margin-bottom:10px">Use this workspace to keep customer contacts visible alongside sales and expense reporting.</div>
    <form method="post" action="/apps/sbaio/customers/create" class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:10px">
      <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
      <label>Customer Name<input type="text" name="customer_name" required></label>
      <label>Contact Name<input type="text" name="contact_name"></label>
      <label>Email<input type="email" name="email"></label>
      <label>Phone<input type="text" name="phone"></label>
      <label>Status<input type="text" name="status" value="active"></label>
      <div style="grid-column:1 / -1">
        <button class="btn btn-primary" type="submit">Create Customer</button>
      </div>
    </form>
  </div>
  <?php if ($rows === []): ?>
    <?php
    $emptyTitle = 'Customer Records';
    $emptyMessage = 'No customer records yet. This module is installed and ready.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <h3 style="margin-top:0">Customer Records</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Customer</th><th>Contact</th><th>Email</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($rows as $row): ?>
            <tr>
              <td><?= e((string)($row['customer_name'] ?? '')) ?></td>
              <td><?= e((string)($row['contact_name'] ?? '')) ?></td>
              <td><?= e((string)($row['email'] ?? '')) ?></td>
              <td><?= e((string)($row['status'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
