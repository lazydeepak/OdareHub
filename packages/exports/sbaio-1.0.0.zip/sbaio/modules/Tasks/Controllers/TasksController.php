<?php
declare(strict_types=1);

namespace Plugins\Tasks\Controllers;

use App\Core\Auth;
use Plugins\Tasks\Services\TasksService;

require_once __DIR__ . '/../Services/TasksService.php';

final class TasksController
{
    public static function index($view): void
    {
        $view->render('Tasks::index.php', [
            'pageTitle' => 'Tasks',
            'moduleTitle' => 'Tasks',
            'moduleDescription' => 'Task and follow-up queue for SBAIO operations, including attendance and payroll review work.',
            'rows' => TasksService::recent(),
            'staffRows' => TasksService::activeStaff(),
            'message' => (string)($_GET['ok'] ?? ''),
            'error' => (string)($_GET['err'] ?? ''),
        ]);
    }

    public static function create(): void
    {
        Auth::requireCsrf((string)($_POST['csrf'] ?? ''));

        $taskTitle = trim((string)($_POST['task_title'] ?? ''));
        if ($taskTitle === '') {
            self::redirect('err', 'Task title is required.');
        }

        TasksService::create($_POST);

        self::redirect('ok', 'Task created.');
    }

    private static function redirect(string $key, string $message): void
    {
        header('Location: /apps/sbaio/tasks?' . $key . '=' . rawurlencode($message));
        exit;
    }
}
