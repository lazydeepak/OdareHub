<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$rows = is_array($rows ?? null) ? $rows : [];
$staffRows = is_array($staffRows ?? null) ? $staffRows : [];
$suiteActions = [
  ['label' => t('nav.sbaio_dashboard'), 'url' => '/apps/sbaio'],
  ['label' => t('nav.sbaio_notices'), 'url' => '/apps/sbaio/notices'],
];
$suiteLinks = [['label' => 'Open Items', 'value' => (string)count($rows)]];
$moduleFilters = [
  ['label' => 'View', 'value' => 'Recent tasks'],
  ['label' => 'Scope', 'value' => 'Ops follow-up queue'],
];
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_intro.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_feedback.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_filters.php';
?>
<section class="card">
  <div class="card" style="margin-bottom:14px">
    <h3 style="margin-top:0">Add Task</h3>
    <div class="muted" style="margin-bottom:10px">Use tasks for missing punch follow-up, payroll review, and general small-business coordination work.</div>
    <form method="post" action="/apps/sbaio/tasks/create" class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:10px">
      <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
      <label>Task Title<input type="text" name="task_title" required></label>
      <label>Owner Name<input type="text" name="owner_name"></label>
      <label>Task Type<input type="text" name="task_type" placeholder="attendance, payroll, ops"></label>
      <label>Bucket<input type="text" name="task_bucket" placeholder="review, correction, close"></label>
      <label>Related Staff
        <select name="related_staff_id">
          <option value="">None</option>
          <?php foreach ($staffRows as $staff): ?>
            <option value="<?= (int)($staff['id'] ?? 0) ?>"><?= e(trim((string)($staff['employee_code'] ?? '') . ' ' . (string)($staff['full_name'] ?? ''))) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Related Date<input type="date" name="related_date"></label>
      <label>Status<input type="text" name="task_status" value="open"></label>
      <label>Priority<input type="text" name="priority" value="normal"></label>
      <label>Due Date<input type="date" name="due_date"></label>
      <div style="grid-column:1 / -1">
        <button class="btn btn-primary" type="submit">Create Task</button>
      </div>
    </form>
  </div>
  <?php if ($rows === []): ?>
    <?php
    $emptyTitle = 'Task Queue';
    $emptyMessage = 'No task records yet. This module is ready for attendance correction, payroll review, and general follow-up tasks.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <h3 style="margin-top:0">Task Queue</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Task</th><th>Owner</th><th>Type</th><th>Bucket</th><th>Status</th><th>Priority</th><th>Related Date</th></tr></thead>
        <tbody>
          <?php foreach ($rows as $row): ?>
            <tr>
              <td><?= e((string)($row['task_title'] ?? '')) ?></td>
              <td><?= e((string)($row['owner_name'] ?? '')) ?></td>
              <td><?= e((string)($row['task_type'] ?? '')) ?></td>
              <td><?= e((string)($row['task_bucket'] ?? '')) ?></td>
              <td><?= e((string)($row['task_status'] ?? '')) ?></td>
              <td><?= e((string)($row['priority'] ?? '')) ?></td>
              <td><?= e((string)($row['related_date'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
