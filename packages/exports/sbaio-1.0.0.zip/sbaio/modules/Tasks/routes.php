<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\Tasks\Controllers\TasksController;

require_once __DIR__ . '/Controllers/TasksController.php';

$router->get('/apps/sbaio/tasks', function () use ($view) {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    TasksController::index($view);
    return null;
});

$router->post('/apps/sbaio/tasks/create', function () {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    TasksController::create();
    return null;
});
