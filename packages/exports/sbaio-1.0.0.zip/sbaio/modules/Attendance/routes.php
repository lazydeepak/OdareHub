<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\Attendance\Controllers\AttendanceController;

require_once __DIR__ . '/Controllers/AttendanceController.php';

$router->get('/apps/sbaio/attendance', function () use ($view) {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    AttendanceController::index($view);
    return null;
});

$router->post('/apps/sbaio/attendance/save', function () {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    AttendanceController::saveEntry();
    return null;
});
