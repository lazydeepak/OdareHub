<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$staffRows = is_array($staffRows ?? null) ? $staffRows : [];
$rows = is_array($rows ?? null) ? $rows : [];
$suiteActions = [
  ['label' => t('nav.sbaio_dashboard'), 'url' => '/apps/sbaio'],
  ['label' => t('nav.sbaio_timecards'), 'url' => '/apps/sbaio/timecards'],
];
$suiteLinks = [
  ['label' => 'Staff', 'value' => (string)count($staffRows)],
  ['label' => 'Recent Rows', 'value' => (string)count($rows)],
];
$moduleFilters = [
  ['label' => 'View', 'value' => 'Recent attendance'],
  ['label' => 'Scope', 'value' => 'All active staff'],
];
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_intro.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_feedback.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_filters.php';
?>
<section class="card">
  <div class="card" style="margin-bottom:14px">
    <h3 style="margin-top:0">Enter Daily Attendance</h3>
    <div class="muted" style="margin-bottom:10px">Use this for raw attendance truth. Missing or corrected punches should be recorded here before timecard generation.</div>
    <form method="post" action="/apps/sbaio/attendance/save" class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:10px">
      <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
      <label>Staff
        <select name="staff_id" required>
          <option value="">Select staff</option>
          <?php foreach ($staffRows as $staff): ?>
            <option value="<?= (int)($staff['id'] ?? 0) ?>"><?= e(trim((string)($staff['employee_code'] ?? '') . ' ' . (string)($staff['full_name'] ?? ''))) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Date<input type="date" name="attendance_date" required></label>
      <label>Day Marker
        <select name="day_marker">
          <option value="workday">Workday</option>
          <option value="holiday">Holiday</option>
          <option value="leave">Leave</option>
          <option value="off_day">Off Day</option>
        </select>
      </label>
      <label>Manual Note<input type="text" name="correction_note" placeholder="optional correction note"></label>
      <label>Work Start<input type="time" name="work_start_time"></label>
      <label>Work End<input type="time" name="work_end_time"></label>
      <label>Break Start<input type="time" name="break_start_time"></label>
      <label>Break End<input type="time" name="break_end_time"></label>
      <div style="grid-column:1 / -1"><button class="btn btn-primary" type="submit">Save Attendance</button></div>
    </form>
  </div>
  <?php if ($rows === []): ?>
    <?php
    $emptyTitle = 'Recent Attendance';
    $emptyMessage = 'No attendance rows yet. This module is ready for daily start, end, break, and workday marker inputs.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <h3 style="margin-top:0">Recent Attendance</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Date</th><th>Staff</th><th>Start</th><th>End</th><th>Break Start</th><th>Break End</th><th>Marker</th><th>Source</th><th>Note</th></tr></thead>
        <tbody>
          <?php foreach ($rows as $row): ?>
            <tr>
              <td><?= e((string)($row['attendance_date'] ?? '')) ?></td>
              <td><?= e(trim((string)($row['employee_code'] ?? '') . ' ' . (string)($row['full_name'] ?? ''))) ?></td>
              <td><?= e((string)($row['work_start_at'] ?? '')) ?></td>
              <td><?= e((string)($row['work_end_at'] ?? '')) ?></td>
              <td><?= e((string)($row['break_start_at'] ?? '')) ?></td>
              <td><?= e((string)($row['break_end_at'] ?? '')) ?></td>
              <td><?= e((string)($row['day_marker'] ?? '')) ?></td>
              <td><?= e((string)($row['source_label'] ?? '')) ?></td>
              <td><?= e((string)($row['correction_note'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
