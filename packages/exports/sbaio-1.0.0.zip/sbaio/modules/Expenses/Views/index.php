<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$rows = is_array($rows ?? null) ? $rows : [];
$suiteActions = [
  ['label' => t('nav.sbaio_dashboard'), 'url' => '/apps/sbaio'],
  ['label' => t('nav.sbaio_sales'), 'url' => '/apps/sbaio/sales'],
];
$suiteLinks = [['label' => 'Records', 'value' => (string)count($rows)]];
$moduleFilters = [
  ['label' => 'View', 'value' => 'Recent expenses'],
  ['label' => 'Sort', 'value' => 'Newest first'],
];
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_intro.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_feedback.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_filters.php';
?>
<section class="card">
  <div class="card" style="margin-bottom:14px">
    <h3 style="margin-top:0">Add Expense Record</h3>
    <div class="muted" style="margin-bottom:10px">Track operating expenses so SBAIO can grow into the workbook’s broader business reporting model.</div>
    <form method="post" action="/apps/sbaio/expenses/create" class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:10px">
      <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
      <label>Reference<input type="text" name="expense_ref" required></label>
      <label>Category<input type="text" name="category_name"></label>
      <label>Amount<input type="number" name="amount" step="0.01" min="0" required></label>
      <label>Status<input type="text" name="expense_status" value="submitted"></label>
      <label>Expense Date<input type="date" name="expense_date"></label>
      <div style="grid-column:1 / -1">
        <button class="btn btn-primary" type="submit">Create Expense</button>
      </div>
    </form>
  </div>
  <?php if ($rows === []): ?>
    <?php
    $emptyTitle = 'Expense Records';
    $emptyMessage = 'No expense records yet. This module is installed and ready.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <h3 style="margin-top:0">Expense Records</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Reference</th><th>Category</th><th>Amount</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($rows as $row): ?>
            <tr>
              <td><?= e((string)($row['expense_ref'] ?? '')) ?></td>
              <td><?= e((string)($row['category_name'] ?? '')) ?></td>
              <td><?= e(number_format((float)($row['amount'] ?? 0), 2, '.', ',')) ?></td>
              <td><?= e((string)($row['expense_status'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
