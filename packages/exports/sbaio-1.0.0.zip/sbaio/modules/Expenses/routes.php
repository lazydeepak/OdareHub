<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\Expenses\Controllers\ExpensesController;

require_once __DIR__ . '/Controllers/ExpensesController.php';

$router->get('/apps/sbaio/expenses', function () use ($view) {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    ExpensesController::index($view);
    return null;
});

$router->post('/apps/sbaio/expenses/create', function () {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    ExpensesController::create();
    return null;
});
