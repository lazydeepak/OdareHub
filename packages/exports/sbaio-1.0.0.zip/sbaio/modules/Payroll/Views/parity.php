<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$rows = is_array($rows ?? null) ? $rows : [];
$summary = is_array($summary ?? null) ? $summary : [];
$suiteActions = [
    ['label' => t('nav.sbaio_dashboard'), 'url' => '/apps/sbaio'],
    ['label' => t('nav.sbaio_payroll'), 'url' => '/apps/sbaio/payroll'],
];
$suiteLinks = [
    ['label' => 'Rows', 'value' => (string)count($rows)],
    ['label' => 'Matches', 'value' => (string)($summary['match'] ?? 0)],
    ['label' => 'Mismatches', 'value' => (string)($summary['mismatch'] ?? 0)],
];
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_intro.php';
$statusColors = [
    'match' => '#1f7a1f',
    'mismatch' => '#b42318',
    'missing_imported_source' => '#b54708',
    'missing_payroll_record' => '#7a271a',
    'unmatched_staff_mapping' => '#6941c6',
    'deferred' => '#667085',
];
$formatValue = static function ($value): string {
    if ($value === null || $value === '') {
        return '';
    }
    if (is_numeric($value)) {
        return number_format((float)$value, 2, '.', ',');
    }
    return (string)$value;
};
$fieldCell = static function (array $field) use ($statusColors, $formatValue): string {
    $status = (string)($field['status'] ?? 'deferred');
    $color = $statusColors[$status] ?? '#667085';
    $imported = $formatValue($field['imported'] ?? null);
    $generated = $formatValue($field['generated'] ?? null);
    if ($status === 'deferred') {
        return '<span style="color:' . e($color) . ';font-weight:600">Deferred</span>';
    }
    return '<div><span style="color:#667085">Src:</span> ' . e($imported) . '</div><div><span style="color:#667085">Gen:</span> ' . e($generated) . '</div><div style="color:' . e($color) . ';font-weight:600">' . e($status) . '</div>';
};
?>
<section class="card">
  <div class="grid" style="grid-template-columns:repeat(6,minmax(0,1fr));gap:10px;margin-bottom:14px">
    <?php foreach (['match','mismatch','missing_imported_source','missing_payroll_record','unmatched_staff_mapping','deferred'] as $status): ?>
      <div class="card">
        <div class="muted"><?= e(ucwords(str_replace('_', ' ', $status))) ?></div>
        <div style="font-size:22px;font-weight:700;color:<?= e($statusColors[$status] ?? '#667085') ?>"><?= e((string)($summary[$status] ?? 0)) ?></div>
      </div>
    <?php endforeach; ?>
  </div>

  <?php if ($rows === []): ?>
    <div class="muted">No parity rows yet. Generate payroll records or import workbook source tables first.</div>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Employee</th>
            <th>Period</th>
            <th>Type</th>
            <th>Variant</th>
            <th>Overall</th>
            <th>Reference</th>
            <th>Base</th>
            <th>Hourly</th>
            <th>Health</th>
            <th>Pension</th>
            <th>Deductions</th>
            <th>Gross</th>
            <th>Net/Cash</th>
            <th>Details</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $row): ?>
            <?php $overall = (string)($row['overall_status'] ?? 'deferred'); ?>
            <?php $color = $statusColors[$overall] ?? '#667085'; ?>
            <?php $fields = is_array($row['fields'] ?? null) ? $row['fields'] : []; ?>
            <tr>
              <td>
                <div><?= e((string)($row['employee'] ?? '')) ?></div>
                <div class="muted"><?= e((string)($row['legacy_name_ref'] ?? '')) ?></div>
              </td>
              <td><?= e((string)($row['period_label'] ?? '')) ?></td>
              <td><?= e((string)($row['salary_type'] ?? '')) ?></td>
              <td><?= e((string)($row['payslip_variant'] ?? '')) ?></td>
              <td><span style="color:<?= e($color) ?>;font-weight:700"><?= e($overall) ?></span></td>
              <td><?= $fieldCell($fields['salary_reference_amount'] ?? []) ?></td>
              <td><?= $fieldCell($fields['base_salary_amount'] ?? []) ?></td>
              <td><?= $fieldCell($fields['hourly_pay_amount'] ?? []) ?></td>
              <td><?= $fieldCell($fields['health_insurance_amount'] ?? []) ?></td>
              <td><?= $fieldCell($fields['pension_insurance_amount'] ?? []) ?></td>
              <td><?= $fieldCell($fields['total_deductions_amount'] ?? []) ?></td>
              <td><?= $fieldCell($fields['gross_amount'] ?? []) ?></td>
              <td><?= $fieldCell($fields['net_amount'] ?? ($fields['cash_payment_amount'] ?? [])) ?></td>
              <td><?= e(implode(', ', array_slice((array)($row['details'] ?? []), 0, 6))) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
  <div class="muted" style="margin-top:8px">Fields that are not yet safely generalized from the workbook remain marked as deferred instead of mismatched.</div>
</section>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
