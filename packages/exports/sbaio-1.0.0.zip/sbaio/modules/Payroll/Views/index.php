<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$approvedPeriods = is_array($approvedPeriods ?? null) ? $approvedPeriods : [];
$runRows = is_array($runRows ?? null) ? $runRows : [];
$recordRows = is_array($recordRows ?? null) ? $recordRows : [];
$suiteActions = [
  ['label' => t('nav.sbaio_dashboard'), 'url' => '/apps/sbaio'],
  ['label' => t('nav.sbaio_payroll_parity'), 'url' => '/apps/sbaio/payroll/parity'],
  ['label' => t('nav.sbaio_timecards'), 'url' => '/apps/sbaio/timecards'],
];
$suiteLinks = [
  ['label' => 'Approved Periods', 'value' => (string)count($approvedPeriods)],
  ['label' => 'Runs', 'value' => (string)count($runRows)],
  ['label' => 'Records', 'value' => (string)count($recordRows)],
];
$moduleFilters = [
  ['label' => 'View', 'value' => 'Runs + output records'],
  ['label' => 'Prerequisite', 'value' => 'Approved timecard periods'],
];
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_intro.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_feedback.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_filters.php';
?>
<section class="card">
  <div class="card" style="margin-bottom:14px">
    <h3 style="margin-top:0">Create Payroll Run Scaffold</h3>
    <div class="muted" style="margin-bottom:10px">Create payroll records from approved timecard periods, then validate workbook-backed parity from the dedicated validation surface.</div>
    <form method="post" action="/apps/sbaio/payroll/create-run" class="grid" style="grid-template-columns:repeat(2,minmax(0,1fr));gap:10px">
      <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
      <label>Approved Timecard Period
        <select name="period_key" required>
          <option value="">Select approved period</option>
          <?php foreach ($approvedPeriods as $period): ?>
            <option value="<?= e((string)($period['period_key'] ?? '')) ?>"><?= e((string)($period['period_key'] ?? '')) ?> (<?= e((string)($period['period_start'] ?? '')) ?> to <?= e((string)($period['period_end'] ?? '')) ?>)</option>
          <?php endforeach; ?>
        </select>
      </label>
      <div style="display:flex;align-items:flex-end"><button class="btn btn-primary" type="submit">Create Payroll Scaffold</button></div>
    </form>
    <div class="muted" style="margin-top:8px">This now creates workbook-compatible payroll scaffolds with month/year context, fixed-vs-hourly payslip variants, working-day labels, monthly salary references, and imported fixed-pay profile support when legacy workbook data has been loaded.</div>
  </div>
  <h3 style="margin-top:0">Payroll Runs</h3>
  <?php if ($runRows === []): ?>
    <?php
    $emptyTitle = 'Payroll Runs';
    $emptyMessage = 'No payroll runs yet. This module is ready for draft, approval, and locking flows built from approved timecards.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Period</th><th>Month</th><th>Variant</th><th>Start</th><th>End</th><th>Run Status</th><th>Approval</th><th>Locked</th></tr></thead>
        <tbody>
          <?php foreach ($runRows as $row): ?>
            <tr>
              <td><?= e((string)($row['period_key'] ?? '')) ?></td>
              <td><?= e(trim((string)($row['period_month_label'] ?? '') . ' ' . (string)($row['period_year'] ?? ''))) ?></td>
              <td><?= e((string)($row['payslip_variant'] ?? '')) ?></td>
              <td><?= e((string)($row['period_start'] ?? '')) ?></td>
              <td><?= e((string)($row['period_end'] ?? '')) ?></td>
              <td><?= e((string)($row['run_status'] ?? '')) ?></td>
              <td><?= e((string)($row['approval_status'] ?? '')) ?></td>
              <td><?= e((string)($row['locked_at'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
  <h3>Payroll Output Records</h3>
  <?php if ($recordRows === []): ?>
    <?php
    $emptyTitle = 'Payroll Output Records';
    $emptyMessage = 'No payroll output records yet. Salary outputs are scaffolded, but exact workbook-driven pay rules are intentionally not invented here.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Staff</th><th>Name Ref</th><th>Variant</th><th>Salary Type</th><th>Rate</th><th>Reference</th><th>Worked Days</th><th>Workdays</th><th>Worked Minutes</th><th>Worked Hours</th><th>OT Min</th><th>Leave</th><th>Holiday</th><th>Health</th><th>Pension</th><th>Employ.</th><th>Total Ded.</th><th>Base Salary</th><th>Hourly Pay</th><th>Gross</th><th>Net</th></tr></thead>
        <tbody>
          <?php foreach ($recordRows as $row): ?>
            <tr>
              <td><?= e((string)($row['full_name'] ?? '')) ?></td>
              <td><?= e((string)($row['legacy_name_ref'] ?? '')) ?></td>
              <td><?= e((string)($row['payslip_variant'] ?? '')) ?></td>
              <td><?= e((string)($row['salary_type'] ?? '')) ?></td>
              <td><?= e($row['salary_rate'] === null ? '' : number_format((float)$row['salary_rate'], 2, '.', ',')) ?></td>
              <td><?= e($row['salary_reference_amount'] === null ? '' : number_format((float)$row['salary_reference_amount'], 2, '.', ',')) ?></td>
              <td><?= e((string)($row['worked_days'] ?? '0')) ?></td>
              <td><?= e((string)($row['workday_count'] ?? '0')) ?></td>
              <td><?= e((string)($row['worked_minutes'] ?? '0')) ?></td>
              <td><?= e((string)($row['worked_hours'] ?? '0')) ?></td>
              <td><?= e((string)($row['overtime_minutes'] ?? '0')) ?></td>
              <td><?= e((string)($row['leave_days'] ?? '0')) ?></td>
              <td><?= e((string)($row['holiday_days'] ?? '0')) ?></td>
              <td><?= e($row['health_insurance_amount'] === null ? '' : number_format((float)$row['health_insurance_amount'], 2, '.', ',')) ?></td>
              <td><?= e($row['pension_insurance_amount'] === null ? '' : number_format((float)$row['pension_insurance_amount'], 2, '.', ',')) ?></td>
              <td><?= e($row['employment_insurance_amount'] === null ? '' : number_format((float)$row['employment_insurance_amount'], 2, '.', ',')) ?></td>
              <td><?= e($row['total_deductions_amount'] === null ? '' : number_format((float)$row['total_deductions_amount'], 2, '.', ',')) ?></td>
              <td><?= e($row['base_salary_amount'] === null ? '' : number_format((float)$row['base_salary_amount'], 2, '.', ',')) ?></td>
              <td><?= e($row['hourly_pay_amount'] === null ? '' : number_format((float)$row['hourly_pay_amount'], 2, '.', ',')) ?></td>
              <td><?= e(number_format((float)($row['gross_amount'] ?? 0), 2, '.', ',')) ?></td>
              <td><?= e(number_format((float)($row['net_amount'] ?? 0), 2, '.', ',')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
  <div class="muted" style="margin-top:8px">Deferred placeholders: generalized overtime pay formulas, rounding rules, holiday premiums, helper classification pay effects, and any payroll math still trapped only in the workbook VBA or unexplained sheets. Imported monthly salary and fixed-pay profile data is now supported where source values are available.</div>
</section>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
