<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\Payroll\Controllers\PayrollController;

require_once __DIR__ . '/Controllers/PayrollController.php';
require_once __DIR__ . '/Services/PayrollParityValidationService.php';
require_once __DIR__ . '/Services/PayrollScaffoldService.php';

$router->get('/apps/sbaio/payroll', function () use ($view) {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    PayrollController::index($view);
    return null;
});

$router->post('/apps/sbaio/payroll/create-run', function () {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    PayrollController::createRun();
    return null;
});

$router->get('/apps/sbaio/payroll/parity', function () use ($view) {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    PayrollController::parity($view);
    return null;
});
