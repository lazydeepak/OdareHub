<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$rows = is_array($rows ?? null) ? $rows : [];
$staffRows = is_array($staffRows ?? null) ? $staffRows : [];
$suiteActions = [
  ['label' => t('nav.sbaio_dashboard'), 'url' => '/apps/sbaio'],
  ['label' => t('nav.sbaio_tasks'), 'url' => '/apps/sbaio/tasks'],
];
$suiteLinks = [['label' => 'Records', 'value' => (string)count($rows)]];
$moduleFilters = [
  ['label' => 'View', 'value' => 'Recent notices'],
  ['label' => 'Scope', 'value' => 'Active communication feed'],
];
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_intro.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_feedback.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_filters.php';
?>
<section class="card">
  <div class="card" style="margin-bottom:14px">
    <h3 style="margin-top:0">Publish Notice</h3>
    <div class="muted" style="margin-bottom:10px">Use notices for payroll-close reminders, approval follow-up, and missing punch alerts.</div>
    <form method="post" action="/apps/sbaio/notices/create" class="grid" style="grid-template-columns:repeat(4,minmax(0,1fr));gap:10px">
      <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
      <label>Title<input type="text" name="title" required></label>
      <label>Type<input type="text" name="notice_type" placeholder="reminder, alert, close"></label>
      <label>Target Period<input type="text" name="target_period" placeholder="2026-04"></label>
      <label>Level<input type="text" name="notice_level" value="info"></label>
      <label>Related Staff
        <select name="related_staff_id">
          <option value="">None</option>
          <?php foreach ($staffRows as $staff): ?>
            <option value="<?= (int)($staff['id'] ?? 0) ?>"><?= e(trim((string)($staff['employee_code'] ?? '') . ' ' . (string)($staff['full_name'] ?? ''))) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label><input type="checkbox" name="requires_ack" value="1"> Requires Acknowledgement</label>
      <label><input type="checkbox" name="is_active" value="1" checked> Active</label>
      <label style="grid-column:1 / -1">Body<textarea name="body" rows="4"></textarea></label>
      <div style="grid-column:1 / -1">
        <button class="btn btn-primary" type="submit">Create Notice</button>
      </div>
    </form>
  </div>
  <?php if ($rows === []): ?>
    <?php
    $emptyTitle = 'Notice Feed';
    $emptyMessage = 'No notices yet. This module is ready for payroll close reminders, approval reminders, and missing punch alerts.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <h3 style="margin-top:0">Notice Feed</h3>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Title</th><th>Type</th><th>Target Period</th><th>Level</th><th>Ack</th><th>Active</th><th>Created</th></tr></thead>
        <tbody>
          <?php foreach ($rows as $row): ?>
            <tr>
              <td><?= e((string)($row['title'] ?? '')) ?></td>
              <td><?= e((string)($row['notice_type'] ?? '')) ?></td>
              <td><?= e((string)($row['target_period'] ?? '')) ?></td>
              <td><?= e((string)($row['notice_level'] ?? '')) ?></td>
              <td><?= !empty($row['requires_ack']) ? 'Yes' : 'No' ?></td>
              <td><?= !empty($row['is_active']) ? 'Yes' : 'No' ?></td>
              <td><?= e((string)($row['created_at'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
