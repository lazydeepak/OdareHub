<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\Notices\Controllers\NoticesController;

require_once __DIR__ . '/Controllers/NoticesController.php';

$router->get('/apps/sbaio/notices', function () use ($view) {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    NoticesController::index($view);
    return null;
});

$router->post('/apps/sbaio/notices/create', function () {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    NoticesController::create();
    return null;
});
