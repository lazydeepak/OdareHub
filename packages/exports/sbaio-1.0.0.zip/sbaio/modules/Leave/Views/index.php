<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$staffRows = is_array($staffRows ?? null) ? $staffRows : [];
$leaveRows = is_array($leaveRows ?? null) ? $leaveRows : [];
$holidayRows = is_array($holidayRows ?? null) ? $holidayRows : [];
$suiteActions = [
  ['label' => t('nav.sbaio_dashboard'), 'url' => '/apps/sbaio'],
  ['label' => t('nav.sbaio_schedules'), 'url' => '/apps/sbaio/schedules'],
  ['label' => t('nav.sbaio_timecards'), 'url' => '/apps/sbaio/timecards'],
];
$suiteLinks = [
  ['label' => 'Leave Requests', 'value' => (string)count($leaveRows)],
  ['label' => 'Holiday Entries', 'value' => (string)count($holidayRows)],
];
$moduleFilters = [
  ['label' => 'View', 'value' => 'Leave + holiday calendar'],
  ['label' => 'Scope', 'value' => 'Attendance and timecard support'],
];
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_intro.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_feedback.php';
require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_filters.php';
?>
<section class="card">
  <div class="grid" style="grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-bottom:14px">
    <section class="card">
      <h3 style="margin-top:0">Add Leave Request</h3>
      <div class="muted" style="margin-bottom:10px">Track approved or pending leave that should affect attendance interpretation and period generation.</div>
      <form method="post" action="/apps/sbaio/leave/create" class="grid" style="grid-template-columns:repeat(2,minmax(0,1fr));gap:10px">
        <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
        <label>Staff
          <select name="staff_id" required>
            <option value="">Select staff</option>
            <?php foreach ($staffRows as $staff): ?>
              <option value="<?= (int)($staff['id'] ?? 0) ?>"><?= e(trim((string)($staff['employee_code'] ?? '') . ' ' . (string)($staff['full_name'] ?? ''))) ?></option>
            <?php endforeach; ?>
          </select>
        </label>
        <label>Leave Type<input type="text" name="leave_type" value="leave"></label>
        <label>Legacy Name Ref<input type="text" name="legacy_name_ref"></label>
        <label>Leave Code<input type="text" name="leave_code"></label>
        <label>Start Date<input type="date" name="start_date" required></label>
        <label>End Date<input type="date" name="end_date" required></label>
        <label>Partial Day Unit<input type="text" name="partial_day_unit" placeholder="half_day"></label>
        <label>Leave Status<input type="text" name="leave_status" value="approved"></label>
        <label>Notes<input type="text" name="notes"></label>
        <div style="grid-column:1 / -1"><button class="btn btn-primary" type="submit">Save Leave</button></div>
      </form>
    </section>
    <section class="card">
      <h3 style="margin-top:0">Add Holiday Calendar Entry</h3>
      <div class="muted" style="margin-bottom:10px">Maintain public holidays and closed-day definitions separately from staff leave.</div>
      <form method="post" action="/apps/sbaio/leave/holiday" class="grid" style="grid-template-columns:repeat(2,minmax(0,1fr));gap:10px">
        <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
        <label>Date<input type="date" name="holiday_date" required></label>
        <label>Name<input type="text" name="holiday_name" required></label>
        <label>Holiday Type<input type="text" name="holiday_type" value="public_holiday"></label>
        <label>Holiday Code<input type="text" name="holiday_code"></label>
        <label>Notes<input type="text" name="notes"></label>
        <label style="display:flex;align-items:center;gap:8px;margin-top:24px"><input type="checkbox" name="is_closed_day" value="1"> Closed Day</label>
        <label style="display:flex;align-items:center;gap:8px;margin-top:24px"><input type="checkbox" name="is_active" value="1" checked> Active</label>
        <div style="grid-column:1 / -1"><button class="btn btn-primary" type="submit">Save Holiday</button></div>
      </form>
    </section>
  </div>
  <h3 style="margin-top:0">Leave Requests</h3>
  <?php if ($leaveRows === []): ?>
    <?php
    $emptyTitle = 'Leave Requests';
    $emptyMessage = 'No leave requests yet. This module is ready for approved leave periods that feed attendance interpretation.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Start</th><th>End</th><th>Staff</th><th>Legacy Name Ref</th><th>Code</th><th>Type</th><th>Partial</th><th>Status</th><th>Approved At</th></tr></thead>
        <tbody>
          <?php foreach ($leaveRows as $row): ?>
            <tr>
              <td><?= e((string)($row['start_date'] ?? '')) ?></td>
              <td><?= e((string)($row['end_date'] ?? '')) ?></td>
              <td><?= e((string)($row['full_name'] ?? '')) ?></td>
              <td><?= e((string)($row['legacy_name_ref'] ?? '')) ?></td>
              <td><?= e((string)($row['leave_code'] ?? '')) ?></td>
              <td><?= e((string)($row['leave_type'] ?? '')) ?></td>
              <td><?= e((string)($row['partial_day_unit'] ?? '')) ?></td>
              <td><?= e((string)($row['leave_status'] ?? '')) ?></td>
              <td><?= e((string)($row['approved_at'] ?? '')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
  <h3>Holiday Calendar</h3>
  <?php if ($holidayRows === []): ?>
    <?php
    $emptyTitle = 'Holiday Calendar';
    $emptyMessage = 'No holidays yet. Public holidays and off-day definitions can be tracked here.';
    require APP_ROOT . '/apps/SBAIO/Views/partials/module_page_empty.php';
    ?>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Date</th><th>Name</th><th>Type</th><th>Code</th><th>Closed Day</th><th>Notes</th><th>Active</th></tr></thead>
        <tbody>
          <?php foreach ($holidayRows as $row): ?>
            <tr>
              <td><?= e((string)($row['holiday_date'] ?? '')) ?></td>
              <td><?= e((string)($row['holiday_name'] ?? '')) ?></td>
              <td><?= e((string)($row['holiday_type'] ?? '')) ?></td>
              <td><?= e((string)($row['holiday_code'] ?? '')) ?></td>
              <td><?= !empty($row['is_closed_day']) ? 'Yes' : 'No' ?></td>
              <td><?= e((string)($row['notes'] ?? '')) ?></td>
              <td><?= !empty($row['is_active']) ? 'Yes' : 'No' ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
