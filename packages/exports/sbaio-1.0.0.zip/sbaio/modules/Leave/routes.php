<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\Leave\Controllers\LeaveController;

require_once __DIR__ . '/Controllers/LeaveController.php';

$router->get('/apps/sbaio/leave', function () use ($view) {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    LeaveController::index($view);
    return null;
});

$router->post('/apps/sbaio/leave/create', function () {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    LeaveController::createLeave();
    return null;
});

$router->post('/apps/sbaio/leave/holiday', function () {
    Auth::requireAppAccess('sbaio');
    Auth::bootSession();
    LeaveController::createHoliday();
    return null;
});
