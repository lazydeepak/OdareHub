<?php
declare(strict_types=1);

use App\Core\Auth;
use Apps\Manufacturing\Controllers\DemandController;

$router->get('/manufacturing/demands', function() use ($view) {
    Auth::requireRouteAccess('/manufacturing/demands');
    DemandController::index($view);
    return null;
});

$router->post('/manufacturing/demands/recalculate', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    DemandController::recalculate($_POST);
    header('Location: /manufacturing/demands');
    exit;
});

$router->post('/manufacturing/demands/adjust', function() {
    Auth::requireRouteAccess('/manufacturing/demands', 'POST');
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    DemandController::adjust($_POST);
    header('Location: /manufacturing/demands');
    exit;
});

$router->post('/manufacturing/demands/approve', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    DemandController::approve($_POST);
    header('Location: /manufacturing/demands');
    exit;
});

$router->get('/manufacturing/demands/debug-decisions', function() {
    Auth::requireRouteAccess('/manufacturing/demands');
    DemandController::debugDecisions();
    return null;
});

$router->get('/manufacturing/demands/debug-work-buckets', function() {
    Auth::requireRouteAccess('/manufacturing/demands');
    DemandController::debugWorkBuckets();
    return null;
});

$router->get('/manufacturing/demands/debug-generate-work-executions', function() {
    Auth::requireRouteAccess('/manufacturing/demands');
    DemandController::debugGenerateWorkExecutions();
    return null;
});

$router->get('/manufacturing/demands/debug-generate-upstream-supply', function() {
    Auth::requireRouteAccess('/manufacturing/demands');
    DemandController::debugGenerateUpstreamSupply();
    return null;
});
