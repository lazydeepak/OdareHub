<?php
declare(strict_types=1);

use App\Core\Auth;
use Apps\Manufacturing\Controllers\DemandDashboardController;

$router->get('/manufacturing/demand-dashboard', function () use ($view) {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    DemandDashboardController::index($view);
    return null;
});
