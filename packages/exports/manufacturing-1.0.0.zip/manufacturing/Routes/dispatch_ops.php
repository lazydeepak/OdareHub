<?php
declare(strict_types=1);

use App\Core\Auth;
use Apps\Manufacturing\Controllers\DispatchOpsController;

$router->get('/manufacturing/dispatch-ops', function() use ($view) {
    Auth::requireRouteAccess('/manufacturing/dispatch-ops');
    DispatchOpsController::index($view);
    return null;
});

$router->get('/manufacturing/dispatch-queue', function() {
    header('Location: /manufacturing/dispatch-ops', true, 302);
    exit;
});

$router->get('/manufacturing/dispatch-ops/preparation', function() use ($view) {
    Auth::requireRouteAccess('/manufacturing/dispatch-ops/preparation');
    DispatchOpsController::preparationForm($view);
    return null;
});

$router->post('/manufacturing/dispatch-ops/ready', function() {
    Auth::requireRouteAccess('/manufacturing/dispatch-ops', 'POST');
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    DispatchOpsController::markReady($_POST);
    header('Location: /manufacturing/dispatch-ops');
    exit;
});

$router->post('/manufacturing/dispatch-ops/prepare', function() {
    Auth::requireRouteAccess('/manufacturing/dispatch-ops', 'POST');
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    DispatchOpsController::prepare($_POST);
    header('Location: /manufacturing/dispatch-ops');
    exit;
});

$router->post('/manufacturing/dispatch-ops/preparation', function() {
    Auth::requireRouteAccess('/manufacturing/dispatch-ops/preparation', 'POST');
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    DispatchOpsController::savePreparation($_POST);
    $redirect = '/manufacturing/dispatch-ops/preparation';
    $params = [];
    $dispatchDate = trim((string)($_POST['dispatch_date'] ?? ''));
    $productId = (int)($_POST['product_id'] ?? 0);
    $dailyOrderId = (int)($_POST['daily_order_id'] ?? 0);
    if ($dispatchDate !== '') {
        $params['dispatch_date'] = $dispatchDate;
    }
    if ($productId > 0) {
        $params['product_id'] = (string)$productId;
    }
    if ($dailyOrderId > 0) {
        $params['daily_order_id'] = (string)$dailyOrderId;
    }
    if ($params !== []) {
        $redirect .= '?' . http_build_query($params);
    }
    header('Location: ' . $redirect);
    exit;
});

$router->post('/manufacturing/dispatch-ops/complete', function() {
    Auth::requireRouteAccess('/manufacturing/dispatch-ops', 'POST');
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    DispatchOpsController::complete($_POST);
    header('Location: /manufacturing/dispatch-ops');
    exit;
});
