<?php
declare(strict_types=1);

use App\Core\Auth;
use Apps\Manufacturing\Controllers\StageTransitionController;

$router->get('/manufacturing/stage-board', function () use ($view) {
    StageTransitionController::boardAction($view);
});

$router->post('/manufacturing/stage-release', function () {
    StageTransitionController::releaseAction();
});

$router->post('/manufacturing/stage-override', function () {
    StageTransitionController::overrideAction();
});
