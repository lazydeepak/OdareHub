<?php
declare(strict_types=1);

use App\Core\Auth;
use Apps\Manufacturing\Controllers\DailyOrdersController;

$router->get('/daily-orders', function() use ($view) {
    acl_require('daily_orders.index.view', '/daily-orders');
    DailyOrdersController::index($view);
    return null;
});

$router->get('/daily-orders/360', function() use ($view) {
    acl_require('daily_orders.360.view', '/daily-orders/360?id=' . (int)($_GET['id'] ?? 0));

    DailyOrdersController::order360($view, (int)($_GET['id'] ?? 0));
    return null;
});

$router->get('/daily-orders/add', function() use ($view) {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    DailyOrdersController::addForm($view);
    return null;
});

$router->get('/daily-orders/import', function() use ($view) {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    DailyOrdersController::importForm($view);
    return null;
});

$router->post('/daily-orders/import', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    DailyOrdersController::importUpload($_FILES['import_file'] ?? null);
    header('Location: /daily-orders');
    exit;
});

$router->post('/daily-orders/add', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    DailyOrdersController::create($_POST);
    header('Location: /daily-orders');
    exit;
});

$router->get('/daily-orders/edit', function() use ($view) {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    DailyOrdersController::editForm($view, (int)($_GET['id'] ?? 0));
    return null;
});

$router->post('/daily-orders/edit', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    DailyOrdersController::update($_POST);
    header('Location: /daily-orders');
    exit;
});

$router->post('/daily-orders/delete', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    DailyOrdersController::delete((int)($_POST['id'] ?? 0));
    header('Location: /daily-orders');
    exit;
});
