<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\Base\Controllers\RoleDashboardsController;
use Plugins\Base\Services\SupervisorCockpitService;

$roleDashboardsControllerPath = APP_ROOT . '/plugins/Base/Controllers/RoleDashboardsController.php';
if (!class_exists(RoleDashboardsController::class) && is_file($roleDashboardsControllerPath)) {
    require_once $roleDashboardsControllerPath;
}

$supervisorCockpitServicePath = APP_ROOT . '/plugins/Base/Services/SupervisorCockpitService.php';
if (!class_exists(SupervisorCockpitService::class) && is_file($supervisorCockpitServicePath)) {
    require_once $supervisorCockpitServicePath;
}

// Canonical app-owned dashboard surfaces.
$router->get('/manufacturing/cockpit', function () use ($view) {
    acl_require('ops.cockpit.view', '/ops/cockpit');
    $user = Auth::user();

    $cockpit = SupervisorCockpitService::build($_GET, $user);
    $view->render('Base::supervisor_cockpit.php', [
        'pageTitle' => 'Supervisor / GM Cockpit',
        'cockpit' => $cockpit,
    ]);
    return null;
});

$router->get('/manufacturing/production-dashboard', function () use ($view) {
    RoleDashboardsController::render($view, 'production_leader');
    return null;
});

$router->get('/manufacturing/assembly-dashboard', function () use ($view) {
    RoleDashboardsController::render($view, 'assembly_leader');
    return null;
});

$router->get('/manufacturing/qc-dashboard', function () use ($view) {
    RoleDashboardsController::render($view, 'qc_leader');
    return null;
});

$router->get('/manufacturing/dispatch-dashboard', function () use ($view) {
    RoleDashboardsController::render($view, 'dispatch_leader');
    return null;
});

$router->get('/ops/cockpit', function () {
    header('Location: /manufacturing/cockpit', true, 302);
    return null;
});

$router->get('/ops/production-dashboard', function () {
    header('Location: /manufacturing/production-dashboard', true, 302);
    return null;
});

$router->get('/ops/assembly-dashboard', function () {
    header('Location: /manufacturing/assembly-dashboard', true, 302);
    return null;
});

$router->get('/ops/qc-dashboard', function () {
    header('Location: /manufacturing/qc-dashboard', true, 302);
    return null;
});

$router->get('/ops/dispatch-dashboard', function () {
    header('Location: /manufacturing/dispatch-dashboard', true, 302);
    return null;
});

$router->get('/ops/production-leader-dashboard', function () {
    header('Location: /manufacturing/production-dashboard', true, 302);
    return null;
});

$router->get('/ops/assembly-leader-dashboard', function () {
    header('Location: /manufacturing/assembly-dashboard', true, 302);
    return null;
});

$router->get('/ops/qc-leader-dashboard', function () {
    header('Location: /manufacturing/qc-dashboard', true, 302);
    return null;
});

$router->get('/ops/dispatch-leader-dashboard', function () {
    header('Location: /manufacturing/dispatch-dashboard', true, 302);
    return null;
});
