<?php
declare(strict_types=1);

use App\Core\Auth;
use Apps\Manufacturing\Controllers\DemandExecutionController;

$router->get('/apps/manufacturing', function() use ($view) {
    Auth::bootSession();
    DemandExecutionController::dashboard($view);
    return null;
});

$router->get('/manufacturing/qc-queue', function() use ($view) {
    // Keep ACL bound to existing route key for backward compatibility.
    Auth::requireRouteAccess('/manufacturing/qc-demand-queue');
    DemandExecutionController::qcQueue($view);
    return null;
});

$router->get('/manufacturing/qc-demand-queue', function() {
    header('Location: /manufacturing/qc-queue', true, 302);
    exit;
});

$router->get('/manufacturing/assembly-queue', function() use ($view) {
    // Keep ACL bound to existing route key for backward compatibility.
    Auth::requireRouteAccess('/manufacturing/assembly-demand-queue');
    DemandExecutionController::assemblyQueue($view);
    return null;
});

$router->get('/manufacturing/assembly-demand-queue', function() {
    header('Location: /manufacturing/assembly-queue', true, 302);
    exit;
});

$router->get('/manufacturing/execution-dashboard', function() {
    // Canonical execution dashboard lives at /apps/manufacturing
    header('Location: /apps/manufacturing', true, 302);
    exit;
});
