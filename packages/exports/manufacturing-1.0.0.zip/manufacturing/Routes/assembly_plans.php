<?php
declare(strict_types=1);

use App\Core\Auth;
use Apps\Manufacturing\Controllers\AssemblyPlansController;
use Apps\Manufacturing\Services\AssemblyPlanService;

$router->get('/manufacturing/assembly-plans', function() use ($view) {
    Auth::requireRouteAccess('/manufacturing/assembly-plans');
    AssemblyPlanService::requireAvailability();
    AssemblyPlansController::index($view);
    return null;
});

$router->get('/manufacturing/assembly-workbench', function() {
    header('Location: /manufacturing/assembly-plans?only_open=1');
    exit;
});

$router->get('/manufacturing/assembly-plans/detail', function() use ($view) {
    $id = (int)($_GET['id'] ?? 0);
    Auth::requireRouteAccess('/manufacturing/assembly-plans/detail?id=' . $id);
    AssemblyPlanService::requireAvailability();
    AssemblyPlansController::detail($view, (int)($_GET['id'] ?? 0));
    return null;
});

$router->post('/manufacturing/assembly-plans/update', function() {
    Auth::requireRouteAccess('/manufacturing/assembly-plans', 'POST');
    AssemblyPlanService::requireAvailability();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    $id = (int)($_POST['id'] ?? 0);
    AssemblyPlansController::update($_POST);
    header('Location: /manufacturing/assembly-plans/detail?id=' . $id);
    exit;
});

$router->post('/manufacturing/assembly-plans/approve', function() {
    Auth::requireAppAccess('manufacturing');
    AssemblyPlanService::requireAvailability();
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    $id = (int)($_POST['id'] ?? 0);
    AssemblyPlansController::approve($_POST);
    header('Location: /manufacturing/assembly-plans/detail?id=' . $id);
    exit;
});

$router->post('/manufacturing/assembly-plans/execution-log', function() {
    Auth::requireRouteAccess('/manufacturing/assembly-plans', 'POST');
    AssemblyPlanService::requireAvailability();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    $planId = (int)($_POST['assembly_plan_id'] ?? 0);
    AssemblyPlansController::addExecution($_POST);
    header('Location: /manufacturing/assembly-plans/detail?id=' . $planId);
    exit;
});

$router->post('/manufacturing/assembly-plans/execution-approve', function() {
    Auth::requireAppAccess('manufacturing');
    AssemblyPlanService::requireAvailability();
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    $planId = (int)($_POST['assembly_plan_id'] ?? 0);
    AssemblyPlansController::approveExecution($_POST);
    header('Location: /manufacturing/assembly-plans/detail?id=' . $planId);
    exit;
});

$router->post('/manufacturing/assembly-plans/transition', function() {
    Auth::requireRouteAccess('/manufacturing/assembly-plans', 'POST');
    AssemblyPlanService::requireAvailability();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    $planId = (int)($_POST['id'] ?? 0);
    AssemblyPlansController::transition($_POST);
    header('Location: /manufacturing/assembly-plans/detail?id=' . $planId);
    exit;
});
