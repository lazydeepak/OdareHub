<?php
declare(strict_types=1);

use App\Core\Auth;
use Apps\Manufacturing\Services\QueueBoardService;

$router->get('/manufacturing/production-queue', function() use ($view) {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    QueueBoardService::render($view);
    return null;
});

// Legacy route alias for backward compatibility.
$router->get('/production-queue', function() {
    header('Location: /manufacturing/production-queue', true, 302);
    exit;
});
