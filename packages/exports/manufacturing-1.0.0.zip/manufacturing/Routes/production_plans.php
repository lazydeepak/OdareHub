<?php
declare(strict_types=1);

use App\Core\Auth;
use Apps\Manufacturing\Controllers\ProductionPlansController;
use Apps\Manufacturing\Services\QueueBoardService;

$router->get('/production-plans', function() use ($view) {
    Auth::requireRouteAccess('/production-plans');
    ProductionPlansController::index($view);
    return null;
});

$router->get('/production-plans/add', function() use ($view) {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    ProductionPlansController::addForm($view);
    return null;
});

$router->post('/production-plans/start-draft', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    ProductionPlansController::createDraft($_POST);
    return null;
});

$router->post('/production-plans/add', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    ProductionPlansController::create($_POST);
    header('Location: /production-plans');
    exit;
});

$router->get('/production-plans/edit', function() use ($view) {
    Auth::requireRouteAccess('/production-plans/edit?id=' . (int)($_GET['id'] ?? 0));
    ProductionPlansController::editForm($view, (int)($_GET['id'] ?? 0));
    return null;
});

$router->post('/production-plans/edit', function() {
    Auth::requireRouteAccess('/production-plans', 'POST');
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    ProductionPlansController::update($_POST);
    header('Location: /production-plans');
    exit;
});

$router->post('/production-plans/approval-action', function() {
    acl_require_any([
        'workflow.production_plan.submit',
        'workflow.production_plan.approve',
        'workflow.production_plan.reopen',
    ], '/production-plans');

    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    ProductionPlansController::approvalAction($_POST);
    return null;
});

$router->post('/production-plans/delete', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    ProductionPlansController::delete((int)($_POST['id'] ?? 0));
    header('Location: /production-plans');
    exit;
});

$router->get('/production-plans/print-pdf', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    ProductionPlansController::printPdf((int)($_GET['id'] ?? 0), false);
});

$router->get('/production-plans/download-pdf', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    ProductionPlansController::printPdf((int)($_GET['id'] ?? 0), true);
});

$router->get('/production-plans/print-next-two-weeks', function() use ($view) {
    Auth::requireRouteAccess('/production-plans/print-next-two-weeks');
    ProductionPlansController::printNextTwoWeeks($view);
    return null;
});

$router->get('/production-plans/print-next-two-weeks-pdf', function() {
    Auth::requireRouteAccess('/production-plans/print-next-two-weeks-pdf');
    ProductionPlansController::printNextTwoWeeksPdf();
    return null;
});

$router->get('/production-plans/queue', function() use ($view) {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();

    $queueActive = ((string)(\App\Core\DB::fetchOne("SELECT status FROM core_apps WHERE app_key='manufacturing' LIMIT 1")['status'] ?? '')) === 'enabled';
    if ($queueActive) {
        $qs = $_SERVER['QUERY_STRING'] ?? '';
        header('Location: /manufacturing/production-queue' . ($qs !== '' ? ('?' . $qs) : ''));
        exit;
    }

    QueueBoardService::render($view, 'manufacturing::production_plans/queue.php');
    return null;
});
