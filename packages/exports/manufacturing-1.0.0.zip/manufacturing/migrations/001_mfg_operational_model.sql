CREATE TABLE IF NOT EXISTS mfg_part_demands (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    demand_date DATE NOT NULL,
    demand_type ENUM('production','qc','assembly') NOT NULL,
    system_qty DECIMAL(14,2) NOT NULL DEFAULT 0,
    adjusted_qty DECIMAL(14,2) NULL,
    approved_qty DECIMAL(14,2) NULL,
    adjustment_note TEXT NULL,
    adjusted_by VARCHAR(190) NULL,
    approved_by VARCHAR(190) NULL,
    approved_at DATETIME NULL,
    source_summary_json JSON NULL,
    status ENUM('calculated','adjusted','approved') NOT NULL DEFAULT 'calculated',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_mfg_demand_key (product_id, demand_date, demand_type),
    KEY idx_mfg_demands_date (demand_date),
    KEY idx_mfg_demands_type (demand_type),
    KEY idx_mfg_demands_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE products ADD COLUMN production_source ENUM('in_house','third_party') NOT NULL DEFAULT 'in_house';
ALTER TABLE products ADD COLUMN requires_qc TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE products ADD COLUMN requires_assembly TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE products ADD COLUMN dispatch_as_is TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE products ADD COLUMN delivery_flow ENUM('company_to_destination','third_party_to_destination','third_party_to_company_to_destination') NOT NULL DEFAULT 'company_to_destination';
ALTER TABLE products ADD COLUMN activity_type ENUM('active','passive') NOT NULL DEFAULT 'active';
ALTER TABLE products ADD INDEX idx_products_production_source (production_source);
ALTER TABLE products ADD INDEX idx_products_processing_flags (requires_qc, requires_assembly, dispatch_as_is);
ALTER TABLE products ADD INDEX idx_products_activity_type (activity_type);

ALTER TABLE dispatch_entries ADD COLUMN cases_count INT NOT NULL DEFAULT 0;
ALTER TABLE dispatch_entries ADD COLUMN pallets_count INT NOT NULL DEFAULT 0;
ALTER TABLE dispatch_entries ADD COLUMN dispatch_mode ENUM('in_house_dispatch','third_party_dispatch','company_origin_dispatch','third_party_direct_dispatch','third_party_to_company_then_destination') NOT NULL DEFAULT 'company_origin_dispatch';
ALTER TABLE dispatch_entries ADD COLUMN delivery_flow ENUM('company_to_destination','third_party_to_destination','third_party_to_company_to_destination') NOT NULL DEFAULT 'company_to_destination';
ALTER TABLE dispatch_entries ADD COLUMN source_type ENUM('in_house','third_party') NOT NULL DEFAULT 'in_house';
ALTER TABLE dispatch_entries ADD COLUMN prepared_by VARCHAR(190) NULL;
ALTER TABLE dispatch_entries ADD COLUMN prepared_at DATETIME NULL;
ALTER TABLE dispatch_entries ADD COLUMN dispatch_completed_by VARCHAR(190) NULL;
ALTER TABLE dispatch_entries ADD COLUMN dispatch_completed_at DATETIME NULL;
ALTER TABLE dispatch_entries ADD COLUMN completion_status ENUM('draft','ready','prepared','completed') NOT NULL DEFAULT 'draft';
ALTER TABLE dispatch_entries ADD COLUMN third_party_reference VARCHAR(190) NULL;
ALTER TABLE dispatch_entries ADD INDEX idx_dispatch_entries_completion_status (completion_status);
ALTER TABLE dispatch_entries ADD INDEX idx_dispatch_entries_mode (dispatch_mode);
ALTER TABLE dispatch_entries ADD INDEX idx_dispatch_entries_source_type (source_type);