-- Migration 004: Add 'packaging' stage to mfg_stage_readiness ENUM
-- Stage flow updated to: Production → Assembly → QC → Packaging → Dispatch
-- Packaging uses dispatch_entries (completion_status: ready=started, prepared=packaged, completed=dispatched)
ALTER TABLE mfg_stage_readiness
    MODIFY COLUMN stage ENUM('production','assembly','qc','packaging','dispatch') NOT NULL;
