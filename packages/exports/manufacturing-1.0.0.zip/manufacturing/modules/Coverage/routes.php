<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\Coverage\Controllers\CoverageController;

require_once __DIR__ . '/Controllers/CoverageController.php';

$router->get('/manufacturing/coverage', function () use ($view) {
    Auth::requireRouteAccess('/manufacturing/coverage');
    CoverageController::index($view);
    return null;
});
