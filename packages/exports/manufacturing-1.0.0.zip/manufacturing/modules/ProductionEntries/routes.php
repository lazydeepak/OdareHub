<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\ProductionEntries\Controllers\ProductionEntriesController;

require_once __DIR__ . '/Controllers/ProductionEntriesController.php';

$router->get('/production-entries', function() use ($view) {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    ProductionEntriesController::index($view);
    return null;
});

$router->get('/production-entries/add', function() use ($view) {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    ProductionEntriesController::addForm($view);
    return null;
});

$router->post('/production-entries/add', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    ProductionEntriesController::create($_POST);
    header('Location: /production-entries');
    exit;
});

$router->get('/production-entries/edit', function() use ($view) {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    ProductionEntriesController::editForm($view, (int)($_GET['id'] ?? 0));
    return null;
});

$router->post('/production-entries/edit', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    ProductionEntriesController::update($_POST);
    header('Location: /production-entries');
    exit;
});

$router->post('/production-entries/delete', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    ProductionEntriesController::delete((int)($_POST['id'] ?? 0));
    header('Location: /production-entries');
    exit;
});
