<?php
return [
  ['key' => 'ipm.root', 'label' => 'IPM', 'url' => null, 'parent' => null, 'order' => 30, 'perm' => null],
  ['key' => 'ipm.production_entries', 'label' => 'Production Entries', 'url' => '/production-entries', 'parent' => 'ipm.root', 'order' => 70, 'perm' => null],
];
