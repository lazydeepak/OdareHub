<?php
return [
  ['key' => 'ipm.root', 'label' => 'IPM', 'url' => null, 'parent' => null, 'order' => 30, 'perm' => null],
  ['key' => 'ipm.qc_plans', 'label' => 'QC Plans', 'url' => '/qc-plans', 'parent' => 'ipm.root', 'order' => 80, 'perm' => null],
];
