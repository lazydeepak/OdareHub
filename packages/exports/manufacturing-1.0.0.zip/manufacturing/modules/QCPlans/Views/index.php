<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<style>
	.qc-filter-row input,
	.qc-filter-row select {
		min-height: 38px;
		width: 100%;
		max-width: 100%;
	}

	.qc-filter-row .btn {
		min-height: 38px;
		padding: 8px 12px;
	}

	.qc-filter-date {
		min-width: 155px;
	}

	.qc-filter-priority {
		min-width: 135px;
	}

	.qc-filter-status {
		min-width: 200px;
	}
</style>
<div class="card"><div class="row" style="justify-content:space-between;align-items:flex-end;gap:10px"><div><h2 style="margin:0"><?= e(t('module.qc_plans.title')) ?></h2><div class="muted"><?= e(t('module.qc_plans.subtitle')) ?></div><div class="muted" style="margin-top:4px">Workflow: System Generated -> QC Verification/Adjustment -> Higher Authority Approval</div></div><div class="row" style="gap:8px;align-items:flex-end;flex-wrap:wrap"><form method="get" action="/qc-plans/print-pdf" target="_blank" class="row" style="gap:8px;align-items:flex-end;margin:0"><div><label class="muted" style="display:block;margin-bottom:6px">From</label><input type="date" name="from_date" value="<?= e((string)($print_from_date ?? '')) ?>"></div><div><label class="muted" style="display:block;margin-bottom:6px">To</label><input type="date" name="to_date" value="<?= e((string)($print_to_date ?? '')) ?>"></div><button class="btn" type="submit">Print</button></form><a class="btn ok" href="/qc-plans/add"><?= e(t('module.qc_plans.add')) ?></a></div></div></div>
<?php if (!empty($flash ?? '')): ?><div class="card" style="border-color:#1d4d2f;background:rgba(0,255,140,.06)"><?= e((string)$flash) ?></div><?php endif; ?>
<?php if (!empty($error ?? '')): ?><div class="card" style="border-color:#5b1d2b;background:rgba(255,0,0,.06)"><?= e((string)$error) ?></div><?php endif; ?>
<div class="card"><form method="get" action="/qc-plans" class="row qc-filter-row" style="align-items:end;gap:8px"><div class="qc-filter-date" style="flex:0 0 auto"><label class="muted" style="display:block;margin-bottom:6px"><?= e(t('module.qc_plans.plan_date')) ?></label><input type="date" name="plan_date" value="<?= e((string)$plan_date) ?>"></div><div class="qc-filter-priority" style="flex:0 0 auto"><label class="muted" style="display:block;margin-bottom:6px"><?= e(t('common.priority')) ?></label><select name="priority"><option value=""><?= e(t('common.all')) ?></option><option value="Critical" <?= ((string)$priority === 'Critical') ? 'selected' : '' ?>>Critical</option><option value="High" <?= ((string)$priority === 'High') ? 'selected' : '' ?>>High</option><option value="Medium" <?= ((string)$priority === 'Medium') ? 'selected' : '' ?>>Medium</option><option value="Normal" <?= ((string)$priority === 'Normal') ? 'selected' : '' ?>>Normal</option><option value="Low" <?= ((string)$priority === 'Low') ? 'selected' : '' ?>>Low</option></select></div><div class="qc-filter-status" style="flex:0 0 auto"><label class="muted" style="display:block;margin-bottom:6px"><?= e(t('common.status')) ?></label><select name="status"><option value=""><?= e(t('common.all')) ?></option><?php foreach (($status_options ?? []) as $opt): ?><option value="<?= e((string)$opt) ?>" <?= ((string)$status === (string)$opt) ? 'selected' : '' ?>><?= e((string)$opt) ?></option><?php endforeach; ?></select></div><div class="row" style="gap:6px;flex:0 0 auto"><button class="btn" type="submit"><?= e(t('common.filter')) ?></button><a class="btn" href="/qc-plans"><?= e(t('common.reset')) ?></a></div></form></div>
<div class="card"><div class="table-wrap"><table><thead><tr><th><?= e(t('common.id')) ?></th><th><?= e(t('common.date')) ?></th><th><?= e(t('common.required_date')) ?></th><th><?= e(t('common.part')) ?></th><th><?= e(t('module.pre_orders.planned_qty')) ?></th><th><?= e(t('common.est_minutes')) ?></th><th><?= e(t('common.priority')) ?></th><th><?= e(t('common.status')) ?></th><th>Assigned to</th><th>Verified by</th><th>Approved by</th><th><?= e(t('common.actions')) ?></th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr><td><?= (int)$r['id'] ?></td><td><?= e((string)$r['plan_date']) ?></td><td><?= e((string)($r['required_date'] ?? '')) ?></td><td><?= e((string)$r['parts_name']) ?> <span class="muted">(<?= e((string)$r['parts_number']) ?>)</span></td><td><?= e((string)$r['planned_qty']) ?></td><td><?= (int)$r['estimated_time_minutes'] ?></td><td><?= e((string)$r['priority']) ?></td><td><?= e((string)$r['status']) ?></td><td><?= e((string)($r['assigned_to'] ?? '-')) ?></td><td><?= e((string)($r['verified_by'] ?? '-')) ?></td><td><?= e((string)($r['approved_by'] ?? '-')) ?></td><td><div class="row"><a class="btn" href="/products/360?id=<?= (int)$r['product_id'] ?>">Part 360</a><a class="btn" href="/qc-plans/edit?id=<?= (int)$r['id'] ?>"><?= e(t('common.edit')) ?></a><form method="post" action="/qc-plans/delete" onsubmit="return confirm('<?= e(t('module.qc_plans.delete_confirm')) ?>');" style="margin:0"><input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn danger" type="submit"><?= e(t('common.delete')) ?></button></form></div></td></tr><?php endforeach; ?>
<?php if (empty($rows)): ?><tr><td colspan="12" class="muted"><?= e(t('module.qc_plans.none')) ?></td></tr><?php endif; ?>
</tbody></table></div></div>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
