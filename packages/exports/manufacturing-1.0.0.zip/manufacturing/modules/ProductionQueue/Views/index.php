<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<style>
.queue-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(340px,1fr)); gap:14px; margin-bottom:14px; }
.queue-card { background:linear-gradient(160deg,rgba(255,255,255,.07),rgba(255,255,255,.02)); border:1px solid var(--glass-border); border-radius:14px; padding:16px; display:flex; flex-direction:column; gap:10px; }
.queue-card.overdue  { border-color:rgba(255,90,90,.35); }
.queue-card.complete { border-color:rgba(0,220,110,.35); }
.queue-card.on-track { border-color:rgba(119,167,255,.35); }
.queue-card-header { display:flex; justify-content:space-between; align-items:flex-start; gap:8px; }
.queue-machine { font-size:.8em; color:var(--muted); }
.queue-product { font-weight:700; font-size:1.05em; line-height:1.3; }
.queue-model   { font-size:.78em; color:var(--muted); margin-top:1px; }
.queue-badge   { font-size:.72em; padding:2px 8px; border-radius:20px; white-space:nowrap; flex-shrink:0; }
.badge-planned   { background:rgba(119,167,255,.18); color:#a5c5ff; border:1px solid rgba(119,167,255,.3); }
.badge-progress  { background:rgba(255,200,60,.18);  color:#ffd97d; border:1px solid rgba(255,200,60,.3); }
.badge-done      { background:rgba(0,220,110,.18);   color:#5fffa4; border:1px solid rgba(0,220,110,.3); }
.badge-overdue   { background:rgba(255,80,80,.18);   color:#ff8888; border:1px solid rgba(255,80,80,.3); }
.badge-upcoming  { background:rgba(160,160,180,.18); color:#b8bcd8; border:1px solid rgba(160,160,180,.3); }
.progress-bar-wrap { height:8px; background:rgba(255,255,255,.08); border-radius:6px; overflow:hidden; }
.progress-bar-fill { height:100%; border-radius:6px; transition:width .4s ease; }
.fill-low      { background:linear-gradient(90deg,#e05555,#ff6b6b); }
.fill-mid      { background:linear-gradient(90deg,#d4a000,#ffd050); }
.fill-high     { background:linear-gradient(90deg,#0d9b5a,#2af590); }
.fill-full     { background:linear-gradient(90deg,#0d7b3a,#00e87a); }
.queue-nums { display:flex; gap:12px; flex-wrap:wrap; }
.queue-num { flex:1; min-width:80px; }
.queue-num-label { font-size:.7em; color:var(--muted); margin-bottom:2px; }
.queue-num-value { font-size:1.1em; font-weight:700; }
.queue-time-row { display:flex; gap:8px; align-items:center; font-size:.78em; color:var(--muted); flex-wrap:wrap; }
.queue-time-bar-wrap { position:relative; height:6px; background:rgba(255,255,255,.08); border-radius:4px; overflow:hidden; flex:1; min-width:80px; }
.queue-time-bar-fill { position:absolute; left:0; top:0; height:100%; background:linear-gradient(90deg,rgba(119,167,255,.6),rgba(119,167,255,.3)); border-radius:4px; }
.queue-time-now  { position:absolute; top:-3px; height:12px; width:2px; background:#77a7ff; border-radius:1px; }
.stat-row { display:flex; gap:14px; flex-wrap:wrap; margin-bottom:14px; }
.stat-box { flex:1; min-width:140px; background:linear-gradient(160deg,rgba(255,255,255,.07),rgba(255,255,255,.02)); border:1px solid var(--glass-border); border-radius:12px; padding:14px 18px; }
.stat-box-label { font-size:.75em; color:var(--muted); margin-bottom:4px; }
.stat-box-value { font-size:1.6em; font-weight:700; }
.queue-actions { display:flex; gap:6px; flex-wrap:wrap; margin-top:2px; }
.seq-badge { font-size:.7em; background:rgba(255,255,255,.1); border-radius:20px; padding:1px 7px; color:var(--muted); }
</style>

<?php
$today    = (string)($today ?? date('Y-m-d'));
$date     = (string)($date ?? $today);
$rows     = $rows ?? [];
$machines = $machines ?? [];
$totalPlanned  = (float)($totalPlanned ?? 0);
$totalProduced = (float)($totalProduced ?? 0);
$machine_id    = (int)($machine_id ?? 0);

$isToday   = ($date === $today);
$isPast    = ($date < $today);
$isFuture  = ($date > $today);

// Current hour of day for time-bar (0-24)
$nowHour = (float)date('G') + (float)date('i') / 60;

// Overall progress %
$overallPct = $totalPlanned > 0 ? min(100, round($totalProduced / $totalPlanned * 100, 1)) : 0;

function queueFillClass(float $pct): string {
    if ($pct >= 100) return 'fill-full';
    if ($pct >= 70)  return 'fill-high';
    if ($pct >= 35)  return 'fill-mid';
    return 'fill-low';
}

function queueCardClass(string $status, float $pct, bool $isToday, bool $isPast): string {
    if ($pct >= 100) return 'complete';
    if ($isPast && $pct < 100) return 'overdue';
    if ($isToday) return 'on-track';
    return '';
}
?>

<!-- Header -->
<div class="card" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px">
  <div>
    <h2 style="margin:0">Production Queue</h2>
    <div class="muted" style="font-size:.85em;margin-top:2px">
      <?php if ($isToday): ?>Today &mdash; <?= e(date('l, d M Y', strtotime($date))) ?>
      <?php elseif ($isPast): ?><span style="color:#ff8888">Past &mdash; <?= e(date('d M Y', strtotime($date))) ?></span>
      <?php else: ?><span style="color:#a5c5ff">Upcoming &mdash; <?= e(date('d M Y', strtotime($date))) ?></span>
      <?php endif; ?>
    </div>
  </div>
  <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
    <a class="btn" href="/manufacturing/production-queue?date=<?= urlencode((string)date('Y-m-d', strtotime($date . ' -1 day'))) ?><?= $machine_id > 0 ? '&machine_id='.$machine_id : '' ?>">&larr;</a>
    <a class="btn" href="/manufacturing/production-queue"><?= $isToday ? 'Today' : 'Go to Today' ?></a>
    <a class="btn" href="/manufacturing/production-queue?date=<?= urlencode((string)date('Y-m-d', strtotime($date . ' +1 day'))) ?><?= $machine_id > 0 ? '&machine_id='.$machine_id : '' ?>">&rarr;</a>
    <a class="btn ok" href="/production-plans/add">+ Plan</a>
    <a class="btn" href="/production-entries/add">+ Entry</a>
    <a class="btn" href="/production-plans">List View</a>
  </div>
</div>

<!-- Filter -->

<style>
<style>
.queue-filter-form { display: flex; flex-direction: column; gap: 0; }
.queue-filter-row { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 6px; }
.queue-filter-field { min-width: 120px; flex: 1 1 120px; max-width: 220px; }
.queue-filter-field input,
.queue-filter-field select { width: 100%; max-width: 100%; box-sizing: border-box; padding: 6px 8px; font-size: 1em; }
.queue-filter-field label { margin-bottom: 3px !important; font-size: .78em !important; }
.queue-filter-actions { display: flex; gap: 8px; justify-content: flex-start; }
@media (max-width: 600px) {
  .queue-filter-row { gap: 6px; }
  .queue-filter-field { max-width: 100%; min-width: 0; padding: 0; }
  .queue-filter-field input,
  .queue-filter-field select { padding: 5px 6px; font-size: .98em; }
  .queue-filter-field label { margin-bottom: 2px !important; font-size: .75em !important; }
  .queue-filter-actions { gap: 6px; }
  .queue-filter-form button,
  .queue-filter-form a.btn { padding: 5px 10px; font-size: .95em; }
}
</style>
<div class="card">
  <form method="get" action="/manufacturing/production-queue" class="queue-filter-form">
    <div class="queue-filter-row">
      <div class="queue-filter-field">
        <label class="muted" style="display:block;margin-bottom:5px;font-size:.8em">Date</label>
        <input type="date" name="date" value="<?= e($date) ?>">
      </div>
      <div class="queue-filter-field">
        <label class="muted" style="display:block;margin-bottom:5px;font-size:.8em">Machine</label>
        <select name="machine_id">
          <option value="0">All Machines</option>
          <?php foreach ($machines as $m): ?>
            <option value="<?= (int)$m['id'] ?>" <?= ($machine_id === (int)$m['id']) ? 'selected' : '' ?>>
              <?= e((string)$m['machine_no']) ?> &mdash; <?= e((string)$m['machine_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <div class="queue-filter-actions">
      <button class="btn" type="submit">Filter</button>
      <a class="btn" href="/manufacturing/production-queue">Reset</a>
    </div>
  </form>
</div>

<!-- Stat summary -->
<div class="stat-row">
  <div class="stat-box">
    <div class="stat-box-label">Plans</div>
    <div class="stat-box-value"><?= count($rows) ?></div>
  </div>
  <div class="stat-box">
    <div class="stat-box-label">Total Planned Qty</div>
    <div class="stat-box-value"><?= number_format($totalPlanned, 0) ?></div>
  </div>
  <div class="stat-box">
    <div class="stat-box-label">Produced (Good)</div>
    <div class="stat-box-value" style="color:<?= $totalProduced >= $totalPlanned && $totalPlanned > 0 ? '#5fffa4' : '#ffd97d' ?>">
      <?= number_format($totalProduced, 0) ?>
    </div>
  </div>
  <div class="stat-box">
    <div class="stat-box-label">Overall Progress</div>
    <div class="stat-box-value" style="color:<?= $overallPct >= 100 ? '#5fffa4' : ($overallPct >= 60 ? '#ffd97d' : '#ff8888') ?>">
      <?= $overallPct ?>%
    </div>
    <div style="margin-top:6px"><div class="progress-bar-wrap"><div class="progress-bar-fill <?= queueFillClass($overallPct) ?>" style="width:<?= $overallPct ?>%"></div></div></div>
  </div>
  <?php if ($isToday): ?>
  <div class="stat-box">
    <div class="stat-box-label">Time of Day</div>
    <div class="stat-box-value"><?= date('H:i') ?></div>
    <div style="margin-top:6px">
      <div class="progress-bar-wrap">
        <?php $dayPct = min(100, round($nowHour / 24 * 100, 1)); ?>
        <div class="progress-bar-fill" style="width:<?= $dayPct ?>%;background:linear-gradient(90deg,rgba(119,167,255,.5),rgba(119,167,255,.2))"></div>
      </div>
    </div>
    <div style="font-size:.72em;color:var(--muted);margin-top:3px"><?= round(24 - $nowHour, 1) ?>h remaining in day</div>
  </div>
  <?php endif; ?>
</div>

<?php if (empty($rows)): ?>
<div class="card" style="color:var(--muted);text-align:center;padding:32px">No production plans for this date<?= $machine_id > 0 ? ' / machine' : '' ?>.</div>
<?php else: ?>

<!-- Cards grid -->
<div class="queue-grid">
<?php foreach ($rows as $r):
  $planned  = (float)$r['planned_qty'];
  $produced = (float)$r['good_qty'];
  $rejected = (float)$r['rejected_qty'];
  $pct      = $planned > 0 ? min(100, round($produced / $planned * 100, 1)) : 0;
  $remaining = max(0, $planned - $produced);

  // Runtime / cycle
  $runtime = $r['runtime'] !== null ? (float)$r['runtime'] : null;
  $productCycle = ($r['cycle_time'] ?? null) !== null && (string)$r['cycle_time'] !== '' ? (float)$r['cycle_time'] : null;
  $cyclePerUnit = $productCycle !== null
      ? round($productCycle, 2)
      : (($runtime !== null && $planned > 0) ? round($runtime * 60 / $planned, 2) : null); // minutes per unit

  // Time progress (runtime as planned shift hours, date = plan_date)
  $timeElapsedHrs = null;
  $timePct        = null;
  if ($isToday && $runtime !== null && $runtime > 0) {
    $timeElapsedHrs = min($runtime, $nowHour); // simplistic: elapsed since midnight
    $timePct = min(100, round($timeElapsedHrs / $runtime * 100, 1));
    $nowPct  = min(100, round($nowHour / $runtime * 100, 1));
  }

  $status = (string)$r['status'];

  // Card state
  if ($pct >= 100) {
    $cardClass  = 'complete';
    $badgeClass = 'badge-done';
    $badgeLabel = 'Done';
  } elseif ($isPast && $pct < 100) {
    $cardClass  = 'overdue';
    $badgeClass = 'badge-overdue';
    $badgeLabel = 'Overdue';
  } elseif ($pct > 0) {
    $cardClass  = 'on-track';
    $badgeClass = 'badge-progress';
    $badgeLabel = 'In Progress';
  } elseif ($isFuture) {
    $cardClass  = '';
    $badgeClass = 'badge-upcoming';
    $badgeLabel = 'Upcoming';
  } else {
    $cardClass  = '';
    $badgeClass = 'badge-planned';
    $badgeLabel = e($status);
  }
?>
<div class="queue-card <?= $cardClass ?>">
  <!-- Card header -->
  <div class="queue-card-header">
    <div>
      <div class="queue-machine">
        <?= e((string)$r['machine_no']) ?> &mdash; <?= e((string)$r['machine_name']) ?>
        <?php if (!empty($r['section'])): ?>
          <span class="seq-badge"><?= e((string)$r['section']) ?></span>
        <?php endif; ?>
        <span class="seq-badge">#<?= (int)$r['sequence_no'] ?></span>
      </div>
      <div class="queue-product"><?= e((string)$r['parts_name']) ?> <span style="font-weight:400;color:var(--muted);font-size:.85em"><?= e((string)$r['parts_number']) ?></span></div>
      <?php if (!empty($r['model'])): ?><div class="queue-model"><?= e((string)$r['model']) ?></div><?php endif; ?>
    </div>
    <span class="queue-badge <?= $badgeClass ?>"><?= $badgeLabel ?></span>
  </div>

  <!-- Progress bar -->
  <div>
    <div style="display:flex;justify-content:space-between;font-size:.75em;margin-bottom:4px">
      <span style="color:var(--muted)">Production Progress</span>
      <span style="font-weight:700;color:<?= $pct >= 100 ? '#5fffa4' : ($pct >= 60 ? '#ffd97d' : '#e07070') ?>"><?= $pct ?>%</span>
    </div>
    <div class="progress-bar-wrap">
      <div class="progress-bar-fill <?= queueFillClass($pct) ?>" style="width:<?= $pct ?>%"></div>
    </div>
  </div>

  <!-- Numbers -->
  <div class="queue-nums">
    <div class="queue-num">
      <div class="queue-num-label">Planned</div>
      <div class="queue-num-value"><?= number_format($planned, 0) ?></div>
    </div>
    <div class="queue-num">
      <div class="queue-num-label">Produced</div>
      <div class="queue-num-value" style="color:#5fffa4"><?= number_format($produced, 0) ?></div>
    </div>
    <?php if ($rejected > 0): ?>
    <div class="queue-num">
      <div class="queue-num-label">Rejected</div>
      <div class="queue-num-value" style="color:#ff8888"><?= number_format($rejected, 0) ?></div>
    </div>
    <?php endif; ?>
    <div class="queue-num">
      <div class="queue-num-label">Remaining</div>
      <div class="queue-num-value" style="color:<?= $remaining > 0 ? '#ffd97d' : '#5fffa4' ?>"><?= number_format($remaining, 0) ?></div>
    </div>
    <?php if ($cyclePerUnit !== null): ?>
    <div class="queue-num">
      <div class="queue-num-label">Cycle (min/unit)</div>
      <div class="queue-num-value"><?= $cyclePerUnit ?></div>
    </div>
    <?php endif; ?>
  </div>

  <!-- Time bar (only for today's plans with runtime set) -->
  <?php if ($runtime !== null && $runtime > 0): ?>
  <div>
    <div style="display:flex;justify-content:space-between;font-size:.73em;margin-bottom:4px;color:var(--muted)">
      <span>Planned time</span>
      <span><?= $runtime ?>h runtime</span>
    </div>
    <?php if ($isToday && $timePct !== null): ?>
    <div style="position:relative">
      <div class="progress-bar-wrap" style="height:6px">
        <div class="progress-bar-fill" style="width:<?= $timePct ?>%;background:linear-gradient(90deg,rgba(119,167,255,.55),rgba(119,167,255,.2))"></div>
      </div>
      <?php if ($nowPct <= 100): ?>
      <div style="position:absolute;top:-2px;left:<?= min(96, $nowPct) ?>%;width:2px;height:10px;background:#77a7ff;border-radius:1px"></div>
      <?php endif; ?>
    </div>
    <div style="font-size:.72em;color:var(--muted);margin-top:3px;display:flex;justify-content:space-between">
      <span>00:00</span>
      <span style="color:#77a7ff">▲ <?= date('H:i') ?></span>
      <span><?= sprintf('%02d:%02d', (int)$runtime, (int)(($runtime - floor($runtime)) * 60)) ?></span>
    </div>
    <?php else: ?>
    <div style="font-size:.72em;color:var(--muted);margin-top:2px">
      <?= e($r['plan_date']) ?> &mdash; <?= $runtime ?>h planned
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <!-- Plan date context -->
  <div style="font-size:.73em;color:var(--muted);display:flex;gap:8px;flex-wrap:wrap;align-items:center">
    <span>Plan: <?= e((string)$r['plan_date']) ?></span>
    <?php if (!$isToday): ?>
      <?php
        $diffDays = (int)((strtotime($date) - strtotime($today)) / 86400);
        $diffLabel = $diffDays > 0 ? "+{$diffDays}d from today" : abs($diffDays)."d ago";
      ?>
      <span style="color:<?= $diffDays < 0 ? '#ff8888' : '#a5c5ff' ?>"><?= $diffLabel ?></span>
    <?php endif; ?>
    <?php if (!empty($r['plan_type']) && $r['plan_type'] !== 'Manual'): ?>
      <span class="seq-badge"><?= e((string)$r['plan_type']) ?></span>
    <?php endif; ?>
    <?php if ((int)$r['entry_count'] > 0): ?>
      <span class="seq-badge"><?= (int)$r['entry_count'] ?> entr<?= (int)$r['entry_count'] === 1 ? 'y' : 'ies' ?></span>
    <?php endif; ?>
  </div>

  <!-- Actions -->
  <div class="queue-actions">
    <a class="btn" href="/production-entries/add?product_id=<?= (int)$r['product_id'] ?>" style="font-size:.8em;padding:4px 10px">+ Entry</a>
    <a class="btn" href="/production-plans/edit?id=<?= (int)$r['id'] ?>" style="font-size:.8em;padding:4px 10px">Edit Plan</a>
    <a class="btn" href="/production-entries?machine_id=<?= (int)$r['machine_id'] ?>&production_date=<?= urlencode($r['plan_date']) ?>" style="font-size:.8em;padding:4px 10px">Entries</a>
  </div>
</div>
<?php endforeach; ?>
</div>

<?php endif; ?>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
