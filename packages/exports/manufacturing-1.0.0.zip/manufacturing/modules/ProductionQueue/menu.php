<?php
return [
  ['key' => 'ipm.root', 'label' => 'IPM', 'url' => null, 'parent' => null, 'order' => 30, 'perm' => null],
  ['key' => 'ipm.production_queue', 'label' => 'Production Queue', 'url' => '/manufacturing/production-queue', 'parent' => 'ipm.root', 'order' => 59, 'perm' => null],
];
