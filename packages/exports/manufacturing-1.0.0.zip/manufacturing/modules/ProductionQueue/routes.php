<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\ProductionQueue\Controllers\QueueBoardService;

require_once __DIR__ . '/Controllers/QueueBoardService.php';

$router->get('/production-queue', function() {
    header('Location: /manufacturing/production-queue', true, 302);
    exit;
});
