<?php
return [
  ['key' => 'ipm.root', 'label' => 'IPM', 'url' => null, 'parent' => null, 'order' => 30, 'perm' => null],
  ['key' => 'ipm.production_plans', 'label' => 'Production Plans', 'url' => '/production-plans', 'parent' => 'ipm.root', 'order' => 60, 'perm' => null],
];
