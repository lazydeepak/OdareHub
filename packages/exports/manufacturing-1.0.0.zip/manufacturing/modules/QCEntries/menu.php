<?php
return [
  ['key' => 'ipm.root', 'label' => 'IPM', 'url' => null, 'parent' => null, 'order' => 30, 'perm' => null],
  ['key' => 'ipm.qc_leader', 'label' => 'QC', 'url' => '/manufacturing/qc-workboard', 'parent' => 'ipm.root', 'order' => 88, 'perm' => null],
  ['key' => 'ipm.qc_entries', 'label' => 'QC Entries', 'url' => '/qc-entries', 'parent' => 'ipm.root', 'order' => 90, 'perm' => null],
];
