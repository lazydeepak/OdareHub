<?php
return [
  ['key' => 'ipm.root', 'label' => 'IPM', 'url' => null, 'parent' => null, 'order' => 30, 'perm' => null],
  ['key' => 'ipm.machine_leader', 'label' => 'Production', 'url' => '/manufacturing/production-workboard', 'parent' => 'ipm.root', 'order' => 18, 'perm' => null],
  ['key' => 'ipm.machines', 'label' => 'Machines', 'url' => '/machines', 'parent' => 'ipm.root', 'order' => 20, 'perm' => null],
];
