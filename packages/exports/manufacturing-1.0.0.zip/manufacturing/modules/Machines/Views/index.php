<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>

<div class="card">
  <div class="module-header">
    <div class="module-header-info">
      <h2><?= e(t('module.machines.title')) ?></h2>
      <div class="muted"><?= e(t('module.machines.subtitle')) ?></div>
    </div>
    <div class="module-header-actions">
      <a class="btn ok" href="/machines/add"><?= e(t('module.machines.add')) ?></a>
    </div>
  </div>
</div>

<?php if (!empty($flash ?? '')): ?><div class="card notice-ok"><?= e((string)$flash) ?></div><?php endif; ?>
<?php if (!empty($error ?? '')): ?><div class="card notice-err"><?= e((string)$error) ?></div><?php endif; ?>

<div class="card">
  <form method="get" action="/machines" class="module-filterbar">
    <div class="module-filter-field-wide">
      <label class="module-filter-label"><?= e(t('common.search')) ?></label>
      <input name="q" value="<?= e((string)$q) ?>" placeholder="<?= e(t('module.machines.search_placeholder')) ?>" autocomplete="off">
    </div>
    <div class="module-filter-field">
      <label class="module-filter-label"><?= e(t('common.status')) ?></label>
      <select name="active">
        <option value="all" <?= $active === 'all' ? 'selected' : '' ?>><?= e(t('common.all')) ?></option>
        <option value="1" <?= $active === '1' ? 'selected' : '' ?>><?= e(t('common.active')) ?></option>
        <option value="0" <?= $active === '0' ? 'selected' : '' ?>><?= e(t('common.inactive')) ?></option>
      </select>
    </div>
    <div class="module-filterbar-actions">
      <button class="btn" type="submit"><?= e(t('common.filter')) ?></button>
      <a class="btn" href="/machines"><?= e(t('common.reset')) ?></a>
    </div>
  </form>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead>
      <tr>
        <th><?= e(t('module.machines.machine_no')) ?></th>
        <th><?= e(t('module.machines.machine_name')) ?></th>
        <th><?= e(t('module.machines.section')) ?></th>
        <th><?= e(t('common.status')) ?></th>
        <th><?= e(t('module.machines.capacity_per_hour')) ?></th>
        <th><?= e(t('common.updated')) ?></th>
        <th><?= e(t('common.actions')) ?></th>
      </tr>
      </thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><code><?= e((string)$r['machine_no']) ?></code></td>
          <td><?= e((string)$r['machine_name']) ?></td>
          <td><?= e((string)($r['section'] ?? '')) ?></td>
          <td>
            <?= e((string)($r['status'] ?? '')) ?>
            <?php if ((int)($r['is_active'] ?? 1) !== 1): ?>
              <span class="muted">(<?= e(t('common.inactive')) ?>)</span>
            <?php endif; ?>
          </td>
          <td><?= e((string)($r['capacity_per_hour'] ?? '')) ?></td>
          <td class="muted"><?= e((string)($r['updated_at'] ?? '')) ?></td>
          <td>
            <div class="row">
              <a class="btn" href="/machines/edit?id=<?= (int)$r['id'] ?>"><?= e(t('common.edit')) ?></a>
              <form method="post" action="/machines/delete" onsubmit="return confirm('<?= e(t('module.machines.delete_confirm')) ?>');">
                <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <button class="btn danger" type="submit"><?= e(t('common.delete')) ?></button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($rows)): ?>
        <tr>
          <td colspan="7" class="muted" style="text-align:center"><?= e(t('module.machines.none')) ?></td>
        </tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="muted" style="margin-top:10px;font-size:13px">
    <?= e(localized_records_summary(count($rows))) ?>
  </div>
</div>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
