<?php
return [
    ['key' => 'inventory.root', 'label' => 'Inventory', 'url' => null, 'parent' => null, 'order' => 40, 'perm' => null],
    ['key' => 'inventory.ledger', 'label' => 'Stock Ledger', 'url' => '/ledger', 'parent' => 'inventory.root', 'order' => 10, 'perm' => null],
    ['key' => 'inventory.ledger_add', 'label' => 'Add Stock Entry', 'url' => '/ledger/add', 'parent' => 'inventory.root', 'order' => 20, 'perm' => null],
    ['key' => 'inventory.ledger_reconcile', 'label' => 'Stock Reconciliation', 'url' => '/ledger/reconcile', 'parent' => 'inventory.root', 'order' => 30, 'perm' => null],
];
