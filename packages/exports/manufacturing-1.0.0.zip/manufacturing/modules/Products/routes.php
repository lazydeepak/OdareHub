<?php
declare(strict_types=1);

use App\Core\Auth;
use Plugins\Products\Controllers\ProductsController;

require_once __DIR__ . '/Controllers/ProductsController.php';

$router->get('/products', function() use ($view) {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    ProductsController::index($view);
    return null;
});

$router->get('/products/360', function() use ($view) {
    acl_require('products.360.view', '/products/360?id=' . (int)($_GET['id'] ?? 0));

    ProductsController::part360($view, (int)($_GET['id'] ?? 0));
    return null;
});

$router->get('/products/add', function() use ($view) {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    ProductsController::addForm($view);
    return null;
});

$router->post('/products/add', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    ProductsController::create($_POST);
    header('Location: /products');
    exit;
});

$router->get('/products/edit', function() use ($view) {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    ProductsController::editForm($view, (int)($_GET['id'] ?? 0));
    return null;
});

$router->post('/products/edit', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    ProductsController::update($_POST);
    header('Location: /products');
    exit;
});

$router->post('/products/delete', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    ProductsController::delete((int)($_POST['id'] ?? 0));
    header('Location: /products');
    exit;
});

$router->get('/products/import', function() use ($view) {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    ProductsController::importForm($view);
    return null;
});

$router->post('/products/import', function() {
    Auth::requireAppAccess('manufacturing');
    Auth::bootSession();
    Auth::requireCsrf((string)($_POST['csrf'] ?? ''));
    ProductsController::importCsv($_FILES['csv'] ?? null);
    header('Location: /products/import');
    exit;
});
