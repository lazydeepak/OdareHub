ALTER TABLE products
    ADD COLUMN essential_stock_qty DECIMAL(12,2) NULL AFTER activity_type,
    ADD COLUMN planning_window_days INT NULL AFTER essential_stock_qty,
    ADD COLUMN max_buffer_qty DECIMAL(12,2) NULL AFTER planning_window_days,
    ADD KEY idx_products_essential_stock_qty (essential_stock_qty),
    ADD KEY idx_products_planning_window_days (planning_window_days),
    ADD KEY idx_products_max_buffer_qty (max_buffer_qty);
