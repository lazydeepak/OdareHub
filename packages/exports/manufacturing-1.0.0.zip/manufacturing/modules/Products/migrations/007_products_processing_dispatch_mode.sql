

CREATE INDEX idx_products_requires_processing ON products (requires_processing);
CREATE INDEX idx_products_dispatch_mode ON products (dispatch_mode);
