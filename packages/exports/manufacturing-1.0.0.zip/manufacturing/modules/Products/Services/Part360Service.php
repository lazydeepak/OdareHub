<?php
declare(strict_types=1);

namespace Plugins\Products\Services;

use App\Core\DB;

require_once APP_ROOT . '/app/Core/helpers.php';

final class Part360Service
{
    /**
     * @var array<string,array{warn:int,breach:int,label:string}>
     */
    private const SLA_HOURS = [
        'production_to_qc' => ['warn' => 4, 'breach' => 12, 'label' => 'Waiting QC'],
        'qc_to_dispatch' => ['warn' => 2, 'breach' => 8, 'label' => 'QC Release'],
        'dispatch_to_completion' => ['warn' => 4, 'breach' => 12, 'label' => 'Dispatch Hold'],
        'order_risk' => ['warn' => 12, 'breach' => 24, 'label' => 'Order Risk'],
    ];

    /**
     * @return array<string,mixed>|null
     */
    public static function build(int $productId): ?array
    {
        if ($productId <= 0) {
            return null;
        }

        $product = DB::fetchOne(
            "SELECT p.*, COALESCE(lb.stock_balance, 0) AS stock_balance
             FROM products p
             LEFT JOIN (
                 SELECT product_id, COALESCE(SUM(qty_delta), 0) AS stock_balance
                 FROM stock_ledger_entries
                 GROUP BY product_id
             ) lb ON lb.product_id = p.id
             WHERE p.id = ?
             LIMIT 1",
            [$productId]
        );

        if (!$product) {
            return null;
        }

        $today = date('Y-m-d');
        $recentStart = self::shiftDate($today, -60);
        $futureEnd = self::shiftDate($today, 30);

        $demandSummary = self::demandSummary($productId);
        $openOrders = self::openOrders($productId);
        $stockSummary = self::stockSummary($productId);
        $recentLedger = self::recentLedger($productId);
        $plannedSupplySummary = self::plannedSupplySummary($productId, $futureEnd);
        $recentProductionPlans = self::recentProductionPlans($productId, $recentStart, $futureEnd);
        $productionSummary = self::productionSummary($productId, $recentStart);
        $recentProductionEntries = self::recentProductionEntries($productId, $recentStart);
        $qcSummary = self::qcSummary($productId, $recentStart, $futureEnd);
        $recentQcPlans = self::recentQcPlans($productId, $recentStart, $futureEnd);
        $recentQcEntries = self::recentQcEntries($productId, $recentStart);
        $dispatchSummary = self::dispatchSummary($productId, $recentStart);
        $recentDispatchEntries = self::recentDispatchEntries($productId, $recentStart);
        $machineMappings = self::machineMappings($productId);
        $machineUsage = self::machineUsage($productId, $recentStart, $futureEnd);
        $handoff = self::handoffSummary($productId, $openOrders, $recentProductionEntries, $recentQcEntries, $recentDispatchEntries);
        $riskSummary = self::riskSummary($product, $demandSummary, $qcSummary, $dispatchSummary, $machineMappings, $handoff);
        $supplyProfile = self::supplyProfile($product);
        $operationalSnapshot = self::operationalSnapshot($demandSummary, $stockSummary, $plannedSupplySummary, $qcSummary, $dispatchSummary);
        $orderContext = self::orderContextBuckets($openOrders);
        $workflowContext = self::workflowContext($demandSummary, $qcSummary, $dispatchSummary, $handoff, $riskSummary);
        $recommendedActions = self::recommendedActions($product, $demandSummary, $dispatchSummary, $riskSummary);
        $timeline = self::buildTimeline($recentProductionPlans, $recentProductionEntries, $recentQcEntries, $recentDispatchEntries, $recentLedger, $handoff);

        return [
            'product' => $product,
            'today' => $today,
            'supply_profile' => $supplyProfile,
            'operational_snapshot' => $operationalSnapshot,
            'order_context' => $orderContext,
            'workflow_context' => $workflowContext,
            'recommended_actions' => $recommendedActions,
            'timeline' => $timeline,
            'demand_summary' => $demandSummary,
            'open_orders' => $openOrders,
            'stock_summary' => $stockSummary,
            'recent_ledger' => $recentLedger,
            'planned_supply_summary' => $plannedSupplySummary,
            'recent_production_plans' => $recentProductionPlans,
            'production_summary' => $productionSummary,
            'recent_production_entries' => $recentProductionEntries,
            'qc_summary' => $qcSummary,
            'recent_qc_plans' => $recentQcPlans,
            'recent_qc_entries' => $recentQcEntries,
            'dispatch_summary' => $dispatchSummary,
            'recent_dispatch_entries' => $recentDispatchEntries,
            'machine_mappings' => $machineMappings,
            'machine_usage' => $machineUsage,
            'handoff' => $handoff,
            'risk_summary' => $riskSummary,
            'links' => [
                'part_edit' => '/products/edit?id=' . $productId,
                'part_list' => '/products',
                'orders_search' => '/daily-orders?q=' . urlencode((string)($product['parts_number'] ?? '')),
                'ledger' => '/ledger?product_id=' . $productId,
                'part_machine_map' => '/part-machine-map?q=' . urlencode((string)($product['parts_number'] ?? '')),
                'production_entries' => '/production-entries?product_id=' . $productId,
                'notifications' => '/ops/notifications',
            ],
        ];
    }

    /**
     * @param array<string,mixed> $product
     * @return array<string,mixed>
     */
    private static function supplyProfile(array $product): array
    {
        $supplyMode = strtolower(trim((string)($product['supply_mode'] ?? 'in_house')));
        $fulfillmentMode = strtolower(trim((string)($product['fulfillment_mode'] ?? 'via_ipm')));
        $requiresQc = (int)($product['requires_ipm_qc'] ?? 1) === 1;
        $stockedAtIpm = (int)($product['stocked_at_ipm'] ?? 1) === 1;

        $flowNarrative = 'In-house supply through IPM workflow.';
        if ($supplyMode === 'third_party') {
            $flowNarrative = 'Third-party supplied part with external dependency risk.';
        } elseif ($supplyMode === 'hybrid') {
            $flowNarrative = 'Hybrid supply path requiring coordinated sourcing.';
        }

        if ($fulfillmentMode === 'direct_supplier') {
            $flowNarrative = 'Direct supplier fulfillment with reduced in-house stock touch.';
        } elseif ($fulfillmentMode === 'mixed') {
            $flowNarrative = 'Mixed fulfillment across IPM and direct supplier paths.';
        }

        return [
            'supply_mode' => $supplyMode,
            'fulfillment_mode' => $fulfillmentMode,
            'requires_ipm_qc' => $requiresQc,
            'default_supplier' => trim((string)($product['default_supplier'] ?? '')),
            'stocked_at_ipm' => $stockedAtIpm,
            'default_procurement_lead_days' => (float)($product['default_procurement_lead_days'] ?? 0),
            'default_supply_note' => trim((string)($product['default_supply_note'] ?? '')),
            'flow_narrative' => $flowNarrative,
        ];
    }

    /**
     * @param array<string,mixed> $demandSummary
     * @param array<string,mixed> $stockSummary
     * @param array<string,mixed> $plannedSupplySummary
     * @param array<string,mixed> $qcSummary
     * @param array<string,mixed> $dispatchSummary
     * @return array<string,mixed>
     */
    private static function operationalSnapshot(array $demandSummary, array $stockSummary, array $plannedSupplySummary, array $qcSummary, array $dispatchSummary): array
    {
        $coveragePressureQty = max(0.0, (float)($demandSummary['open_demand_qty'] ?? 0) - ((float)($stockSummary['current_balance'] ?? 0) + (float)($plannedSupplySummary['active_planned_qty'] ?? 0) + (float)($qcSummary['pass_qty'] ?? 0)));

        return [
            'current_stock_qty' => round((float)($stockSummary['current_balance'] ?? 0), 2),
            'open_demand_qty' => round((float)($demandSummary['open_demand_qty'] ?? 0), 2),
            'planned_supply_qty' => round((float)($plannedSupplySummary['active_planned_qty'] ?? 0), 2),
            'qc_pending_qty' => round(max(0.0, (float)($qcSummary['checked_qty'] ?? 0) - (float)($qcSummary['pass_qty'] ?? 0)), 2),
            'qc_pass_qty' => round((float)($qcSummary['pass_qty'] ?? 0), 2),
            'dispatch_pending_qty' => round((float)($dispatchSummary['ready_qty'] ?? 0), 2),
            'dispatch_released_qty' => round((float)($dispatchSummary['dispatched_qty'] ?? 0), 2),
            'coverage_pressure_qty' => round($coveragePressureQty, 2),
            'low_coverage_orders' => (int)($demandSummary['low_coverage_orders'] ?? 0),
        ];
    }

    /**
     * @param array<int,array<string,mixed>> $openOrders
     * @return array<string,array<int,array<string,mixed>>>
     */
    private static function orderContextBuckets(array $openOrders): array
    {
        $urgent = [];
        $lowCoverage = [];
        $partial = [];

        foreach ($openOrders as $row) {
            $coverageStatus = strtolower(trim((string)($row['coverage_status'] ?? '')));
            $coveragePct = (float)($row['coverage_pct'] ?? 0);
            $due = trim((string)($row['dispatch_deadline'] ?? $row['required_date'] ?? ''));
            if ($due !== '') {
                $hours = self::hoursDiff(date('Y-m-d H:i:s'), strlen($due) === 10 ? ($due . ' 23:59:59') : $due);
                if ($hours <= 48.0) {
                    $urgent[] = $row;
                }
            }
            if ($coverageStatus === 'low' || $coveragePct < 50.0) {
                $lowCoverage[] = $row;
            }
            if ($coverageStatus === 'partial' || ((float)($row['open_demand_qty'] ?? 0) > 0 && $coveragePct > 0 && $coveragePct < 100)) {
                $partial[] = $row;
            }
        }

        return [
            'urgent_orders' => array_slice($urgent, 0, 8),
            'low_coverage_orders' => array_slice($lowCoverage, 0, 8),
            'partial_orders' => array_slice($partial, 0, 8),
        ];
    }

    /**
     * @param array<string,mixed> $demandSummary
     * @param array<string,mixed> $qcSummary
     * @param array<string,mixed> $dispatchSummary
     * @param array<string,mixed> $handoff
     * @param array<string,mixed> $riskSummary
     * @return array<string,mixed>
     */
    private static function workflowContext(array $demandSummary, array $qcSummary, array $dispatchSummary, array $handoff, array $riskSummary): array
    {
        $handoffCounts = (array)($handoff['counts'] ?? []);
        $planningNeeded = (float)($demandSummary['shortage_qty'] ?? 0) > 0.0001 || (int)($demandSummary['low_coverage_orders'] ?? 0) > 0;
        $awaitingQc = (float)($qcSummary['blocked_entries'] ?? 0) > 0 || (float)($qcSummary['checked_qty'] ?? 0) > (float)($qcSummary['pass_qty'] ?? 0);
        $readyDispatch = (float)($dispatchSummary['ready_qty'] ?? 0) > 0.0001;
        $partiallyReleased = (float)($dispatchSummary['dispatched_qty'] ?? 0) > 0.0001 && (float)($demandSummary['open_demand_qty'] ?? 0) > 0.0001;
        $supplyBlocked = (float)($demandSummary['shortage_qty'] ?? 0) > 0.0001 || (int)($dispatchSummary['blocked_entries'] ?? 0) > 0 || (int)($handoffCounts['blocked'] ?? 0) > 0;

        $stage = 'Coverage Healthy';
        if ((string)($riskSummary['state'] ?? '') === 'blocked') {
            $stage = 'Supply Blocked';
        } elseif ($awaitingQc) {
            $stage = 'Awaiting QC';
        } elseif ($readyDispatch) {
            $stage = 'Ready for Dispatch';
        } elseif ($planningNeeded) {
            $stage = 'Planning Needed';
        }

        if ($partiallyReleased) {
            $stage = 'Partially Released';
        }

        return [
            'stage_label' => $stage,
            'planning_needed' => $planningNeeded,
            'awaiting_qc' => $awaitingQc,
            'ready_for_dispatch' => $readyDispatch,
            'partially_released' => $partiallyReleased,
            'supply_blocked' => $supplyBlocked,
            'coverage_healthy' => (string)($riskSummary['state'] ?? '') === 'healthy',
        ];
    }

    /**
     * @param array<string,mixed> $product
     * @param array<string,mixed> $demandSummary
     * @param array<string,mixed> $dispatchSummary
     * @param array<string,mixed> $riskSummary
     * @return array<int,array<string,mixed>>
     */
    private static function recommendedActions(array $product, array $demandSummary, array $dispatchSummary, array $riskSummary): array
    {
        $productId = (int)($product['id'] ?? 0);
        $actions = [
            [
                'label' => 'Create Plan Draft',
                'method' => 'post',
                'url' => '/production-plans/start-draft',
                'roles' => ['admin', 'planning', 'machine'],
                'intent' => 'Start recovery planning for open demand pressure.',
                'post' => [
                    'product_id' => (string)$productId,
                    'required_date' => date('Y-m-d'),
                    'shortage_qty' => number_format(max(0.0, (float)($demandSummary['shortage_qty'] ?? 0)), 2, '.', ''),
                    'plan_type' => 'Recovery',
                    'failure_fallback' => '/products/360?id=' . $productId,
                ],
            ],
            [
                'label' => 'Review Shortage Orders',
                'method' => 'link',
                'url' => '/daily-orders?product_id=' . $productId . '&coverage=low',
                'roles' => ['all'],
                'intent' => 'Prioritize orders with low coverage for this part.',
            ],
            [
                'label' => 'Check Stock Ledger',
                'method' => 'link',
                'url' => '/ledger?product_id=' . $productId,
                'roles' => ['all'],
                'intent' => 'Confirm movement history and balance integrity.',
            ],
            [
                'label' => 'Review QC Worklist',
                'method' => 'link',
                'url' => '/qc-entries?product_id=' . $productId,
                'roles' => ['admin', 'qc'],
                'intent' => 'Investigate pending QC checks and pass/fail flow.',
            ],
            [
                'label' => 'Create Dispatch Draft',
                'method' => 'post',
                'url' => '/dispatch-entries/start-draft',
                'roles' => ['admin', 'dispatch'],
                'intent' => 'Start dispatch from available covered supply.',
                'post' => [
                    'product_id' => (string)$productId,
                    'required_date' => date('Y-m-d'),
                    'covered_qty' => number_format(max(0.0, (float)($dispatchSummary['ready_qty'] ?? 0)), 2, '.', ''),
                    'failure_fallback' => '/products/360?id=' . $productId,
                ],
            ],
        ];

        $supplyMode = strtolower(trim((string)($product['supply_mode'] ?? 'in_house')));
        if ($supplyMode !== 'in_house') {
            $actions[] = [
                'label' => 'Supplier / Procurement Review',
                'method' => 'link',
                'url' => '/products/edit?id=' . $productId,
                'roles' => ['admin', 'planning'],
                'intent' => 'Review external source configuration and procurement settings.',
            ];
        }

        if ((string)($riskSummary['state'] ?? '') === 'blocked') {
            $actions[] = [
                'label' => 'Open Dispatch Ops',
                'method' => 'link',
                'url' => '/manufacturing/dispatch-ops',
                'roles' => ['admin', 'dispatch'],
                'intent' => 'Resolve blocked/hold dispatch rows tied to this part.',
            ];
        }

        return $actions;
    }

    /**
     * @param array<int,array<string,mixed>> $recentProductionPlans
     * @param array<int,array<string,mixed>> $recentProductionEntries
     * @param array<int,array<string,mixed>> $recentQcEntries
     * @param array<int,array<string,mixed>> $recentDispatchEntries
     * @param array<int,array<string,mixed>> $recentLedger
     * @param array<string,mixed> $handoff
     * @return array<int,array<string,mixed>>
     */
    private static function buildTimeline(array $recentProductionPlans, array $recentProductionEntries, array $recentQcEntries, array $recentDispatchEntries, array $recentLedger, array $handoff): array
    {
        $events = [];
        foreach (array_slice($recentProductionPlans, 0, 5) as $row) {
            $events[] = [
                'when' => (string)($row['plan_date'] ?? ''),
                'type' => 'Production Plan',
                'title' => 'Plan #' . (int)($row['id'] ?? 0) . ' planned qty ' . number_format((float)($row['planned_qty'] ?? 0), 2, '.', ','),
                'status' => (string)($row['status'] ?? ''),
                'url' => '/production-plans/edit?id=' . (int)($row['id'] ?? 0),
            ];
        }
        foreach (array_slice($recentProductionEntries, 0, 5) as $row) {
            $events[] = [
                'when' => (string)($row['production_date'] ?? ''),
                'type' => 'Production Entry',
                'title' => 'Entry #' . (int)($row['id'] ?? 0) . ' good qty ' . number_format((float)($row['good_qty'] ?? 0), 2, '.', ','),
                'status' => (string)($row['status'] ?? ''),
                'url' => '/production-entries/edit?id=' . (int)($row['id'] ?? 0),
            ];
        }
        foreach (array_slice($recentQcEntries, 0, 5) as $row) {
            $events[] = [
                'when' => (string)($row['updated_at'] ?? $row['created_at'] ?? ''),
                'type' => 'QC Entry',
                'title' => 'QC #' . (int)($row['id'] ?? 0) . ' pass qty ' . number_format((float)($row['pass_qty'] ?? 0), 2, '.', ','),
                'status' => (string)($row['status'] ?? ''),
                'url' => '/qc-entries/edit?id=' . (int)($row['id'] ?? 0),
            ];
        }
        foreach (array_slice($recentDispatchEntries, 0, 5) as $row) {
            $events[] = [
                'when' => (string)($row['dispatch_date'] ?? ''),
                'type' => 'Dispatch Entry',
                'title' => 'Dispatch #' . (int)($row['id'] ?? 0) . ' qty ' . number_format((float)($row['dispatchable_qty'] ?? 0), 2, '.', ','),
                'status' => (string)($row['dispatch_status'] ?? ''),
                'url' => '/dispatch-entries/edit?id=' . (int)($row['id'] ?? 0),
            ];
        }
        foreach (array_slice($recentLedger, 0, 5) as $row) {
            $events[] = [
                'when' => (string)($row['created_at'] ?? ''),
                'type' => 'Ledger',
                'title' => (string)($row['movement_type'] ?? 'Movement') . ' delta ' . number_format((float)($row['qty_delta'] ?? 0), 2, '.', ','),
                'status' => (string)($row['reference_no'] ?? ''),
                'url' => '/ledger?product_id=' . (int)($row['product_id'] ?? 0),
            ];
        }

        $handoffItems = is_array($handoff['items'] ?? null) ? $handoff['items'] : [];
        foreach (array_slice($handoffItems, 0, 5) as $row) {
            $events[] = [
                'when' => date('Y-m-d H:i:s'),
                'type' => 'Handoff',
                'title' => (string)($row['stage_label'] ?? 'Workflow stage') . ' • owner ' . (string)($row['owner_role'] ?? 'Unassigned'),
                'status' => (string)($row['sla_level'] ?? 'ok'),
                'url' => '/apps/manufacturing/handoffs',
            ];
        }

        usort($events, static function (array $a, array $b): int {
            return strcmp((string)($b['when'] ?? ''), (string)($a['when'] ?? ''));
        });

        return array_slice($events, 0, 20);
    }

    /**
     * @return array<string,mixed>
     */
    private static function demandSummary(int $productId): array
    {
        $row = DB::fetchOne(
            "SELECT
                COUNT(*) AS open_orders,
                COALESCE(SUM(qty), 0) AS demand_qty,
                COALESCE(SUM(open_demand_qty), 0) AS open_demand_qty,
                COALESCE(SUM(shortage_qty), 0) AS shortage_qty,
                COALESCE(SUM(planned_supply_qty), 0) AS planned_supply_qty,
                COALESCE(SUM(usable_stock_qty), 0) AS usable_stock_qty,
                COALESCE(SUM(qc_pass_qty), 0) AS qc_pass_qty,
                COALESCE(SUM(dispatched_qty), 0) AS dispatched_qty,
                COALESCE(AVG(coverage_pct), 0) AS avg_coverage_pct,
                MIN(COALESCE(dispatch_deadline, CONCAT(COALESCE(required_date, order_date), ' 23:59:59'))) AS next_due_at,
                SUM(CASE WHEN LOWER(COALESCE(coverage_status, '')) = 'low' THEN 1 ELSE 0 END) AS low_coverage_orders,
                SUM(CASE WHEN LOWER(COALESCE(coverage_status, '')) = 'partial' THEN 1 ELSE 0 END) AS partial_coverage_orders,
                SUM(CASE WHEN TIMESTAMPDIFF(HOUR, NOW(), COALESCE(dispatch_deadline, CONCAT(COALESCE(required_date, order_date), ' 23:59:59'))) <= 48 THEN 1 ELSE 0 END) AS due_within_48h
             FROM daily_orders
             WHERE product_id = ?
               AND LOWER(COALESCE(status, '')) NOT IN ('closed', 'completed', 'cancelled', 'canceled')",
            [$productId]
        ) ?: [];

        return [
            'open_orders' => (int)($row['open_orders'] ?? 0),
            'demand_qty' => round((float)($row['demand_qty'] ?? 0), 2),
            'open_demand_qty' => round((float)($row['open_demand_qty'] ?? 0), 2),
            'shortage_qty' => round((float)($row['shortage_qty'] ?? 0), 2),
            'planned_supply_qty' => round((float)($row['planned_supply_qty'] ?? 0), 2),
            'usable_stock_qty' => round((float)($row['usable_stock_qty'] ?? 0), 2),
            'qc_pass_qty' => round((float)($row['qc_pass_qty'] ?? 0), 2),
            'dispatched_qty' => round((float)($row['dispatched_qty'] ?? 0), 2),
            'avg_coverage_pct' => round((float)($row['avg_coverage_pct'] ?? 0), 2),
            'next_due_at' => (string)($row['next_due_at'] ?? ''),
            'low_coverage_orders' => (int)($row['low_coverage_orders'] ?? 0),
            'partial_coverage_orders' => (int)($row['partial_coverage_orders'] ?? 0),
            'due_within_48h' => (int)($row['due_within_48h'] ?? 0),
        ];
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function openOrders(int $productId): array
    {
        return DB::fetchAll(
            "SELECT id, order_date, required_date, dispatch_deadline, customer_name, qty, open_demand_qty, coverage_pct, coverage_status, shortage_qty, status
             FROM daily_orders
             WHERE product_id = ?
               AND LOWER(COALESCE(status, '')) NOT IN ('closed', 'completed', 'cancelled', 'canceled')
             ORDER BY COALESCE(dispatch_deadline, CONCAT(COALESCE(required_date, order_date), ' 23:59:59')) ASC, id DESC
             LIMIT 25",
            [$productId]
        );
    }

    /**
     * @return array<string,mixed>
     */
    private static function stockSummary(int $productId): array
    {
        if (!self::tableExists('stock_ledger_entries')) {
            return [
                'current_balance' => 0.0,
                'total_in_qty' => 0.0,
                'total_out_qty' => 0.0,
                'production_in_qty' => 0.0,
                'dispatch_out_qty' => 0.0,
            ];
        }

        $row = DB::fetchOne(
            "SELECT
                COALESCE(SUM(qty_delta), 0) AS current_balance,
                COALESCE(SUM(CASE WHEN qty_delta > 0 THEN qty_delta ELSE 0 END), 0) AS total_in_qty,
                COALESCE(SUM(CASE WHEN qty_delta < 0 THEN ABS(qty_delta) ELSE 0 END), 0) AS total_out_qty,
                COALESCE(SUM(CASE WHEN movement_type IN ('IN', 'PRODUCTION_IN') THEN qty_delta ELSE 0 END), 0) AS production_in_qty,
                COALESCE(SUM(CASE WHEN movement_type IN ('OUT', 'DISPATCH_OUT') AND qty_delta < 0 THEN ABS(qty_delta) ELSE 0 END), 0) AS dispatch_out_qty
             FROM stock_ledger_entries
             WHERE product_id = ?",
            [$productId]
        ) ?: [];

        return [
            'current_balance' => round((float)($row['current_balance'] ?? 0), 2),
            'total_in_qty' => round((float)($row['total_in_qty'] ?? 0), 2),
            'total_out_qty' => round((float)($row['total_out_qty'] ?? 0), 2),
            'production_in_qty' => round((float)($row['production_in_qty'] ?? 0), 2),
            'dispatch_out_qty' => round((float)($row['dispatch_out_qty'] ?? 0), 2),
        ];
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function recentLedger(int $productId): array
    {
        if (!self::tableExists('stock_ledger_entries')) {
            return [];
        }

        return DB::fetchAll(
            "SELECT id, movement_type, qty_delta, balance_after, reference_no, source_module, source_id, notes, created_at
             FROM stock_ledger_entries
             WHERE product_id = ?
             ORDER BY created_at DESC, id DESC
             LIMIT 20",
            [$productId]
        );
    }

    /**
     * @return array<string,mixed>
     */
    private static function plannedSupplySummary(int $productId, string $futureEnd): array
    {
        $row = DB::fetchOne(
            "SELECT
                COUNT(*) AS open_plans,
                COALESCE(SUM(planned_qty), 0) AS planned_qty,
                COALESCE(SUM(CASE WHEN plan_date = CURDATE() THEN planned_qty ELSE 0 END), 0) AS today_planned_qty,
                COALESCE(SUM(CASE WHEN plan_date > CURDATE() THEN planned_qty ELSE 0 END), 0) AS upcoming_planned_qty,
                COALESCE(SUM(CASE WHEN LOWER(COALESCE(status, '')) IN ('planned', 'open', 'queued', 'in progress') THEN planned_qty ELSE 0 END), 0) AS active_planned_qty
             FROM production_plans
             WHERE product_id = ?
               AND plan_date <= ?",
            [$productId, $futureEnd]
        ) ?: [];

        return [
            'open_plans' => (int)($row['open_plans'] ?? 0),
            'planned_qty' => round((float)($row['planned_qty'] ?? 0), 2),
            'today_planned_qty' => round((float)($row['today_planned_qty'] ?? 0), 2),
            'upcoming_planned_qty' => round((float)($row['upcoming_planned_qty'] ?? 0), 2),
            'active_planned_qty' => round((float)($row['active_planned_qty'] ?? 0), 2),
        ];
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function recentProductionPlans(int $productId, string $recentStart, string $futureEnd): array
    {
        return DB::fetchAll(
            "SELECT pp.*, m.machine_no, m.machine_name
             FROM production_plans pp
             LEFT JOIN machines m ON m.id = pp.machine_id
             WHERE pp.product_id = ?
               AND pp.plan_date BETWEEN ? AND ?
             ORDER BY pp.plan_date DESC, pp.id DESC
             LIMIT 25",
            [$productId, $recentStart, $futureEnd]
        );
    }

    /**
     * @return array<string,mixed>
     */
    private static function productionSummary(int $productId, string $recentStart): array
    {
        $row = DB::fetchOne(
            "SELECT
                COUNT(*) AS entries,
                COALESCE(SUM(produced_qty), 0) AS produced_qty,
                COALESCE(SUM(good_qty), 0) AS good_qty,
                COALESCE(SUM(rejected_qty), 0) AS rejected_qty,
                MAX(production_date) AS last_production_date
             FROM production_entries
             WHERE product_id = ?
               AND production_date >= ?",
            [$productId, $recentStart]
        ) ?: [];

        return [
            'entries' => (int)($row['entries'] ?? 0),
            'produced_qty' => round((float)($row['produced_qty'] ?? 0), 2),
            'good_qty' => round((float)($row['good_qty'] ?? 0), 2),
            'rejected_qty' => round((float)($row['rejected_qty'] ?? 0), 2),
            'last_production_date' => (string)($row['last_production_date'] ?? ''),
        ];
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function recentProductionEntries(int $productId, string $recentStart): array
    {
        return DB::fetchAll(
            "SELECT pe.*, m.machine_no, m.machine_name
             FROM production_entries pe
             LEFT JOIN machines m ON m.id = pe.machine_id
             WHERE pe.product_id = ?
               AND pe.production_date >= ?
             ORDER BY pe.production_date DESC, pe.id DESC
             LIMIT 25",
            [$productId, $recentStart]
        );
    }

    /**
     * @return array<string,mixed>
     */
    private static function qcSummary(int $productId, string $recentStart, string $futureEnd): array
    {
        $planRow = DB::fetchOne(
            "SELECT
                COUNT(*) AS open_plans,
                COALESCE(SUM(planned_qty), 0) AS planned_qty
             FROM qc_plans
             WHERE product_id = ?
               AND plan_date BETWEEN ? AND ?",
            [$productId, $recentStart, $futureEnd]
        ) ?: [];

        $entryRow = DB::fetchOne(
            "SELECT
                COUNT(*) AS entries,
                COALESCE(SUM(checked_qty), 0) AS checked_qty,
                COALESCE(SUM(pass_qty), 0) AS pass_qty,
                COALESCE(SUM(fail_qty), 0) AS fail_qty,
                SUM(CASE WHEN LOWER(COALESCE(status, '')) IN ('recheck', 'failed', 'hold') THEN 1 ELSE 0 END) AS blocked_entries
             FROM qc_entries
             WHERE product_id = ?
               AND DATE(created_at) >= ?",
            [$productId, $recentStart]
        ) ?: [];

        return [
            'open_plans' => (int)($planRow['open_plans'] ?? 0),
            'planned_qty' => round((float)($planRow['planned_qty'] ?? 0), 2),
            'entries' => (int)($entryRow['entries'] ?? 0),
            'checked_qty' => round((float)($entryRow['checked_qty'] ?? 0), 2),
            'pass_qty' => round((float)($entryRow['pass_qty'] ?? 0), 2),
            'fail_qty' => round((float)($entryRow['fail_qty'] ?? 0), 2),
            'blocked_entries' => (int)($entryRow['blocked_entries'] ?? 0),
        ];
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function recentQcPlans(int $productId, string $recentStart, string $futureEnd): array
    {
        return DB::fetchAll(
            "SELECT *
             FROM qc_plans
             WHERE product_id = ?
               AND plan_date BETWEEN ? AND ?
             ORDER BY plan_date DESC, id DESC
             LIMIT 25",
            [$productId, $recentStart, $futureEnd]
        );
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function recentQcEntries(int $productId, string $recentStart): array
    {
        return DB::fetchAll(
            "SELECT *
             FROM qc_entries
             WHERE product_id = ?
               AND DATE(created_at) >= ?
             ORDER BY id DESC
             LIMIT 25",
            [$productId, $recentStart]
        );
    }

    /**
     * @return array<string,mixed>
     */
    private static function dispatchSummary(int $productId, string $recentStart): array
    {
        $row = DB::fetchOne(
            "SELECT
                COUNT(*) AS entries,
                COALESCE(SUM(dispatchable_qty), 0) AS total_qty,
                COALESCE(SUM(CASE WHEN LOWER(COALESCE(dispatch_status, '')) = 'ready' THEN dispatchable_qty ELSE 0 END), 0) AS ready_qty,
                COALESCE(SUM(CASE WHEN LOWER(COALESCE(dispatch_status, '')) IN ('partial', 'dispatched', 'completed', 'closed', 'delivered') THEN dispatchable_qty ELSE 0 END), 0) AS dispatched_qty,
                COALESCE(SUM(CASE WHEN LOWER(COALESCE(dispatch_status, '')) IN ('hold', 'blocked') THEN dispatchable_qty ELSE 0 END), 0) AS blocked_qty,
                SUM(CASE WHEN LOWER(COALESCE(dispatch_status, '')) IN ('hold', 'blocked') THEN 1 ELSE 0 END) AS blocked_entries
             FROM dispatch_entries
             WHERE product_id = ?
               AND dispatch_date >= ?",
            [$productId, $recentStart]
        ) ?: [];

        return [
            'entries' => (int)($row['entries'] ?? 0),
            'total_qty' => round((float)($row['total_qty'] ?? 0), 2),
            'ready_qty' => round((float)($row['ready_qty'] ?? 0), 2),
            'dispatched_qty' => round((float)($row['dispatched_qty'] ?? 0), 2),
            'blocked_qty' => round((float)($row['blocked_qty'] ?? 0), 2),
            'blocked_entries' => (int)($row['blocked_entries'] ?? 0),
        ];
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function recentDispatchEntries(int $productId, string $recentStart): array
    {
        return DB::fetchAll(
            "SELECT *
             FROM dispatch_entries
             WHERE product_id = ?
               AND dispatch_date >= ?
             ORDER BY dispatch_date DESC, id DESC
             LIMIT 25",
            [$productId, $recentStart]
        );
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function machineMappings(int $productId): array
    {
        if (!self::tableExists('part_machine_map')) {
            return [];
        }

        return DB::fetchAll(
            "SELECT pm.*, m.machine_no, m.machine_name, m.section, m.status AS machine_status, m.capacity_per_hour
             FROM part_machine_map pm
             INNER JOIN machines m ON m.id = pm.machine_id
             WHERE pm.product_id = ?
             ORDER BY pm.is_active DESC, m.machine_no ASC, pm.id DESC",
            [$productId]
        );
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function machineUsage(int $productId, string $recentStart, string $futureEnd): array
    {
        return DB::fetchAll(
            "SELECT
                m.id AS machine_id,
                m.machine_no,
                m.machine_name,
                m.section,
                COALESCE(pp.plan_count, 0) AS plan_count,
                COALESCE(pp.planned_qty, 0) AS planned_qty,
                COALESCE(pe.entry_count, 0) AS entry_count,
                COALESCE(pe.good_qty, 0) AS good_qty
             FROM machines m
             INNER JOIN (
                SELECT machine_id FROM production_plans WHERE product_id = ? AND plan_date BETWEEN ? AND ?
                UNION
                SELECT machine_id FROM production_entries WHERE product_id = ? AND production_date >= ?
             ) used ON used.machine_id = m.id
             LEFT JOIN (
                SELECT machine_id, COUNT(*) AS plan_count, COALESCE(SUM(planned_qty), 0) AS planned_qty
                FROM production_plans
                WHERE product_id = ? AND plan_date BETWEEN ? AND ?
                GROUP BY machine_id
             ) pp ON pp.machine_id = m.id
             LEFT JOIN (
                SELECT machine_id, COUNT(*) AS entry_count, COALESCE(SUM(good_qty), 0) AS good_qty
                FROM production_entries
                WHERE product_id = ? AND production_date >= ?
                GROUP BY machine_id
             ) pe ON pe.machine_id = m.id
             ORDER BY COALESCE(pe.good_qty, 0) DESC, COALESCE(pp.planned_qty, 0) DESC, m.machine_no ASC",
            [$productId, $recentStart, $futureEnd, $productId, $recentStart, $productId, $recentStart, $futureEnd, $productId, $recentStart]
        );
    }

    /**
     * @param array<int,array<string,mixed>> $openOrders
     * @param array<int,array<string,mixed>> $productionEntries
     * @param array<int,array<string,mixed>> $qcEntries
     * @param array<int,array<string,mixed>> $dispatchEntries
     * @return array<string,mixed>
     */
    private static function handoffSummary(int $productId, array $openOrders, array $productionEntries, array $qcEntries, array $dispatchEntries): array
    {
        if (!self::tableExists('handoff_tracking')) {
            return [
                'counts' => ['blocked' => 0, 'escalated' => 0, 'breach' => 0, 'warning' => 0, 'active' => 0],
                'items' => [],
            ];
        }

        $dailyOrderIds = array_values(array_filter(array_map(static fn(array $row): int => (int)($row['id'] ?? 0), $openOrders)));
        $productionEntryIds = array_values(array_filter(array_map(static fn(array $row): int => (int)($row['id'] ?? 0), $productionEntries)));
        $qcEntryIds = array_values(array_filter(array_map(static fn(array $row): int => (int)($row['id'] ?? 0), $qcEntries)));
        $dispatchEntryIds = array_values(array_filter(array_map(static fn(array $row): int => (int)($row['id'] ?? 0), $dispatchEntries)));

        $clauses = [];
        $params = [];
        self::appendEntityInClause($clauses, $params, 'daily_order', $dailyOrderIds);
        self::appendEntityInClause($clauses, $params, 'production_entry', $productionEntryIds);
        self::appendEntityInClause($clauses, $params, 'qc_entry', $qcEntryIds);
        self::appendEntityInClause($clauses, $params, 'dispatch_entry', $dispatchEntryIds);

        if (empty($clauses)) {
            return [
                'counts' => ['blocked' => 0, 'escalated' => 0, 'breach' => 0, 'warning' => 0, 'active' => 0],
                'items' => [],
            ];
        }

        $rows = DB::fetchAll(
            'SELECT entity_type, entity_id, stage, owner_role, owner_display, escalation_level, escalation_state, escalated_at, blocked_since, ready_since, entered_stage_at, updated_at, created_at
             FROM handoff_tracking
             WHERE released_since IS NULL AND (' . implode(' OR ', $clauses) . ')
             ORDER BY updated_at DESC, created_at DESC',
            $params
        );

        $counts = ['blocked' => 0, 'escalated' => 0, 'breach' => 0, 'warning' => 0, 'active' => count($rows)];
        $items = [];
        $now = date('Y-m-d H:i:s');
        foreach ($rows as $row) {
            $stage = (string)($row['stage'] ?? '');
            $ageHours = self::hoursDiff(self::stageSinceAt($row), $now);
            $slaLevel = self::evaluateSlaLevel($stage, $ageHours);
            $isBlocked = trim((string)($row['blocked_since'] ?? '')) !== '';
            $isEscalated = trim((string)($row['escalated_at'] ?? '')) !== '' || trim((string)($row['escalation_state'] ?? '')) !== '';

            if ($isBlocked) {
                $counts['blocked']++;
            }
            if ($isEscalated) {
                $counts['escalated']++;
            }
            if ($slaLevel === 'breach') {
                $counts['breach']++;
            } elseif ($slaLevel === 'warning') {
                $counts['warning']++;
            }

            $items[] = [
                'entity_type' => (string)($row['entity_type'] ?? ''),
                'entity_id' => (int)($row['entity_id'] ?? 0),
                'stage' => $stage,
                'stage_label' => (string)(self::SLA_HOURS[$stage]['label'] ?? $stage),
                'owner_role' => displayRole(self::fallbackOwner($stage, (string)($row['owner_role'] ?? ''))),
                'owner_display' => (string)($row['owner_display'] ?? ''),
                'age_hours' => $ageHours,
                'sla_level' => $slaLevel,
                'is_blocked' => $isBlocked,
                'is_escalated' => $isEscalated,
            ];
        }

        usort($items, static function (array $a, array $b): int {
            $rank = ['breach' => 0, 'warning' => 1, 'ok' => 2];
            $aRank = $rank[(string)($a['sla_level'] ?? 'ok')] ?? 2;
            $bRank = $rank[(string)($b['sla_level'] ?? 'ok')] ?? 2;
            if ($aRank !== $bRank) {
                return $aRank <=> $bRank;
            }
            if ((bool)($a['is_blocked'] ?? false) !== (bool)($b['is_blocked'] ?? false)) {
                return ((bool)($b['is_blocked'] ?? false) <=> (bool)($a['is_blocked'] ?? false));
            }
            return ((float)($b['age_hours'] ?? 0)) <=> ((float)($a['age_hours'] ?? 0));
        });

        return ['counts' => $counts, 'items' => array_slice($items, 0, 20)];
    }

    /**
     * @param array<string,mixed> $product
     * @param array<string,mixed> $demandSummary
     * @param array<string,mixed> $qcSummary
     * @param array<string,mixed> $dispatchSummary
     * @param array<int,array<string,mixed>> $machineMappings
     * @param array<string,mixed> $handoff
     * @return array<string,mixed>
     */
    private static function riskSummary(array $product, array $demandSummary, array $qcSummary, array $dispatchSummary, array $machineMappings, array $handoff): array
    {
        $handoffCounts = (array)($handoff['counts'] ?? []);
        $reasons = [];

        if ((float)($demandSummary['shortage_qty'] ?? 0) > 0) {
            $reasons[] = 'Open orders are short by ' . number_format((float)$demandSummary['shortage_qty'], 2, '.', ',') . ' units.';
        }
        if ((int)($demandSummary['due_within_48h'] ?? 0) > 0 && (float)($demandSummary['shortage_qty'] ?? 0) > 0) {
            $reasons[] = (int)$demandSummary['due_within_48h'] . ' open order(s) are due within 48h under partial/low coverage.';
        }
        if ((float)($qcSummary['fail_qty'] ?? 0) > 0) {
            $reasons[] = 'QC failures total ' . number_format((float)$qcSummary['fail_qty'], 2, '.', ',') . ' units in recent entries.';
        }
        if ((int)($dispatchSummary['blocked_entries'] ?? 0) > 0) {
            $reasons[] = (int)$dispatchSummary['blocked_entries'] . ' dispatch row(s) are blocked or on hold.';
        }
        if ((int)($handoffCounts['blocked'] ?? 0) > 0 || (int)($handoffCounts['breach'] ?? 0) > 0) {
            $reasons[] = 'Active handoffs include ' . (int)($handoffCounts['blocked'] ?? 0) . ' blocked and ' . (int)($handoffCounts['breach'] ?? 0) . ' breached item(s).';
        }
        if (empty($machineMappings)) {
            $reasons[] = 'No machine mapping is active for this part.';
        }
        if (empty($reasons)) {
            $reasons[] = 'Demand, execution, QC, and dispatch signals are currently within normal operating range.';
        }

        $state = 'healthy';
        $label = 'Healthy';
        if ((int)($handoffCounts['blocked'] ?? 0) > 0 || (int)($dispatchSummary['blocked_entries'] ?? 0) > 0) {
            $state = 'blocked';
            $label = 'Blocked';
        } elseif ((float)($demandSummary['shortage_qty'] ?? 0) > 0
            || (float)($qcSummary['fail_qty'] ?? 0) > 0
            || (int)($handoffCounts['escalated'] ?? 0) > 0
            || (int)($demandSummary['low_coverage_orders'] ?? 0) > 0) {
            $state = 'under_pressure';
            $label = 'Under Pressure';
        }

        return [
            'state' => $state,
            'label' => $label,
            'highlights' => array_slice($reasons, 0, 6),
        ];
    }

    /**
     * @param array<string,mixed> $row
     */
    private static function stageSinceAt(array $row): string
    {
        $candidates = [
            trim((string)($row['blocked_since'] ?? '')),
            trim((string)($row['ready_since'] ?? '')),
            trim((string)($row['entered_stage_at'] ?? '')),
            trim((string)($row['updated_at'] ?? '')),
            trim((string)($row['created_at'] ?? '')),
        ];
        foreach ($candidates as $candidate) {
            if ($candidate !== '') {
                return $candidate;
            }
        }
        return date('Y-m-d H:i:s');
    }

    private static function evaluateSlaLevel(string $stage, float $ageHours): string
    {
        $policy = self::SLA_HOURS[$stage] ?? null;
        if ($policy === null) {
            return 'ok';
        }
        if ($ageHours >= (float)$policy['breach']) {
            return 'breach';
        }
        if ($ageHours >= (float)$policy['warn']) {
            return 'warning';
        }
        return 'ok';
    }

    private static function fallbackOwner(string $stage, string $ownerRole): string
    {
        $ownerRole = trim($ownerRole);
        if ($ownerRole !== '') {
            return $ownerRole;
        }
        if ($stage === 'production_to_qc') {
            return 'QC';
        }
        if ($stage === 'qc_to_dispatch' || $stage === 'dispatch_to_completion') {
            return 'Dispatch';
        }
        if ($stage === 'order_risk') {
            return 'Production';
        }
        return 'Unassigned / System issue';
    }

    private static function hoursDiff(string $fromTs, string $toTs): float
    {
        try {
            $from = new \DateTime($fromTs);
            $to = new \DateTime($toTs);
        } catch (\Throwable $e) {
            return 0.0;
        }

        $seconds = $to->getTimestamp() - $from->getTimestamp();
        if ($seconds <= 0) {
            return 0.0;
        }
        return round($seconds / 3600, 2);
    }

    private static function shiftDate(string $date, int $days): string
    {
        try {
            $dt = new \DateTime($date);
            $dt->modify(($days >= 0 ? '+' : '') . $days . ' day');
            return $dt->format('Y-m-d');
        } catch (\Throwable $e) {
            return date('Y-m-d');
        }
    }

    /**
     * @param array<int,string> $clauses
     * @param array<int,mixed> $params
     * @param array<int,int> $ids
     */
    private static function appendEntityInClause(array &$clauses, array &$params, string $entityType, array $ids): void
    {
        if (empty($ids)) {
            return;
        }

        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $clauses[] = '(entity_type = ? AND entity_id IN (' . $placeholders . '))';
        $params[] = $entityType;
        foreach ($ids as $id) {
            $params[] = (int)$id;
        }
    }

    private static function tableExists(string $tableName): bool
    {
        $escaped = DB::conn()->real_escape_string($tableName);
        return DB::fetchOne("SHOW TABLES LIKE '{$escaped}'") !== null;
    }
}
