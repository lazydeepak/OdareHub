<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>

<div class="card">
  <div class="module-header">
    <div class="module-header-info">
      <h2>Import Parts CSV</h2>
      <div class="muted">Columns: parts_name, parts_number, model, producer, lead, cycle_time, notes, is_active, supply_mode, fulfillment_mode, requires_ipm_qc, default_supplier, stocked_at_ipm, default_procurement_lead_days, default_supply_note</div>
    </div>
    <div class="module-header-actions"><a class="btn" href="/products">Back to List</a></div>
  </div>
</div>

<?php if (!empty($flash ?? '')): ?><div class="card notice-ok"><?= e((string)$flash) ?></div><?php endif; ?>
<?php if (!empty($error ?? '')): ?><div class="card notice-err"><?= e((string)$error) ?></div><?php endif; ?>

<div class="card">
  <form method="post" action="/products/import" enctype="multipart/form-data" class="form-grid">
    <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
    <div class="form-field-wide">
      <label class="field-label">CSV File</label>
      <input type="file" name="csv" accept=".csv,text/csv" required>
    </div>
    <div class="form-actions">
      <button class="btn ok" type="submit">Import</button>
      <a class="btn" href="/products">Cancel</a>
    </div>
  </form>
</div>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
