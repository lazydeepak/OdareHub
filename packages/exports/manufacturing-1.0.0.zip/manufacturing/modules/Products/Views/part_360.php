<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$payload = is_array($payload ?? null) ? $payload : [];
$product = is_array($payload['product'] ?? null) ? $payload['product'] : [];
$demandSummary = is_array($payload['demand_summary'] ?? null) ? $payload['demand_summary'] : [];
$openOrders = is_array($payload['open_orders'] ?? null) ? $payload['open_orders'] : [];
$stockSummary = is_array($payload['stock_summary'] ?? null) ? $payload['stock_summary'] : [];
$recentLedger = is_array($payload['recent_ledger'] ?? null) ? $payload['recent_ledger'] : [];
$plannedSupplySummary = is_array($payload['planned_supply_summary'] ?? null) ? $payload['planned_supply_summary'] : [];
$productionSummary = is_array($payload['production_summary'] ?? null) ? $payload['production_summary'] : [];
$recentProductionPlans = is_array($payload['recent_production_plans'] ?? null) ? $payload['recent_production_plans'] : [];
$recentProductionEntries = is_array($payload['recent_production_entries'] ?? null) ? $payload['recent_production_entries'] : [];
$qcSummary = is_array($payload['qc_summary'] ?? null) ? $payload['qc_summary'] : [];
$recentQcPlans = is_array($payload['recent_qc_plans'] ?? null) ? $payload['recent_qc_plans'] : [];
$recentQcEntries = is_array($payload['recent_qc_entries'] ?? null) ? $payload['recent_qc_entries'] : [];
$dispatchSummary = is_array($payload['dispatch_summary'] ?? null) ? $payload['dispatch_summary'] : [];
$recentDispatchEntries = is_array($payload['recent_dispatch_entries'] ?? null) ? $payload['recent_dispatch_entries'] : [];
$machineMappings = is_array($payload['machine_mappings'] ?? null) ? $payload['machine_mappings'] : [];
$machineUsage = is_array($payload['machine_usage'] ?? null) ? $payload['machine_usage'] : [];
$handoff = is_array($payload['handoff'] ?? null) ? $payload['handoff'] : [];
$handoffCounts = is_array($handoff['counts'] ?? null) ? $handoff['counts'] : [];
$handoffItems = is_array($handoff['items'] ?? null) ? $handoff['items'] : [];
$riskSummary = is_array($payload['risk_summary'] ?? null) ? $payload['risk_summary'] : [];
$links = is_array($payload['links'] ?? null) ? $payload['links'] : [];
$supplyProfile = is_array($payload['supply_profile'] ?? null) ? $payload['supply_profile'] : [];
$operationalSnapshot = is_array($payload['operational_snapshot'] ?? null) ? $payload['operational_snapshot'] : [];
$orderContext = is_array($payload['order_context'] ?? null) ? $payload['order_context'] : [];
$workflowContext = is_array($payload['workflow_context'] ?? null) ? $payload['workflow_context'] : [];
$recommendedActions = is_array($payload['recommended_actions'] ?? null) ? $payload['recommended_actions'] : [];
$timeline = is_array($payload['timeline'] ?? null) ? $payload['timeline'] : [];
$currentRole = strtolower(trim((string)($current_role ?? '')));

$fmt = static function (float $n, int $precision = 2): string {
    return number_format($n, $precision, '.', ',');
};

$riskBadge = static function (string $state): string {
    $s = strtolower(trim($state));
    if ($s === 'blocked') {
        return 'p360-badge-bad';
    }
    if ($s === 'under_pressure') {
        return 'p360-badge-warn';
    }
    return 'p360-badge-good';
};

$sourceUrl = static function (string $module, int $id): string {
    if ($id <= 0) {
        return '#';
    }
    $map = [
        'ProductionEntries' => '/production-entries/edit?id=',
        'DispatchEntries' => '/dispatch-entries/edit?id=',
        'QCEntries' => '/qc-entries/edit?id=',
        'ProductionPlans' => '/production-plans/edit?id=',
        'QCPlans' => '/qc-plans/edit?id=',
    ];
    return ($map[$module] ?? '#') . $id;
};

$handoffUrl = static function (string $entityType, int $entityId): string {
    if ($entityId <= 0) {
        return '#';
    }
    if ($entityType === 'daily_order') {
        return '/daily-orders/360?id=' . $entityId;
    }
    if ($entityType === 'production_entry') {
        return '/production-entries/edit?id=' . $entityId;
    }
    if ($entityType === 'qc_entry') {
        return '/qc-entries/edit?id=' . $entityId;
    }
    if ($entityType === 'dispatch_entry') {
        return '/dispatch-entries/edit?id=' . $entityId;
    }
    return '#';
};

$roleToken = static function (string $role): string {
  $role = strtolower(trim($role));
  if ($role === '' || $role === 'all') {
    return 'all';
  }
  if (str_contains($role, 'dispatch')) {
    return 'dispatch';
  }
  if (str_contains($role, 'qc')) {
    return 'qc';
  }
  if (str_contains($role, 'machine')) {
    return 'machine';
  }
  if (str_contains($role, 'plan')) {
    return 'planning';
  }
  if (str_contains($role, 'admin')) {
    return 'admin';
  }
  return 'all';
};

$roleGroup = $roleToken($currentRole);
$actionVisible = static function (array $action, string $roleGroup): bool {
  $roles = array_map(static fn ($v): string => strtolower(trim((string)$v)), (array)($action['roles'] ?? ['all']));
  if (in_array('all', $roles, true) || in_array($roleGroup, $roles, true)) {
    return true;
  }
  return $roleGroup === 'admin';
};
?>

<style>
.p360-hero { display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap; align-items:flex-start; }
.p360-title { margin:0; font-size:1.42rem; }
.p360-sub { margin-top:6px; color:var(--muted); font-size:.9rem; max-width:860px; }
.p360-actions { display:flex; gap:8px; flex-wrap:wrap; }
.p360-grid { display:grid; gap:12px; grid-template-columns:repeat(auto-fit,minmax(230px,1fr)); }
.p360-card { border:1px solid var(--glass-border); border-radius:12px; background:linear-gradient(160deg,rgba(255,255,255,.05),rgba(255,255,255,.02)); padding:10px 12px; }
.p360-kpi { font-size:1.28rem; font-weight:800; margin-top:4px; }
.p360-muted { color:var(--muted); font-size:.82rem; }
.p360-table-wrap { overflow:auto; border:1px solid var(--glass-border); border-radius:12px; }
.p360-table { width:100%; border-collapse:collapse; min-width:920px; }
.p360-table th, .p360-table td { padding:8px 10px; border-bottom:1px solid rgba(255,255,255,.08); text-align:left; vertical-align:top; font-size:.82rem; }
.p360-table th { color:var(--muted); background:rgba(255,255,255,.03); font-weight:600; }
.p360-section-title { margin:0 0 8px; font-size:1rem; }
.p360-empty { color:var(--muted); font-size:.84rem; }
.p360-badge { border-radius:999px; border:1px solid; padding:3px 9px; font-size:.72rem; white-space:nowrap; }
.p360-badge-good { color:#9fe8bf; border-color:rgba(90,210,130,.4); background:rgba(90,210,130,.14); }
.p360-badge-warn { color:#ffd483; border-color:rgba(255,194,72,.4); background:rgba(255,188,71,.15); }
.p360-badge-bad { color:#ff9d9d; border-color:rgba(255,102,102,.4); background:rgba(255,80,80,.14); }
.p360-list { margin:0; padding-left:18px; }
</style>

<section class="card">
  <div class="p360-hero">
    <div>
      <h2 class="p360-title">Part 360 - <?= e((string)($product['parts_name'] ?? '-')) ?> (<?= e((string)($product['parts_number'] ?? '-')) ?>)</h2>
      <div class="p360-sub">Single-part operational truth across demand, stock, planning, execution, QC, dispatch, machine fit, and active workflow risk.</div>
      <div style="margin-top:8px" class="p360-muted">
        Model: <strong><?= e((string)($product['model'] ?? '-')) ?></strong> |
        Producer: <strong><?= e((string)($product['producer'] ?? '-')) ?></strong> |
        Lead: <strong><?= e((string)($product['lead'] ?? '-')) ?></strong> |
        Cycle Time: <strong><?= e((string)($product['cycle_time'] ?? '-')) ?></strong> |
        Supply Mode: <strong><?= e((string)($product['supply_mode'] ?? 'in_house')) ?></strong> |
        Fulfillment Mode: <strong><?= e((string)($product['fulfillment_mode'] ?? 'via_ipm')) ?></strong> |
        Requires IPM QC: <strong><?= ((int)($product['requires_ipm_qc'] ?? 1) === 1) ? 'Yes' : 'No' ?></strong> |
        Status: <strong><?= (int)($product['is_active'] ?? 1) === 1 ? 'Active' : 'Inactive' ?></strong>
      </div>
    </div>
    <div class="p360-actions">
      <a class="btn" href="<?= e((string)($links['part_list'] ?? '/products')) ?>">Back to Parts</a>
      <a class="btn" href="<?= e((string)($links['part_edit'] ?? '#')) ?>">Edit Part</a>
      <a class="btn" href="<?= e((string)($links['ledger'] ?? '#')) ?>">Stock Ledger</a>
      <a class="btn" href="<?= e((string)($links['orders_search'] ?? '/daily-orders')) ?>">Related Orders</a>
      <a class="btn" href="<?= e((string)($links['part_machine_map'] ?? '/part-machine-map')) ?>">Machine Map</a>
    </div>
  </div>
</section>

<section class="card">
  <h3 class="p360-section-title">Supply and Fulfillment Profile</h3>
  <div class="p360-grid">
    <div class="p360-card"><div class="p360-muted">Supply Mode</div><div class="p360-kpi" style="font-size:1rem"><?= e((string)($supplyProfile['supply_mode'] ?? '-')) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Fulfillment Mode</div><div class="p360-kpi" style="font-size:1rem"><?= e((string)($supplyProfile['fulfillment_mode'] ?? '-')) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Requires IPM QC</div><div class="p360-kpi" style="font-size:1rem"><?= !empty($supplyProfile['requires_ipm_qc']) ? 'Yes' : 'No' ?></div></div>
    <div class="p360-card"><div class="p360-muted">Stocked at IPM</div><div class="p360-kpi" style="font-size:1rem"><?= !empty($supplyProfile['stocked_at_ipm']) ? 'Yes' : 'No' ?></div></div>
    <div class="p360-card"><div class="p360-muted">Default Supplier</div><div class="p360-kpi" style="font-size:1rem"><?= e((string)($supplyProfile['default_supplier'] ?? '-')) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Lead Days</div><div class="p360-kpi" style="font-size:1rem"><?= e($fmt((float)($supplyProfile['default_procurement_lead_days'] ?? 0), 0)) ?></div></div>
  </div>
  <div class="p360-card" style="margin-top:10px">
    <div class="p360-muted">Flow Narrative</div>
    <div><?= e((string)($supplyProfile['flow_narrative'] ?? '-')) ?></div>
    <?php if (trim((string)($supplyProfile['default_supply_note'] ?? '')) !== ''): ?>
      <div class="p360-muted" style="margin-top:6px">Supply Note: <?= e((string)$supplyProfile['default_supply_note']) ?></div>
    <?php endif; ?>
  </div>
</section>

<section class="card">
  <h3 class="p360-section-title">Current Workflow Context</h3>
  <div class="p360-grid">
    <div class="p360-card"><div class="p360-muted">Operational Stage</div><div class="p360-kpi" style="font-size:1rem"><?= e((string)($workflowContext['stage_label'] ?? '-')) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Planning Needed</div><div class="p360-kpi" style="font-size:1rem"><?= !empty($workflowContext['planning_needed']) ? 'Yes' : 'No' ?></div></div>
    <div class="p360-card"><div class="p360-muted">Awaiting QC</div><div class="p360-kpi" style="font-size:1rem"><?= !empty($workflowContext['awaiting_qc']) ? 'Yes' : 'No' ?></div></div>
    <div class="p360-card"><div class="p360-muted">Ready for Dispatch</div><div class="p360-kpi" style="font-size:1rem"><?= !empty($workflowContext['ready_for_dispatch']) ? 'Yes' : 'No' ?></div></div>
    <div class="p360-card"><div class="p360-muted">Partially Released</div><div class="p360-kpi" style="font-size:1rem"><?= !empty($workflowContext['partially_released']) ? 'Yes' : 'No' ?></div></div>
    <div class="p360-card"><div class="p360-muted">Supply Blocked</div><div class="p360-kpi" style="font-size:1rem"><?= !empty($workflowContext['supply_blocked']) ? 'Yes' : 'No' ?></div></div>
  </div>
</section>

<section class="card">
  <div class="p360-grid">
    <div class="p360-card">
      <div class="p360-muted">Current State</div>
      <div class="p360-kpi" style="font-size:1rem"><span class="p360-badge <?= e($riskBadge((string)($riskSummary['state'] ?? 'healthy'))) ?>"><?= e((string)($riskSummary['label'] ?? 'Healthy')) ?></span></div>
    </div>
    <div class="p360-card"><div class="p360-muted">Open Orders</div><div class="p360-kpi"><?= (int)($demandSummary['open_orders'] ?? 0) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Open Demand Qty</div><div class="p360-kpi"><?= e($fmt((float)($demandSummary['open_demand_qty'] ?? 0))) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Current Stock</div><div class="p360-kpi"><?= e($fmt((float)($stockSummary['current_balance'] ?? 0))) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Planned Supply</div><div class="p360-kpi"><?= e($fmt((float)($plannedSupplySummary['planned_qty'] ?? 0))) ?></div></div>
    <div class="p360-card"><div class="p360-muted">QC Pass / Fail</div><div class="p360-kpi"><?= e($fmt((float)($qcSummary['pass_qty'] ?? 0))) ?> / <?= e($fmt((float)($qcSummary['fail_qty'] ?? 0))) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Ready / Dispatched</div><div class="p360-kpi"><?= e($fmt((float)($dispatchSummary['ready_qty'] ?? 0))) ?> / <?= e($fmt((float)($dispatchSummary['dispatched_qty'] ?? 0))) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Blocked / Escalated Handoffs</div><div class="p360-kpi"><?= (int)($handoffCounts['blocked'] ?? 0) ?> / <?= (int)($handoffCounts['escalated'] ?? 0) ?></div></div>
  </div>
  <div class="p360-card" style="margin-top:10px">
    <div class="p360-muted">Why this part is <?= e(strtolower((string)($riskSummary['label'] ?? 'healthy'))) ?></div>
    <ul class="p360-list">
      <?php foreach ((array)($riskSummary['highlights'] ?? []) as $line): ?>
        <li><?= e((string)$line) ?></li>
      <?php endforeach; ?>
    </ul>
  </div>
</section>

<section class="card">
  <h3 class="p360-section-title">Operational Snapshot</h3>
  <div class="p360-grid">
    <div class="p360-card"><div class="p360-muted">Current Stock / Open Demand</div><div class="p360-kpi"><?= e($fmt((float)($operationalSnapshot['current_stock_qty'] ?? 0))) ?> / <?= e($fmt((float)($operationalSnapshot['open_demand_qty'] ?? 0))) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Planned Supply</div><div class="p360-kpi"><?= e($fmt((float)($operationalSnapshot['planned_supply_qty'] ?? 0))) ?></div></div>
    <div class="p360-card"><div class="p360-muted">QC Pending / Pass</div><div class="p360-kpi"><?= e($fmt((float)($operationalSnapshot['qc_pending_qty'] ?? 0))) ?> / <?= e($fmt((float)($operationalSnapshot['qc_pass_qty'] ?? 0))) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Dispatch Pending / Released</div><div class="p360-kpi"><?= e($fmt((float)($operationalSnapshot['dispatch_pending_qty'] ?? 0))) ?> / <?= e($fmt((float)($operationalSnapshot['dispatch_released_qty'] ?? 0))) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Coverage Pressure Qty</div><div class="p360-kpi"><?= e($fmt((float)($operationalSnapshot['coverage_pressure_qty'] ?? 0))) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Low Coverage Orders</div><div class="p360-kpi"><?= (int)($operationalSnapshot['low_coverage_orders'] ?? 0) ?></div></div>
  </div>
</section>

<?php if (!empty($recommendedActions)): ?>
<section class="card">
  <h3 class="p360-section-title">Recommended Next Actions</h3>
  <div class="p360-grid">
    <?php foreach ($recommendedActions as $action): ?>
      <?php if (!$actionVisible((array)$action, $roleGroup)) { continue; } ?>
      <div class="p360-card">
        <div style="font-weight:700"><?= e((string)($action['label'] ?? 'Action')) ?></div>
        <div class="p360-muted" style="margin-top:4px"><?= e((string)($action['intent'] ?? '')) ?></div>
        <div style="margin-top:8px">
          <?php if ((string)($action['method'] ?? 'link') === 'post'): ?>
            <form method="post" action="<?= e((string)($action['url'] ?? '#')) ?>" style="margin:0;display:flex;gap:6px;flex-wrap:wrap">
              <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
              <?php foreach ((array)($action['post'] ?? []) as $key => $value): ?>
                <input type="hidden" name="<?= e((string)$key) ?>" value="<?= e((string)$value) ?>">
              <?php endforeach; ?>
              <button class="btn" type="submit"><?= e((string)($action['label'] ?? 'Run')) ?></button>
            </form>
          <?php else: ?>
            <a class="btn" href="<?= e((string)($action['url'] ?? '#')) ?>"><?= e((string)($action['label'] ?? 'Open')) ?></a>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<section class="card">
  <h3 class="p360-section-title">Related Demand Buckets</h3>
  <div class="p360-grid">
    <div class="p360-card"><div class="p360-muted">Urgent Orders (<=48h)</div><div class="p360-kpi" style="font-size:1rem"><?= count((array)($orderContext['urgent_orders'] ?? [])) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Low Coverage Orders</div><div class="p360-kpi" style="font-size:1rem"><?= count((array)($orderContext['low_coverage_orders'] ?? [])) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Partial Coverage Orders</div><div class="p360-kpi" style="font-size:1rem"><?= count((array)($orderContext['partial_orders'] ?? [])) ?></div></div>
  </div>
</section>

<section class="card">
  <h3 class="p360-section-title">Demand, Supply, and Execution Snapshot</h3>
  <div class="p360-grid">
    <div class="p360-card"><div class="p360-muted">Demand Qty</div><div class="p360-kpi"><?= e($fmt((float)($demandSummary['demand_qty'] ?? 0))) ?></div><div class="p360-muted">Avg coverage <?= e($fmt((float)($demandSummary['avg_coverage_pct'] ?? 0))) ?>%</div></div>
    <div class="p360-card"><div class="p360-muted">Shortage Qty</div><div class="p360-kpi" style="color:#ffb3b3"><?= e($fmt((float)($demandSummary['shortage_qty'] ?? 0))) ?></div><div class="p360-muted">Low coverage orders <?= (int)($demandSummary['low_coverage_orders'] ?? 0) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Due within 48h</div><div class="p360-kpi"><?= (int)($demandSummary['due_within_48h'] ?? 0) ?></div><div class="p360-muted">Next due <?= e((string)($demandSummary['next_due_at'] ?? '-')) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Total In / Out</div><div class="p360-kpi"><?= e($fmt((float)($stockSummary['total_in_qty'] ?? 0))) ?> / <?= e($fmt((float)($stockSummary['total_out_qty'] ?? 0))) ?></div><div class="p360-muted">Production in <?= e($fmt((float)($stockSummary['production_in_qty'] ?? 0))) ?> | Dispatch out <?= e($fmt((float)($stockSummary['dispatch_out_qty'] ?? 0))) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Today's Planned Qty</div><div class="p360-kpi"><?= e($fmt((float)($plannedSupplySummary['today_planned_qty'] ?? 0))) ?></div><div class="p360-muted">Upcoming <?= e($fmt((float)($plannedSupplySummary['upcoming_planned_qty'] ?? 0))) ?></div></div>
    <div class="p360-card"><div class="p360-muted">Produced / Good / Rejected</div><div class="p360-kpi"><?= e($fmt((float)($productionSummary['produced_qty'] ?? 0))) ?> / <?= e($fmt((float)($productionSummary['good_qty'] ?? 0))) ?> / <?= e($fmt((float)($productionSummary['rejected_qty'] ?? 0))) ?></div><div class="p360-muted">Recent entries <?= (int)($productionSummary['entries'] ?? 0) ?></div></div>
  </div>
</section>

<section class="card">
  <h3 class="p360-section-title">Open Demand by Order</h3>
  <?php if (empty($openOrders)): ?>
    <div class="p360-empty">No open orders for this part.</div>
  <?php else: ?>
    <div class="p360-table-wrap">
      <table class="p360-table">
        <thead><tr><th>Order</th><th>Customer</th><th>Demand</th><th>Open Demand</th><th>Coverage</th><th>Shortage</th><th>Due</th><th>Action</th></tr></thead>
        <tbody>
        <?php foreach ($openOrders as $row): ?>
          <tr>
            <td>#<?= (int)($row['id'] ?? 0) ?></td>
            <td><?= e((string)($row['customer_name'] ?? '-')) ?></td>
            <td><?= e($fmt((float)($row['qty'] ?? 0))) ?></td>
            <td><?= e($fmt((float)($row['open_demand_qty'] ?? 0))) ?></td>
            <td><?= e($fmt((float)($row['coverage_pct'] ?? 0))) ?>% <span class="p360-muted"><?= e((string)($row['coverage_status'] ?? '-')) ?></span></td>
            <td><?= e($fmt((float)($row['shortage_qty'] ?? 0))) ?></td>
            <td><?= e((string)($row['dispatch_deadline'] ?? $row['required_date'] ?? '-')) ?></td>
            <td><a class="btn" href="/daily-orders/360?id=<?= (int)($row['id'] ?? 0) ?>">Order 360</a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<section class="p360-grid card">
  <div class="p360-card">
    <h3 class="p360-section-title">Machine Mappings</h3>
    <?php if (empty($machineMappings)): ?>
      <div class="p360-empty">No part-machine mappings exist.</div>
    <?php else: ?>
      <div class="p360-table-wrap">
        <table class="p360-table" style="min-width:620px">
          <thead><tr><th>Machine</th><th>Section</th><th>Status</th><th>Capacity/hr</th><th>Mapping</th></tr></thead>
          <tbody>
          <?php foreach ($machineMappings as $row): ?>
            <tr>
              <td><?= e((string)($row['machine_no'] ?? '-')) ?> <?= e((string)($row['machine_name'] ?? '')) ?></td>
              <td><?= e((string)($row['section'] ?? '-')) ?></td>
              <td><?= e((string)($row['machine_status'] ?? '-')) ?> / <?= (int)($row['is_active'] ?? 0) === 1 ? 'Active map' : 'Inactive map' ?></td>
              <td><?= e($fmt((float)($row['capacity_per_hour'] ?? 0))) ?></td>
              <td><a class="btn" href="/part-machine-map?q=<?= urlencode((string)($product['parts_number'] ?? '')) ?>">Open Map</a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <div class="p360-card">
    <h3 class="p360-section-title">Machine Usage</h3>
    <?php if (empty($machineUsage)): ?>
      <div class="p360-empty">No recent production usage found.</div>
    <?php else: ?>
      <div class="p360-table-wrap">
        <table class="p360-table" style="min-width:640px">
          <thead><tr><th>Machine</th><th>Planned Runs</th><th>Planned Qty</th><th>Produced Runs</th><th>Good Qty</th></tr></thead>
          <tbody>
          <?php foreach ($machineUsage as $row): ?>
            <tr>
              <td><?= e((string)($row['machine_no'] ?? '-')) ?> <?= e((string)($row['machine_name'] ?? '')) ?></td>
              <td><?= (int)($row['plan_count'] ?? 0) ?></td>
              <td><?= e($fmt((float)($row['planned_qty'] ?? 0))) ?></td>
              <td><?= (int)($row['entry_count'] ?? 0) ?></td>
              <td><?= e($fmt((float)($row['good_qty'] ?? 0))) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <div class="p360-card">
    <h3 class="p360-section-title">Current Bottlenecks / Handoffs</h3>
    <div class="p360-muted" style="margin-bottom:8px">Active <?= (int)($handoffCounts['active'] ?? 0) ?> | blocked <?= (int)($handoffCounts['blocked'] ?? 0) ?> | escalated <?= (int)($handoffCounts['escalated'] ?? 0) ?> | breach <?= (int)($handoffCounts['breach'] ?? 0) ?></div>
    <?php if (empty($handoffItems)): ?>
      <div class="p360-empty">No active workflow bottlenecks for this part.</div>
    <?php else: ?>
      <ul class="p360-list">
        <?php foreach ($handoffItems as $row): ?>
          <li>
            <?= e((string)($row['stage_label'] ?? '-')) ?> on <?= e((string)($row['entity_type'] ?? '-')) ?> #<?= (int)($row['entity_id'] ?? 0) ?>,
            owner <?= e((string)($row['owner_role'] ?? '-')) ?>,
            age <?= e($fmt((float)($row['age_hours'] ?? 0))) ?>h
            <a href="<?= e($handoffUrl((string)($row['entity_type'] ?? ''), (int)($row['entity_id'] ?? 0))) ?>">open</a>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
</section>

<?php
$renderList = static function (string $title, string $emptyText, array $rows, callable $renderer): void {
?>
<section class="card">
  <h3 class="p360-section-title"><?= e($title) ?></h3>
  <?php if (empty($rows)): ?>
    <div class="p360-empty"><?= e($emptyText) ?></div>
  <?php else: ?>
    <div class="p360-table-wrap"><?php $renderer($rows); ?></div>
  <?php endif; ?>
</section>
<?php
};

$renderList('Recent Production Plans', 'No recent production plans for this part.', $recentProductionPlans, static function (array $rows) use ($fmt): void {
?>
<table class="p360-table"><thead><tr><th>ID</th><th>Date</th><th>Machine</th><th>Planned Qty</th><th>Status</th><th>Approval</th><th>Lock</th><th>Action</th></tr></thead><tbody>
<?php foreach ($rows as $row): ?>
<tr><td>#<?= (int)($row['id'] ?? 0) ?></td><td><?= e((string)($row['plan_date'] ?? '-')) ?></td><td><?= e((string)($row['machine_no'] ?? '-')) ?> <?= e((string)($row['machine_name'] ?? '')) ?></td><td><?= e($fmt((float)($row['planned_qty'] ?? 0))) ?></td><td><?= e((string)($row['status'] ?? '-')) ?></td><td><?= e((string)($row['approval_status'] ?? 'Draft')) ?></td><td><?= trim((string)($row['locked_at'] ?? '')) !== '' ? 'Locked' : 'Open' ?></td><td><a class="btn" href="/production-plans/edit?id=<?= (int)($row['id'] ?? 0) ?>">Open</a></td></tr>
<?php endforeach; ?>
</tbody></table>
<?php
});

$renderList('Recent Production Entries', 'No recent production entries for this part.', $recentProductionEntries, static function (array $rows) use ($fmt): void {
?>
<table class="p360-table"><thead><tr><th>ID</th><th>Date</th><th>Machine</th><th>Produced</th><th>Good</th><th>Rejected</th><th>Action</th></tr></thead><tbody>
<?php foreach ($rows as $row): ?>
<tr><td>#<?= (int)($row['id'] ?? 0) ?></td><td><?= e((string)($row['production_date'] ?? '-')) ?></td><td><?= e((string)($row['machine_no'] ?? '-')) ?> <?= e((string)($row['machine_name'] ?? '')) ?></td><td><?= e($fmt((float)($row['produced_qty'] ?? 0))) ?></td><td><?= e($fmt((float)($row['good_qty'] ?? 0))) ?></td><td><?= e($fmt((float)($row['rejected_qty'] ?? 0))) ?></td><td><a class="btn" href="/production-entries/edit?id=<?= (int)($row['id'] ?? 0) ?>">Open</a></td></tr>
<?php endforeach; ?>
</tbody></table>
<?php
});

$renderList('Recent QC Plans', 'No recent QC plans for this part.', $recentQcPlans, static function (array $rows) use ($fmt): void {
?>
<table class="p360-table"><thead><tr><th>ID</th><th>Date</th><th>Required</th><th>Planned Qty</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php foreach ($rows as $row): ?>
<tr><td>#<?= (int)($row['id'] ?? 0) ?></td><td><?= e((string)($row['plan_date'] ?? '-')) ?></td><td><?= e((string)($row['required_date'] ?? '-')) ?></td><td><?= e($fmt((float)($row['planned_qty'] ?? 0))) ?></td><td><?= e((string)($row['status'] ?? '-')) ?></td><td><a class="btn" href="/qc-plans/edit?id=<?= (int)($row['id'] ?? 0) ?>">Open</a><?php if ((int)($row['daily_order_id'] ?? 0) > 0): ?> <a class="btn" href="/daily-orders/360?id=<?= (int)($row['daily_order_id'] ?? 0) ?>">Order 360</a><?php endif; ?></td></tr>
<?php endforeach; ?>
</tbody></table>
<?php
});

$renderList('Recent QC Entries', 'No recent QC entries for this part.', $recentQcEntries, static function (array $rows) use ($fmt, $product): void {
?>
<table class="p360-table"><thead><tr><th>ID</th><th>Type</th><th>Checked</th><th>Pass</th><th>Fail</th><th>Status</th><th>Approval</th><th>Lock</th><th>Action</th></tr></thead><tbody>
<?php foreach ($rows as $row): ?>
<tr><td>#<?= (int)($row['id'] ?? 0) ?></td><td><?= e((string)($row['qc_type'] ?? '-')) ?></td><td><?= e($fmt((float)($row['checked_qty'] ?? 0))) ?></td><td><?= e($fmt((float)($row['pass_qty'] ?? 0))) ?></td><td><?= e($fmt((float)($row['fail_qty'] ?? 0))) ?></td><td><?= e((string)($row['status'] ?? '-')) ?></td><td><?= e((string)($row['approval_status'] ?? 'Draft')) ?></td><td><?= trim((string)($row['locked_at'] ?? '')) !== '' ? 'Locked' : 'Open' ?></td><td><a class="btn" href="/qc-entries/edit?id=<?= (int)($row['id'] ?? 0) ?>">Open</a><a class="btn" href="/ledger?product_id=<?= (int)($product['id'] ?? 0) ?>&source_module=QCEntries&source_id=<?= (int)($row['id'] ?? 0) ?>">Ledger</a><?php if ((int)($row['daily_order_id'] ?? 0) > 0): ?> <a class="btn" href="/daily-orders/360?id=<?= (int)($row['daily_order_id'] ?? 0) ?>">Order 360</a><?php endif; ?></td></tr>
<?php endforeach; ?>
</tbody></table>
<?php
});

$renderList('Recent Dispatch Entries', 'No recent dispatch entries for this part.', $recentDispatchEntries, static function (array $rows) use ($fmt, $product): void {
?>
<table class="p360-table"><thead><tr><th>ID</th><th>Date</th><th>Qty</th><th>Status</th><th>Approval</th><th>Lock</th><th>Destination</th><th>Action</th></tr></thead><tbody>
<?php foreach ($rows as $row): ?>
<tr><td>#<?= (int)($row['id'] ?? 0) ?></td><td><?= e((string)($row['dispatch_date'] ?? '-')) ?></td><td><?= e($fmt((float)($row['dispatchable_qty'] ?? 0))) ?></td><td><?= e((string)($row['dispatch_status'] ?? '-')) ?></td><td><?= e((string)($row['approval_status'] ?? 'Draft')) ?></td><td><?= trim((string)($row['locked_at'] ?? '')) !== '' || strtolower(trim((string)($row['dispatch_status'] ?? ''))) === 'dispatched' ? 'Locked' : 'Open' ?></td><td><?= e((string)($row['destination'] ?? '-')) ?></td><td><a class="btn" href="/dispatch-entries/edit?id=<?= (int)($row['id'] ?? 0) ?>">Open</a><a class="btn" href="/ledger?product_id=<?= (int)($product['id'] ?? 0) ?>&source_module=DispatchEntries&source_id=<?= (int)($row['id'] ?? 0) ?>">Ledger</a><?php if ((int)($row['daily_order_id'] ?? 0) > 0): ?> <a class="btn" href="/daily-orders/360?id=<?= (int)($row['daily_order_id'] ?? 0) ?>">Order 360</a><?php endif; ?></td></tr>
<?php endforeach; ?>
</tbody></table>
<?php
});

$renderList('Recent Stock Ledger', 'No stock ledger entries for this part.', $recentLedger, static function (array $rows) use ($fmt, $sourceUrl): void {
?>
<table class="p360-table"><thead><tr><th>When</th><th>Type</th><th>Delta</th><th>Balance</th><th>Reference</th><th>Action</th></tr></thead><tbody>
<?php foreach ($rows as $row): ?>
<tr><td><?= e((string)($row['created_at'] ?? '-')) ?></td><td><?= e((string)($row['movement_type'] ?? '-')) ?></td><td><?= e($fmt((float)($row['qty_delta'] ?? 0))) ?></td><td><?= e($fmt((float)($row['balance_after'] ?? 0))) ?></td><td><strong><?= e((string)($row['reference_no'] ?? '-')) ?></strong><br><span class="p360-muted"><?= e((string)($row['source_module'] ?? '')) ?> #<?= (int)($row['source_id'] ?? 0) ?></span></td><td><?php if ((string)($row['source_module'] ?? '') !== '' && (int)($row['source_id'] ?? 0) > 0): ?><a class="btn" href="<?= e($sourceUrl((string)($row['source_module'] ?? ''), (int)($row['source_id'] ?? 0))) ?>">Open Source</a><?php endif; ?></td></tr>
<?php endforeach; ?>
</tbody></table>
<?php
});
?>

<?php if (!empty($timeline)): ?>
<section class="card">
  <h3 class="p360-section-title">Workflow Timeline</h3>
  <div class="p360-table-wrap">
    <table class="p360-table" style="min-width:700px">
      <thead><tr><th>When</th><th>Type</th><th>Event</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach ($timeline as $event): ?>
        <tr>
          <td><?= e((string)($event['when'] ?? '')) ?></td>
          <td><?= e((string)($event['type'] ?? '')) ?></td>
          <td><?= e((string)($event['title'] ?? '')) ?></td>
          <td><?= e((string)($event['status'] ?? '')) ?></td>
          <td><a class="btn" href="<?= e((string)($event['url'] ?? '#')) ?>">Open</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>
<?php endif; ?>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>