<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>

<div class="card">
  <div class="module-header">
    <div class="module-header-info">
      <h2><?= e(t('module.products.title')) ?></h2>
      <div class="muted"><?= e(t('module.products.subtitle')) ?></div>
    </div>
    <div class="module-header-actions">
      <a class="btn ok" href="/products/add"><?= e(t('module.products.add')) ?></a>
      <a class="btn" href="/products/import"><?= e(t('common.import_csv')) ?></a>
    </div>
  </div>
</div>

<?php if (!empty($flash ?? '')): ?>
  <div class="card" style="border-color:#1d4d2f;background:rgba(0,255,140,.06)">
    <?= e((string)$flash) ?>
  </div>
<?php endif; ?>

<?php if (!empty($error ?? '')): ?>
  <div class="card" style="border-color:#5b1d2b;background:rgba(255,0,0,.06)">
    <?= e((string)$error) ?>
  </div>
<?php endif; ?>

<div class="card">
  <form method="get" action="/products" class="products-filterbar" id="productsFilterForm">
    <div class="products-filter-field products-filter-search">
      <label for="q" class="muted products-filter-label"><?= e(t('common.search')) ?></label>
      <input id="q" name="q" value="<?= e((string)$q) ?>" placeholder="<?= e(t('module.products.search_placeholder')) ?>" autocomplete="off">
    </div>
    <div class="products-filter-field products-filter-status">
      <label for="active" class="muted products-filter-label"><?= e(t('common.status')) ?></label>
      <select id="active" name="active">
        <option value="all" <?= $active === 'all' ? 'selected' : '' ?>><?= e(t('common.all')) ?></option>
        <option value="1" <?= $active === '1' ? 'selected' : '' ?>><?= e(t('common.active')) ?></option>
        <option value="0" <?= $active === '0' ? 'selected' : '' ?>><?= e(t('common.inactive')) ?></option>
      </select>
    </div>
    <div class="products-filter-actions">
      <button class="btn" type="submit"><?= e(t('common.filter')) ?></button>
      <a class="btn" href="/products"><?= e(t('common.reset')) ?></a>
    </div>
  </form>
</div>

<div class="card">
  <div class="table-wrap">
    <table id="productsTable" class="products-table">
      <thead>
      <tr>
        <th>ID</th>
        <th><?= e(t('module.products.part_name')) ?></th>
        <th><?= e(t('module.products.part_number')) ?></th>
        <th><?= e(t('common.model')) ?></th>
        <th><?= e(t('common.producer')) ?></th>
        <th><?= e(t('common.lead')) ?></th>
        <th>Supply</th>
        <th>Fulfillment</th>
        <th>IPM QC</th>
        <th>Cycle</th>
        <th><?= e(t('common.stock')) ?></th>
        <th><?= e(t('common.status')) ?></th>
        <th><?= e(t('common.updated')) ?></th>
        <th><?= e(t('common.actions')) ?></th>
      </tr>
      </thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr
          data-name="<?= e(strtolower((string)$r['parts_name'])) ?>"
          data-number="<?= e(strtolower((string)$r['parts_number'])) ?>"
          data-status="<?= (int)($r['is_active'] ?? 1) === 1 ? '1' : '0' ?>"
        >
          <td><?= e((string)$r['id']) ?></td>
          <td><?= e((string)$r['parts_name']) ?></td>
          <td><code><?= e((string)$r['parts_number']) ?></code></td>
          <td><?= e((string)($r['model'] ?? '')) ?></td>
          <td><?= e((string)($r['producer'] ?? '')) ?></td>
          <td><?= e((string)($r['lead'] ?? '')) ?></td>
          <td><?= e((string)($r['supply_mode'] ?? 'in_house')) ?></td>
          <td><?= e((string)($r['fulfillment_mode'] ?? 'via_ipm')) ?></td>
          <td><?= ((int)($r['requires_ipm_qc'] ?? 1) === 1) ? 'Yes' : 'No' ?></td>
          <td><?= ($r['cycle_time'] ?? null) !== null && (string)$r['cycle_time'] !== '' ? e((string)$r['cycle_time']) : '<span class="muted">-</span>' ?></td>
            <td><a href="/ledger?product_id=<?= (int)$r['id'] ?>"><strong><?= e((string)($r['stock_balance'] ?? '0')) ?></strong></a></td>
            <td><?php $isAct = (int)($r['is_active'] ?? 1); ?>
              <span class="pill" style="<?= $isAct ? 'border-color:#1d4d2f;color:#6effa8;background:rgba(0,255,140,.06)' : 'border-color:#5b1d2b;color:#ff8080;background:rgba(255,0,0,.06)' ?>"><?= $isAct ? e(t('common.active')) : e(t('common.inactive')) ?></span>
            </td>
            <td class="muted" style="white-space:nowrap;font-size:12px"><?= ($r['updated_at'] ?? '') !== '' ? e(date('Y-m-d H:i', strtotime((string)$r['updated_at']))) : '' ?></td>
            <td>
            <div class="row products-actions">
              <a class="btn" href="/products/360?id=<?= (int)$r['id'] ?>">Part 360</a>
              <a class="btn ok" href="/qr/product/label?product_id=<?= (int)$r['id'] ?>&copies=8" target="_blank" rel="noopener"><?= e(t('common.label')) ?></a>
              <a class="btn" href="/products/edit?id=<?= (int)$r['id'] ?>"><?= e(t('common.edit')) ?></a>
              <form method="post" action="/products/delete" onsubmit="return confirm('<?= e(t('module.products.delete_confirm')) ?>');">
                <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                <button class="btn danger" type="submit"><?= e(t('common.delete')) ?></button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <tr id="productsNoRows" <?= !empty($rows) ? 'style="display:none"' : '' ?>><td colspan="14" class="muted"><?= e(t('module.products.none')) ?></td></tr>
      </tbody>
    </table>
  </div>
  <div class="muted" style="margin-top:10px" id="productsRowSummary"><?= e(localized_records_summary(count($rows))) ?></div>
</div>

<script>
  (function () {
    const searchInput = document.getElementById('q');
    const statusSelect = document.getElementById('active');
    const table = document.getElementById('productsTable');
    const noRows = document.getElementById('productsNoRows');
    const summary = document.getElementById('productsRowSummary');
    if (!searchInput || !statusSelect || !table || !noRows || !summary) return;

    const bodyRows = Array.from(table.querySelectorAll('tbody tr')).filter((row) => row.id !== 'productsNoRows');
    const normalize = (s) => (s || '').toString().toLowerCase().trim();

    function applyLocalFilter() {
      const q = normalize(searchInput.value);
      const status = statusSelect.value;
      let shown = 0;

      bodyRows.forEach((row) => {
        const name = normalize(row.dataset.name || '');
        const number = normalize(row.dataset.number || '');
        const rowStatus = row.dataset.status || '1';

        const searchOk = q === '' || name.includes(q) || number.includes(q);
        const statusOk = status === 'all' || rowStatus === status;
        const visible = searchOk && statusOk;

        row.style.display = visible ? '' : 'none';
        if (visible) shown++;
      });

      noRows.style.display = shown === 0 ? '' : 'none';
      summary.textContent = <?= json_encode(localized_records_summary(0), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>.replace('0', String(shown));
    }

    searchInput.addEventListener('input', applyLocalFilter);
    statusSelect.addEventListener('change', applyLocalFilter);
    applyLocalFilter();
  })();
</script>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
