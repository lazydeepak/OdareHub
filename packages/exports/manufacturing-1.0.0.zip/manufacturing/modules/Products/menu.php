<?php
return [
  ['key'=>'ipm.root','label'=>'IPM','url'=>null,'parent'=>null,'order'=>30,'perm'=>null],
  ['key'=>'ipm.products','label'=>'Parts Master','url'=>'/products','parent'=>'ipm.root','order'=>10,'perm'=>null],
];
