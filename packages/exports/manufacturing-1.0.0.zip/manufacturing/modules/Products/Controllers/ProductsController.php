<?php
declare(strict_types=1);

namespace Plugins\Products\Controllers;

use App\Core\DB;
use App\Core\View;
use Plugins\Products\Services\Part360Service;
use Plugins\Products\Services\PartExecutionRouteResolver;
use Plugins\Supply\Services\SupplyModel;

require_once __DIR__ . '/../Services/Part360Service.php';
require_once __DIR__ . '/../Services/PartExecutionRouteResolver.php';

final class ProductsController
{
    public static function index(View $view): void
    {
        $q = trim((string)($_GET['q'] ?? ''));
        $active = (string)($_GET['active'] ?? 'all');

        $hasLedger = self::hasLedgerTable();
        $sql = $hasLedger
            ? "SELECT p.*, COALESCE(lb.stock_balance, 0) AS stock_balance
               FROM products p
               LEFT JOIN (
                   SELECT product_id, COALESCE(SUM(qty_delta), 0) AS stock_balance
                   FROM stock_ledger_entries
                   GROUP BY product_id
               ) lb ON lb.product_id = p.id
               WHERE 1=1"
            : "SELECT p.*, 0 AS stock_balance FROM products p WHERE 1=1";
        $params = [];

        if ($q !== '') {
            $sql .= " AND (p.parts_name LIKE ? OR p.parts_number LIKE ? OR p.model LIKE ? OR p.producer LIKE ?)";
            $like = '%' . $q . '%';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        if ($active === '1' || $active === '0') {
            $sql .= " AND p.is_active = ?";
            $params[] = (int)$active;
        }

        $sql .= " ORDER BY p.updated_at DESC, p.id DESC LIMIT 300";

        $view->render('Products::index.php', [
            'pageTitle' => 'Parts Master',
            'rows' => DB::fetchAll($sql, $params),
            'q' => $q,
            'active' => $active,
            'supply_mode_options' => self::supplyModeOptions(),
            'fulfillment_mode_options' => PartExecutionRouteResolver::getFulfillmentModeOptions(),
            'flash' => self::pullFlash('ok'),
            'error' => self::pullFlash('err'),
        ]);
    }

    public static function addForm(View $view): void
    {
        $old = $_SESSION['products_old'] ?? [];
        if ((string)($old['supply_mode'] ?? '') === '') {
            $old['supply_mode'] = SupplyModel::SUPPLY_IN_HOUSE;
        }
        if ((string)($old['fulfillment_mode'] ?? '') === '') {
            $old['fulfillment_mode'] = 'company_to_destination';
        }
        if (!array_key_exists('requires_ipm_qc', $old)) {
            $old['requires_ipm_qc'] = '1';
        }
        if (!array_key_exists('stocked_at_ipm', $old)) {
            $old['stocked_at_ipm'] = '1';
        }
        if (!array_key_exists('requires_processing', $old)) {
            $old['requires_processing'] = '1';
        }
        if (!array_key_exists('dispatch_mode', $old)) {
            $old['dispatch_mode'] = '';
        }

        $view->render('Products::add.php', [
            'pageTitle' => 'Add Part',
            'old' => $old,
            'supply_mode_options' => self::supplyModeOptions(),
            'fulfillment_mode_options' => PartExecutionRouteResolver::getFulfillmentModeOptions(),
            'dispatch_mode_options' => self::dispatchModeOptions(),
            'error' => self::pullFlash('err'),
        ]);
        unset($_SESSION['products_old']);
    }

    public static function create(array $input): void
    {
        $data = self::sanitize($input);
        $_SESSION['products_old'] = $data;

        if ($data['parts_name'] === '' || $data['parts_number'] === '') {
            self::flash('err', 'Part name and part number are required.');
            header('Location: /products/add');
            exit;
        }

        try {
            $columns = [
                'parts_name' => $data['parts_name'],
                'parts_number' => $data['parts_number'],
                'model' => $data['model'],
                'producer' => $data['producer'],
                'lead' => $data['lead'],
                'cycle_time' => $data['cycle_time'],
                'notes' => $data['notes'],
                'is_active' => $data['is_active'],
            ];

            self::appendSupplyColumns($columns, $data);

            $fieldNames = array_map(
                static fn(string $name): string => $name === 'lead' ? '`lead`' : $name,
                array_keys($columns)
            );
            $fieldSql = implode(', ', $fieldNames);
            $placeholders = implode(', ', array_fill(0, count($columns), '?'));
            DB::query(
                "INSERT INTO products ({$fieldSql}) VALUES ({$placeholders})",
                array_values($columns)
            );
            unset($_SESSION['products_old']);
            self::flash('ok', 'Part created successfully.');
        } catch (\Throwable $e) {
            self::flash('err', 'Create failed: ' . $e->getMessage());
            header('Location: /products/add');
            exit;
        }
    }

    public static function editForm(View $view, int $id): void
    {
        if ($id <= 0) {
            self::flash('err', 'Invalid part id.');
            header('Location: /products');
            exit;
        }

        $row = DB::fetchOne('SELECT * FROM products WHERE id=? LIMIT 1', [$id]);
        if (!$row) {
            self::flash('err', 'Part not found.');
            header('Location: /products');
            exit;
        }

        $row['stock_balance'] = self::hasLedgerTable()
            ? (float)(DB::fetchOne('SELECT COALESCE(SUM(qty_delta), 0) AS balance FROM stock_ledger_entries WHERE product_id=?', [$id])['balance'] ?? 0)
            : 0.0;

        $view->render('Products::edit.php', [
            'pageTitle' => 'Edit Part',
            'row' => $row,
            'supply_mode_options' => self::supplyModeOptions(),
            'fulfillment_mode_options' => PartExecutionRouteResolver::getFulfillmentModeOptions(),
            'dispatch_mode_options' => self::dispatchModeOptions(),
            'error' => self::pullFlash('err'),
        ]);
    }

    public static function part360(View $view, int $id): void
    {
        if ($id <= 0) {
            self::flash('err', 'Invalid part id.');
            header('Location: /products');
            exit;
        }

        $payload = Part360Service::build($id);
        if (!$payload) {
            self::flash('err', 'Part not found.');
            header('Location: /products');
            exit;
        }

        $product = (array)($payload['product'] ?? []);
        $user = \App\Core\Auth::user();
        $currentRole = strtolower(trim((string)($user['role'] ?? '')));
        $view->render('Products::part_360.php', [
            'pageTitle' => 'Part 360 ' . (string)($product['parts_number'] ?? ''),
            'payload' => $payload,
            'current_role' => $currentRole,
            'error' => self::pullFlash('err'),
            'flash' => self::pullFlash('ok'),
        ]);
    }

    public static function update(array $input): void
    {
        $id = (int)($input['id'] ?? 0);
        $data = self::sanitize($input);

        if ($id <= 0 || $data['parts_name'] === '' || $data['parts_number'] === '') {
            self::flash('err', 'Invalid edit payload.');
            header('Location: /products');
            exit;
        }

        try {
            $sets = [
                'parts_name=?' => $data['parts_name'],
                'parts_number=?' => $data['parts_number'],
                'model=?' => $data['model'],
                'producer=?' => $data['producer'],
                '`lead`=?' => $data['lead'],
                'cycle_time=?' => $data['cycle_time'],
                'notes=?' => $data['notes'],
                'is_active=?' => $data['is_active'],
            ];

            self::appendSupplyUpdateSets($sets, $data);

            $setSql = implode(', ', array_keys($sets));
            $params = array_values($sets);
            $params[] = $id;

            DB::query(
                "UPDATE products SET {$setSql}, updated_at=NOW() WHERE id=?",
                $params
            );
            self::flash('ok', 'Part updated.');
        } catch (\Throwable $e) {
            self::flash('err', 'Update failed: ' . $e->getMessage());
            header('Location: /products/edit?id=' . $id);
            exit;
        }
    }

    public static function delete(int $id): void
    {
        if ($id <= 0) {
            self::flash('err', 'Invalid part id.');
            return;
        }

        DB::query('DELETE FROM products WHERE id=? LIMIT 1', [$id]);
        self::flash('ok', 'Part deleted.');
    }

    public static function importForm(View $view): void
    {
        $view->render('Products::import.php', [
            'pageTitle' => 'Import Parts CSV',
            'flash' => self::pullFlash('ok'),
            'error' => self::pullFlash('err'),
        ]);
    }

    public static function importCsv($file): void
    {
        if (!is_array($file) || (int)($file['error'] ?? 1) !== 0) {
            self::flash('err', 'CSV upload failed.');
            return;
        }

        $tmp = (string)($file['tmp_name'] ?? '');
        if ($tmp === '' || !is_file($tmp)) {
            self::flash('err', 'Invalid uploaded file.');
            return;
        }

        $fh = fopen($tmp, 'rb');
        if (!$fh) {
            self::flash('err', 'Unable to open CSV file.');
            return;
        }

        $rowNo = 0;
        $inserted = 0;
        $skipped = 0;

        while (($row = fgetcsv($fh)) !== false) {
            $rowNo++;
            if ($rowNo === 1 && self::looksLikeHeader($row)) {
                continue;
            }

            $partsName = trim((string)($row[0] ?? ''));
            $partsNumber = trim((string)($row[1] ?? ''));
            $model = trim((string)($row[2] ?? ''));
            $producer = trim((string)($row[3] ?? ''));
            $lead = trim((string)($row[4] ?? ''));
            $rawCycle = '';
            $supplyMode = SupplyModel::SUPPLY_IN_HOUSE;
            $fulfillmentMode = 'company_to_destination';
            $requiresIpmQc = 1;
            $defaultSupplier = '';
            $stockedAtIpm = 1;
            $defaultProcurementLeadDays = null;
            $defaultSupplyNote = '';

            if (count($row) >= 8) {
                $rawCycle = trim((string)($row[5] ?? ''));
                $notes = trim((string)($row[6] ?? ''));
                $isActive = (int)((string)($row[7] ?? '1') === '0' ? 0 : 1);

                if (count($row) >= 9) {
                    $supplyMode = SupplyModel::normalizeSupplyMode((string)($row[8] ?? ''));
                }
                if (count($row) >= 10) {
                    $fulfillmentMode = PartExecutionRouteResolver::normalizeFulfillmentMode((string)($row[9] ?? ''));
                }
                if (count($row) >= 11) {
                    $requiresIpmQc = SupplyModel::normalizeRequiresIpmQc($row[10] ?? null) ? 1 : 0;
                }
                if (count($row) >= 12) {
                    $defaultSupplier = trim((string)($row[11] ?? ''));
                }
                if (count($row) >= 13) {
                    $stockedAtIpm = SupplyModel::normalizeRequiresIpmQc($row[12] ?? null) ? 1 : 0;
                }
                if (count($row) >= 14) {
                    $candidateLeadDays = trim((string)($row[13] ?? ''));
                    $defaultProcurementLeadDays = ($candidateLeadDays !== '' && is_numeric($candidateLeadDays)) ? max(0, (float)$candidateLeadDays) : null;
                }
                if (count($row) >= 15) {
                    $defaultSupplyNote = trim((string)($row[14] ?? ''));
                }
            } else {
                $notes = trim((string)($row[5] ?? ''));
                $isActive = (int)((string)($row[6] ?? '1') === '0' ? 0 : 1);
            }
            $cycleTime = ($rawCycle !== '' && is_numeric($rawCycle)) ? max(0, (float)$rawCycle) : null;

            if ($partsName === '' || $partsNumber === '') {
                $skipped++;
                continue;
            }

            try {
                $columns = [
                    'parts_name' => $partsName,
                    'parts_number' => $partsNumber,
                    'model' => $model,
                    'producer' => $producer,
                    'lead' => $lead,
                    'cycle_time' => $cycleTime,
                    'notes' => $notes,
                    'is_active' => $isActive,
                ];

                self::appendSupplyColumns($columns, [
                    'supply_mode' => $supplyMode,
                    'fulfillment_mode' => $fulfillmentMode,
                    'requires_ipm_qc' => $requiresIpmQc,
                    'default_supplier' => $defaultSupplier,
                    'stocked_at_ipm' => $stockedAtIpm,
                    'default_procurement_lead_days' => $defaultProcurementLeadDays,
                    'default_supply_note' => $defaultSupplyNote,
                ]);

                $insertFields = array_keys($columns);
                $insertSqlFields = array_map(
                    static fn(string $name): string => $name === 'lead' ? '`lead`' : $name,
                    $insertFields
                );
                $insertSql = implode(', ', $insertSqlFields);
                $insertPlaceholders = implode(', ', array_fill(0, count($insertFields), '?'));

                $upserts = ['parts_name', 'model', 'producer', 'lead', 'cycle_time', 'notes', 'is_active'];
                if (isset($columns['supply_mode'])) {
                    $upserts[] = 'supply_mode';
                }
                if (isset($columns['fulfillment_mode'])) {
                    $upserts[] = 'fulfillment_mode';
                }
                if (isset($columns['requires_ipm_qc'])) {
                    $upserts[] = 'requires_ipm_qc';
                }
                if (isset($columns['default_supplier'])) {
                    $upserts[] = 'default_supplier';
                }
                if (isset($columns['stocked_at_ipm'])) {
                    $upserts[] = 'stocked_at_ipm';
                }
                if (isset($columns['default_procurement_lead_days'])) {
                    $upserts[] = 'default_procurement_lead_days';
                }
                if (isset($columns['default_supply_note'])) {
                    $upserts[] = 'default_supply_note';
                }

                $updateExpr = [];
                foreach ($upserts as $upsertField) {
                    $dbField = $upsertField === 'lead' ? '`lead`' : $upsertField;
                    $updateExpr[] = $dbField . '=VALUES(' . $dbField . ')';
                }

                DB::query(
                    "INSERT INTO products ({$insertSql})
                     VALUES ({$insertPlaceholders})
                     ON DUPLICATE KEY UPDATE
                     " . implode(",\n                     ", $updateExpr) . ",
                     updated_at=NOW()",
                    array_values($columns)
                );
                $inserted++;
            } catch (\Throwable $e) {
                $skipped++;
            }
        }

        fclose($fh);
        self::flash('ok', "Import complete: {$inserted} upserted, {$skipped} skipped.");
    }

    private static function sanitize(array $input): array
    {
        return [
            'parts_name' => trim((string)($input['parts_name'] ?? '')),
            'parts_number' => trim((string)($input['parts_number'] ?? '')),
            'model' => trim((string)($input['model'] ?? '')),
            'producer' => trim((string)($input['producer'] ?? '')),
            'lead' => trim((string)($input['lead'] ?? '')),
            'cycle_time' => ((string)($input['cycle_time'] ?? '')) !== '' && is_numeric((string)$input['cycle_time'])
                ? max(0, (float)$input['cycle_time'])
                : null,
                        'qc_time_per_item' => ((string)($input['qc_time_per_item'] ?? '')) !== '' && is_numeric((string)$input['qc_time_per_item'])
                            ? max(0, (float)$input['qc_time_per_item'])
                            : null,
            'notes' => trim((string)($input['notes'] ?? '')),
            'is_active' => (int)((string)($input['is_active'] ?? '1') === '0' ? 0 : 1),
            'supply_mode' => SupplyModel::normalizeSupplyMode((string)($input['supply_mode'] ?? SupplyModel::SUPPLY_IN_HOUSE)),
            'fulfillment_mode' => PartExecutionRouteResolver::normalizeFulfillmentMode((string)($input['fulfillment_mode'] ?? 'company_to_destination')),
            'requires_ipm_qc' => SupplyModel::normalizeRequiresIpmQc($input['requires_ipm_qc'] ?? null) ? 1 : 0,
            'default_supplier' => trim((string)($input['default_supplier'] ?? '')),
            'stocked_at_ipm' => SupplyModel::normalizeRequiresIpmQc($input['stocked_at_ipm'] ?? null) ? 1 : 0,
            'default_procurement_lead_days' => ((string)($input['default_procurement_lead_days'] ?? '')) !== '' && is_numeric((string)$input['default_procurement_lead_days'])
                ? max(0, (float)$input['default_procurement_lead_days'])
                : null,
            'default_supply_note' => trim((string)($input['default_supply_note'] ?? '')),
            'requires_assembly' => (int)((string)($input['requires_assembly'] ?? '0') === '0' ? 0 : 1),
            'requires_processing' => PartExecutionRouteResolver::normalizeRequiresProcessing($input['requires_processing'] ?? null, (string)($input['fulfillment_mode'] ?? '')) ? 1 : 0,
            'dispatch_mode' => PartExecutionRouteResolver::normalizeDispatchMode((string)($input['dispatch_mode'] ?? '')),
            'dispatch_as_is' => (int)((string)($input['dispatch_as_is'] ?? '0') === '0' ? 0 : 1),
            'essential_stock_qty' => ((string)($input['essential_stock_qty'] ?? '')) !== '' && is_numeric((string)$input['essential_stock_qty'])
                ? max(0, (float)$input['essential_stock_qty'])
                : null,
            'planning_window_days' => ((string)($input['planning_window_days'] ?? '')) !== '' && is_numeric((string)$input['planning_window_days'])
                ? max(0, (int)$input['planning_window_days'])
                : null,
            'max_buffer_qty' => ((string)($input['max_buffer_qty'] ?? '')) !== '' && is_numeric((string)$input['max_buffer_qty'])
                ? max(0, (float)$input['max_buffer_qty'])
                : null,
        ];
    }

    /**
     * @param array<string,mixed> $columns
     * @param array<string,mixed> $data
     */
    private static function appendSupplyColumns(array &$columns, array $data): void
    {
        if (self::hasColumn('supply_mode')) {
            $columns['supply_mode'] = SupplyModel::normalizeSupplyMode((string)($data['supply_mode'] ?? ''));
        }
        if (self::hasColumn('fulfillment_mode')) {
            $columns['fulfillment_mode'] = PartExecutionRouteResolver::normalizeFulfillmentMode((string)($data['fulfillment_mode'] ?? ''));
        }
        if (self::hasColumn('requires_ipm_qc')) {
            $columns['requires_ipm_qc'] = SupplyModel::normalizeRequiresIpmQc($data['requires_ipm_qc'] ?? null) ? 1 : 0;
        }
        if (self::hasColumn('default_supplier')) {
            $columns['default_supplier'] = trim((string)($data['default_supplier'] ?? ''));
        }
        if (self::hasColumn('stocked_at_ipm')) {
            $columns['stocked_at_ipm'] = SupplyModel::normalizeRequiresIpmQc($data['stocked_at_ipm'] ?? null) ? 1 : 0;
        }
        if (self::hasColumn('default_procurement_lead_days')) {
            $columns['default_procurement_lead_days'] = ((string)($data['default_procurement_lead_days'] ?? '')) !== '' && is_numeric((string)$data['default_procurement_lead_days'])
                ? max(0, (float)$data['default_procurement_lead_days'])
                : null;
        }
        if (self::hasColumn('default_supply_note')) {
            $columns['default_supply_note'] = trim((string)($data['default_supply_note'] ?? ''));
        }
        if (self::hasColumn('requires_assembly')) {
            $columns['requires_assembly'] = (int)((string)($data['requires_assembly'] ?? '0') === '0' ? 0 : 1);
        }
        if (self::hasColumn('requires_processing')) {
            $columns['requires_processing'] = PartExecutionRouteResolver::normalizeRequiresProcessing($data['requires_processing'] ?? null, (string)($data['fulfillment_mode'] ?? '')) ? 1 : 0;
        }
        if (self::hasColumn('dispatch_mode')) {
            $dispatchMode = PartExecutionRouteResolver::normalizeDispatchMode((string)($data['dispatch_mode'] ?? ''));
            $columns['dispatch_mode'] = $dispatchMode !== '' ? $dispatchMode : null;
        }
        if (self::hasColumn('dispatch_as_is')) {
            $columns['dispatch_as_is'] = (int)((string)($data['dispatch_as_is'] ?? '0') === '0' ? 0 : 1);
        }
        if (self::hasColumn('essential_stock_qty')) {
            $columns['essential_stock_qty'] = ((string)($data['essential_stock_qty'] ?? '')) !== '' && is_numeric((string)$data['essential_stock_qty'])
                ? max(0, (float)$data['essential_stock_qty'])
                : null;
        }
        if (self::hasColumn('planning_window_days')) {
            $columns['planning_window_days'] = ((string)($data['planning_window_days'] ?? '')) !== '' && is_numeric((string)$data['planning_window_days'])
                ? max(0, (int)$data['planning_window_days'])
                : null;
        }
        if (self::hasColumn('max_buffer_qty')) {
            $columns['max_buffer_qty'] = ((string)($data['max_buffer_qty'] ?? '')) !== '' && is_numeric((string)$data['max_buffer_qty'])
                ? max(0, (float)$data['max_buffer_qty'])
                : null;
        }
    }

    /**
     * @param array<string,mixed> $sets
     * @param array<string,mixed> $data
     */
    private static function appendSupplyUpdateSets(array &$sets, array $data): void
    {
        if (self::hasColumn('supply_mode')) {
            $sets['supply_mode=?'] = SupplyModel::normalizeSupplyMode((string)($data['supply_mode'] ?? ''));
        }
        if (self::hasColumn('fulfillment_mode')) {
            $sets['fulfillment_mode=?'] = PartExecutionRouteResolver::normalizeFulfillmentMode((string)($data['fulfillment_mode'] ?? ''));
        }
        if (self::hasColumn('requires_ipm_qc')) {
            $sets['requires_ipm_qc=?'] = SupplyModel::normalizeRequiresIpmQc($data['requires_ipm_qc'] ?? null) ? 1 : 0;
        }
        if (self::hasColumn('default_supplier')) {
            $sets['default_supplier=?'] = trim((string)($data['default_supplier'] ?? ''));
        }
        if (self::hasColumn('stocked_at_ipm')) {
            $sets['stocked_at_ipm=?'] = SupplyModel::normalizeRequiresIpmQc($data['stocked_at_ipm'] ?? null) ? 1 : 0;
        }
        if (self::hasColumn('default_procurement_lead_days')) {
            $sets['default_procurement_lead_days=?'] = ((string)($data['default_procurement_lead_days'] ?? '')) !== '' && is_numeric((string)$data['default_procurement_lead_days'])
                ? max(0, (float)$data['default_procurement_lead_days'])
                : null;
        }
        if (self::hasColumn('default_supply_note')) {
            $sets['default_supply_note=?'] = trim((string)($data['default_supply_note'] ?? ''));
        }
        if (self::hasColumn('requires_assembly')) {
            $sets['requires_assembly=?'] = (int)((string)($data['requires_assembly'] ?? '0') === '0' ? 0 : 1);
        }
        if (self::hasColumn('requires_processing')) {
            $sets['requires_processing=?'] = PartExecutionRouteResolver::normalizeRequiresProcessing($data['requires_processing'] ?? null, (string)($data['fulfillment_mode'] ?? '')) ? 1 : 0;
        }
        if (self::hasColumn('dispatch_mode')) {
            $dispatchMode = PartExecutionRouteResolver::normalizeDispatchMode((string)($data['dispatch_mode'] ?? ''));
            $sets['dispatch_mode=?'] = $dispatchMode !== '' ? $dispatchMode : null;
        }
        if (self::hasColumn('dispatch_as_is')) {
            $sets['dispatch_as_is=?'] = (int)((string)($data['dispatch_as_is'] ?? '0') === '0' ? 0 : 1);
        }
        if (self::hasColumn('essential_stock_qty')) {
            $sets['essential_stock_qty=?'] = ((string)($data['essential_stock_qty'] ?? '')) !== '' && is_numeric((string)$data['essential_stock_qty'])
                ? max(0, (float)$data['essential_stock_qty'])
                : null;
        }
        if (self::hasColumn('planning_window_days')) {
            $sets['planning_window_days=?'] = ((string)($data['planning_window_days'] ?? '')) !== '' && is_numeric((string)$data['planning_window_days'])
                ? max(0, (int)$data['planning_window_days'])
                : null;
        }
        if (self::hasColumn('max_buffer_qty')) {
            $sets['max_buffer_qty=?'] = ((string)($data['max_buffer_qty'] ?? '')) !== '' && is_numeric((string)$data['max_buffer_qty'])
                ? max(0, (float)$data['max_buffer_qty'])
                : null;
        }
    }

    /**
     * @return array<string,bool>
     */
    private static function columnMap(): array
    {
        static $map = null;
        if (is_array($map)) {
            return $map;
        }

        $map = [];
        foreach (DB::fetchAll('SHOW COLUMNS FROM products') as $col) {
            $name = (string)($col['Field'] ?? '');
            if ($name !== '') {
                $map[$name] = true;
            }
        }
        return $map;
    }

    private static function hasColumn(string $name): bool
    {
        return isset(self::columnMap()[$name]);
    }

    /**
     * @return array<string,string>
     */
    private static function supplyModeOptions(): array
    {
        return [
            SupplyModel::SUPPLY_IN_HOUSE => 'In-house',
            SupplyModel::SUPPLY_THIRD_PARTY => 'Third-party',
            SupplyModel::SUPPLY_HYBRID => 'Hybrid',
        ];
    }

    /**
     * @return array<string,string>
     */
    private static function fulfillmentModeOptions(): array
    {
        return [
            'company_to_destination' => 'Company handles delivery to destination',
            'third_party_to_company_to_destination' => 'Supplier to company warehouse, then to destination',
            'third_party_to_destination' => 'Supplier delivers directly to destination',
        ];
    }

    /**
     * @return array<string,string>
     */
    private static function dispatchModeOptions(): array
    {
        return [
            '' => 'Auto (derive from fulfillment mode)',
            'internal' => 'Internal',
            'direct_supplier' => 'Direct Supplier',
            'hybrid' => 'Hybrid',
        ];
    }

    private static function looksLikeHeader(array $row): bool
    {
        $first = strtolower(trim((string)($row[0] ?? '')));
        $second = strtolower(trim((string)($row[1] ?? '')));
        return str_contains($first, 'parts') || str_contains($second, 'number');
    }

    private static function flash(string $key, string $msg): void
    {
        $_SESSION['products_flash_' . $key] = $msg;
    }

    private static function pullFlash(string $key): string
    {
        $k = 'products_flash_' . $key;
        $v = (string)($_SESSION[$k] ?? '');
        unset($_SESSION[$k]);
        return $v;
    }

    private static function hasLedgerTable(): bool
    {
        return DB::fetchOne("SHOW TABLES LIKE 'stock_ledger_entries'") !== null;
    }
}
