<?php
return [
  ['key' => 'ipm.root', 'label' => 'IPM', 'url' => null, 'parent' => null, 'order' => 30, 'perm' => null],
  ['key' => 'ipm.pre_orders', 'label' => 'Pre Orders', 'url' => '/pre-orders', 'parent' => 'ipm.root', 'order' => 50, 'perm' => null],
];
