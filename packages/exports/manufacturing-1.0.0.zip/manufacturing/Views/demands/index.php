<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>

<div class="card">
  <div class="row" style="justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
    <div>
      <h2 style="margin:0">Manufacturing Demand Engine</h2>
      <div class="muted">Auto-calculated from Pre Orders + Daily Orders with editor adjustments and admin approvals.</div>
    </div>
    <div class="row" style="gap:8px">
      <a class="btn" href="/apps/manufacturing">Manufacturing Portal</a>
      <a class="btn" href="/manufacturing/qc-queue">QC Queue</a>
      <a class="btn" href="/manufacturing/assembly-queue">Assembly Queue</a>
      <a class="btn" href="/manufacturing/assembly-plans">Assembly Plans</a>
      <a class="btn" href="/manufacturing/dispatch-ops">Open Dispatch Workbench</a>
    </div>
  </div>
</div>

<?php if (!empty($flash ?? '')): ?><div class="card" style="border-color:#1d4d2f;background:rgba(0,255,140,.06)"><?= e((string)$flash) ?></div><?php endif; ?>
<?php if (!empty($error ?? '')): ?><div class="card" style="border-color:#5b1d2b;background:rgba(255,0,0,.06)"><?= e((string)$error) ?></div><?php endif; ?>

<div class="card">
  <form method="get" action="/manufacturing/demands" class="row" style="align-items:end;gap:8px">
    <div style="flex:1;min-width:160px"><label class="muted" style="display:block;margin-bottom:6px">From</label><input type="date" name="from_date" value="<?= e((string)($from_date ?? '')) ?>"></div>
    <div style="flex:1;min-width:160px"><label class="muted" style="display:block;margin-bottom:6px">To</label><input type="date" name="to_date" value="<?= e((string)($to_date ?? '')) ?>"></div>
    <div style="flex:2;min-width:220px">
      <label class="muted" style="display:block;margin-bottom:6px">Part</label>
      <select name="product_id">
        <option value="0">All parts</option>
        <?php foreach ($products as $p): ?>
          <option value="<?= (int)$p['id'] ?>" <?= ((int)($product_id ?? 0) === (int)$p['id']) ? 'selected' : '' ?>>
            <?= e((string)$p['parts_name']) ?> (<?= e((string)$p['parts_number']) ?>)
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div style="flex:1;min-width:160px">
      <label class="muted" style="display:block;margin-bottom:6px">Demand Type</label>
      <select name="demand_type">
        <option value="">All</option>
        <?php foreach (['production', 'qc', 'assembly'] as $t): ?>
          <option value="<?= e($t) ?>" <?= ((string)($demand_type ?? '') === $t) ? 'selected' : '' ?>><?= e(ucfirst($t)) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div style="flex:1;min-width:160px">
      <label class="muted" style="display:block;margin-bottom:6px">Status</label>
      <select name="status">
        <option value="">All</option>
        <?php foreach (['calculated', 'adjusted', 'approved'] as $s): ?>
          <option value="<?= e($s) ?>" <?= ((string)($status ?? '') === $s) ? 'selected' : '' ?>><?= e(ucfirst($s)) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="row"><button class="btn" type="submit">Filter</button><a class="btn" href="/manufacturing/demands">Reset</a></div>
  </form>

  <form method="post" action="/manufacturing/demands/recalculate" style="margin-top:10px" class="row">
    <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
    <input type="hidden" name="from_date" value="<?= e((string)($from_date ?? '')) ?>">
    <input type="hidden" name="to_date" value="<?= e((string)($to_date ?? '')) ?>">
    <input type="hidden" name="product_id" value="<?= (int)($product_id ?? 0) ?>">
    <button class="btn ok" type="submit">Recalculate Demand</button>
  </form>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Date</th>
          <th>Part</th>
          <th>Type</th>
          <th>System Qty</th>
          <th>Adjusted Qty</th>
          <th>Approved Qty</th>
          <th>Status</th>
          <th>Adjust / Approve</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?= (int)$r['id'] ?></td>
          <td><?= e((string)$r['demand_date']) ?></td>
          <td><?= e((string)$r['parts_name']) ?> <span class="muted">(<?= e((string)$r['parts_number']) ?>)</span></td>
          <td><?= e((string)$r['demand_type']) ?></td>
          <td><?= e((string)$r['system_qty']) ?></td>
          <td><?= e((string)($r['adjusted_qty'] ?? '')) ?></td>
          <td><?= e((string)($r['approved_qty'] ?? '')) ?></td>
          <td><?= e((string)$r['status']) ?></td>
          <td>
            <form method="post" action="/manufacturing/demands/adjust" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:0 0 8px 0">
              <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <input type="number" step="0.01" min="0" name="adjusted_qty" value="<?= e((string)($r['adjusted_qty'] ?? $r['system_qty'])) ?>" style="width:110px">
              <input type="text" name="adjustment_note" value="<?= e((string)($r['adjustment_note'] ?? '')) ?>" placeholder="Adjustment note" style="min-width:180px">
              <button class="btn" type="submit">Adjust</button>
            </form>
            <form method="post" action="/manufacturing/demands/approve" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:0">
              <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <input type="number" step="0.01" min="0" name="approved_qty" value="<?= e((string)($r['approved_qty'] ?? $r['adjusted_qty'] ?? $r['system_qty'])) ?>" style="width:110px">
              <button class="btn ok" type="submit">Admin Approve</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($rows)): ?>
        <tr><td colspan="9" class="muted">No demand rows found for current filter.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
