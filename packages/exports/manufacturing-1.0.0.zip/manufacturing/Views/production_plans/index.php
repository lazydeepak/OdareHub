<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php $statusOptions = ['Draft', 'Planned', 'In Progress', 'Completed', 'On Hold', 'Cancelled']; ?>
<?php $auditSummary = is_array($audit_summary ?? null) ? $audit_summary : []; ?>
<style>
	.pp-filter-row input,
	.pp-filter-row select {
		min-height: 38px;
	}

	.pp-filter-row .btn {
		min-height: 38px;
		padding: 8px 12px;
	}

	.pp-filter-date {
		min-width: 165px;
	}

	.pp-filter-machine {
		min-width: 190px;
	}

	.pp-filter-status {
		min-width: 165px;
	}
</style>
<div class="card"><div class="row" style="justify-content:space-between;align-items:center"><div><h2 style="margin:0"><?= e(t('module.production_plans.title')) ?></h2><div class="muted"><?= e(t('module.production_plans.subtitle')) ?></div></div><div class="row" style="gap:8px"><a class="btn" href="/production-plans/print-next-two-weeks-pdf" target="_blank" rel="noopener">Print</a><a class="btn ok" href="/production-plans/add"><?= e(t('module.production_plans.add')) ?></a></div></div></div>
<?php if (!empty($flash ?? '')): ?><div class="card" style="border-color:#1d4d2f;background:rgba(0,255,140,.06)"><?= e((string)$flash) ?></div><?php endif; ?>
<?php if (!empty($error ?? '')): ?><div class="card" style="border-color:#5b1d2b;background:rgba(255,0,0,.06)"><?= e((string)$error) ?></div><?php endif; ?>
<div class="card"><form method="get" action="/production-plans" class="row pp-filter-row" style="align-items:end"><div class="pp-filter-date" style="flex:1"><label class="muted" style="display:block;margin-bottom:6px"><?= e(t('module.production_plans.plan_date')) ?></label><input type="date" name="plan_date" value="<?= e((string)$plan_date) ?>"></div><div class="pp-filter-machine" style="flex:1"><label class="muted" style="display:block;margin-bottom:6px"><?= e(t('common.machine')) ?></label><select name="machine_id" style="width:100%;max-width:100%"><option value="0"><?= e(t('common.all')) ?></option><?php foreach ($machines as $m): ?><option value="<?= (int)$m['id'] ?>" <?= ((int)$machine_id === (int)$m['id']) ? 'selected' : '' ?>><?= e((string)$m['machine_no']) ?> - <?= e((string)$m['machine_name']) ?></option><?php endforeach; ?></select></div><div class="pp-filter-status" style="flex:1"><label class="muted" style="display:block;margin-bottom:6px"><?= e(t('common.status')) ?></label><select name="status" style="width:100%;max-width:100%"><option value=""><?= e(t('common.all')) ?></option><?php foreach ($statusOptions as $opt): ?><option value="<?= e($opt) ?>" <?= ((string)$status === $opt) ? 'selected' : '' ?>><?= e($opt) ?></option><?php endforeach; ?></select></div><div class="row"><button class="btn" type="submit"><?= e(t('common.filter')) ?></button><a class="btn" href="/production-plans"><?= e(t('common.reset')) ?></a></div></form></div>
<div class="card"><div class="table-wrap"><table><thead><tr><th><?= e(t('common.id')) ?></th><th><?= e(t('common.date')) ?></th><th><?= e(t('common.machine')) ?></th><th><?= e(t('common.part')) ?></th><th><?= e(t('common.qty')) ?></th><th><?= e(t('common.sequence')) ?></th><th><?= e(t('common.status')) ?></th><th>Added by</th><th>Approval</th><th>Lock</th><th>Last Activity</th><th><?= e(t('common.coverage')) ?></th><th><?= e(t('common.shortage')) ?></th><th><?= e(t('common.actions')) ?></th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><?php $summary = $auditSummary[(int)$r['id']] ?? []; ?><tr><td><?= (int)$r['id'] ?></td><td><?= e((string)$r['plan_date']) ?></td><td><?= e((string)$r['machine_no']) ?> - <?= e((string)$r['machine_name']) ?></td><td><?= e((string)$r['parts_name']) ?> <span class="muted">(<?= e((string)$r['parts_number']) ?>)</span></td><td><?= e((string)$r['planned_qty']) ?></td><td><?= (int)$r['sequence_no'] ?></td><td><?= e((string)$r['status']) ?></td><td><?= e((string)($r['added_by'] ?? '-')) ?></td><td><?= e((string)($r['approval_status'] ?? 'Draft')) ?></td><td><?= trim((string)($r['locked_at'] ?? '')) !== '' ? 'Locked' : 'Open' ?></td><td><?php if (!empty($summary)): ?><div><?= e((string)($summary['action'] ?? '')) ?></div><div class="muted" style="font-size:.8em"><?= e((string)($summary['actor'] ?? 'System')) ?> @ <?= e((string)($summary['at'] ?? '')) ?></div><?php else: ?><span class="muted">-</span><?php endif; ?></td><td><?= e((string)$r['coverage_pct']) ?></td><td><?= e((string)$r['shortage_qty']) ?></td><td><div class="row"><a class="btn" href="/products/360?id=<?= (int)$r['product_id'] ?>">Part 360</a><a class="btn" href="/production-plans/edit?id=<?= (int)$r['id'] ?>"><?= e(t('common.edit')) ?></a><a class="btn" href="/production-plans/print-pdf?id=<?= (int)$r['id'] ?>" target="_blank" rel="noopener"><?= e(t('common.print_pdf')) ?></a><form method="post" action="/production-plans/delete" onsubmit="return confirm('<?= e(t('module.production_plans.delete_confirm')) ?>');" style="margin:0"><input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn danger" type="submit"><?= e(t('common.delete')) ?></button></form></div></td></tr><?php endforeach; ?>
<?php if (empty($rows)): ?><tr><td colspan="14" class="muted"><?= e(t('module.production_plans.none')) ?></td></tr><?php endif; ?>
</tbody></table></div></div>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
