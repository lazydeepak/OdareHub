<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$templates = is_array($templates ?? null) ? $templates : [];
$preview = is_array($preview ?? null) ? $preview : null;
$history = is_array($history ?? null) ? $history : [];
$csrf = (string)($csrf ?? '');
$previewPayload = is_array($preview['preview'] ?? null) ? $preview['preview'] : [];
$previewTemplate = is_array($previewPayload['template'] ?? null) ? $previewPayload['template'] : [];
?>

<div class="card">
  <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
    <div>
      <h2 style="margin:0 0 6px">Manufacturing Legacy Imports</h2>
      <div class="muted">Suite-owned import templates for core Manufacturing master/setup tables. Preview first, then commit only for commit-ready template types. This is separate from setup and demo data.</div>
    </div>
    <a class="btn" href="/apps/manufacturing">Back to Manufacturing</a>
  </div>
</div>

<?php if (($flash_ok ?? '') !== ''): ?>
  <div class="card" style="border-color:rgba(0,200,120,.4);color:#7df0b0"><?= e((string)$flash_ok) ?></div>
<?php endif; ?>
<?php if (($flash_err ?? '') !== ''): ?>
  <div class="card" style="border-color:rgba(255,80,80,.45);color:#ffb3b3"><?= e((string)$flash_err) ?></div>
<?php endif; ?>

<div class="card">
  <h3 style="margin:0 0 8px">Import Templates</h3>
  <div class="muted" style="margin-bottom:10px">Download a starter template, fill it with legacy data, then upload it here for preview. Ready templates can be committed now. Template-only types are staged for later migration work.</div>
  <div style="display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(220px,1fr))">
    <?php foreach ($templates as $template): ?>
      <div class="card" style="margin:0">
        <strong><?= e((string)($template['label'] ?? '')) ?></strong>
        <div class="muted" style="margin:6px 0"><?= e((string)($template['description'] ?? '')) ?></div>
        <div class="muted" style="margin-bottom:10px">Status: <?= e((string)($template['mode'] ?? 'template_only')) ?></div>
        <a class="btn" href="/apps/manufacturing/imports/template?import_type=<?= urlencode((string)($template['key'] ?? '')) ?>">Download CSV Template</a>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<div style="display:grid;gap:12px;grid-template-columns:minmax(280px,420px) minmax(320px,1fr)">
  <form method="post" action="/apps/manufacturing/imports/preview" enctype="multipart/form-data" class="card" style="margin:0">
    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
    <h3 style="margin:0 0 8px">Upload For Preview</h3>
    <label style="display:block;margin-bottom:10px">
      <div class="muted" style="margin-bottom:6px">Import type</div>
      <select name="import_type" required>
        <?php foreach ($templates as $template): ?>
          <option value="<?= e((string)($template['key'] ?? '')) ?>"><?= e((string)($template['label'] ?? '')) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label style="display:block;margin-bottom:10px">
      <div class="muted" style="margin-bottom:6px">Import file (.csv or .xlsx)</div>
      <input type="file" name="import_file" accept=".csv,.xlsx,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" required>
    </label>
    <button class="btn ok" type="submit">Preview Manufacturing Import</button>
  </form>

  <div class="card" style="margin:0">
    <h3 style="margin:0 0 8px">Preview Checks</h3>
    <div class="muted">Every preview surfaces valid rows, invalid rows, skipped rows, duplicate matches, and mapping issues such as missing parts or machines. Commit happens only after review.</div>
    <div style="display:grid;gap:8px;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));margin-top:12px">
      <div class="card" style="margin:0"><strong>Products / Parts</strong><div class="muted">Master rows and upserts</div></div>
      <div class="card" style="margin:0"><strong>Machines</strong><div class="muted">Machine master rows</div></div>
      <div class="card" style="margin:0"><strong>Demand Imports</strong><div class="muted">Daily and pre-order rows with product mapping</div></div>
      <div class="card" style="margin:0"><strong>Mappings</strong><div class="muted">Part-machine compatibility rows</div></div>
    </div>
  </div>
</div>

<?php if (is_array($preview)): ?>
  <div class="card">
    <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
      <div>
        <h3 style="margin:0 0 8px">Preview Summary</h3>
        <div class="muted">Type: <?= e((string)($previewPayload['import_type'] ?? '')) ?> · Source: <?= e((string)($preview['source_file'] ?? '')) ?> · Mode: <?= e((string)($previewTemplate['mode'] ?? '')) ?></div>
      </div>
      <?php if (($previewTemplate['mode'] ?? '') === 'ready'): ?>
        <form method="post" action="/apps/manufacturing/imports/commit">
          <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
          <input type="hidden" name="preview_token" value="<?= e((string)($preview['preview_token'] ?? '')) ?>">
          <button class="btn ok" type="submit">Commit Manufacturing Import</button>
        </form>
      <?php endif; ?>
    </div>

    <div style="display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));margin-top:12px">
      <div class="card" style="margin:0"><strong>Valid Rows</strong><div class="muted"><?= e((string)($previewPayload['valid_rows'] ?? 0)) ?></div></div>
      <div class="card" style="margin:0"><strong>Invalid Rows</strong><div class="muted"><?= e((string)($previewPayload['invalid_rows'] ?? 0)) ?></div></div>
      <div class="card" style="margin:0"><strong>Skipped Rows</strong><div class="muted"><?= e((string)($previewPayload['skipped_rows'] ?? 0)) ?></div></div>
      <div class="card" style="margin:0"><strong>Duplicates</strong><div class="muted"><?= e((string)($previewPayload['duplicate_rows'] ?? 0)) ?></div></div>
    </div>

    <?php if (!empty($previewPayload['warnings'])): ?>
      <div class="muted" style="margin-top:10px;color:#ffcc8a"><?= e(implode(' ', array_map('strval', (array)$previewPayload['warnings']))) ?></div>
    <?php endif; ?>
  </div>

  <div class="card">
    <h3 style="margin:0 0 8px">Preview Rows</h3>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Line</th>
            <th>Preview</th>
            <th>Issues</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ((array)($previewPayload['sample_rows'] ?? []) as $row): ?>
            <tr>
              <td><?= e((string)($row['line_number'] ?? '')) ?></td>
              <td><pre style="white-space:pre-wrap;margin:0"><?= e(json_encode($row, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) ?: '{}') ?></pre></td>
              <td><?= e(!empty($row['errors']) ? implode(' | ', array_map('strval', (array)$row['errors'])) : (!empty($row['duplicate']) ? 'Will update or coexist with existing data' : 'Ready')) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php endif; ?>

<div class="card">
  <h3 style="margin:0 0 8px">Import History</h3>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>When</th>
          <th>Type</th>
          <th>Source</th>
          <th>Status</th>
          <th>Rows</th>
          <th>User</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($history as $run): ?>
          <tr>
            <td><?= e((string)($run['created_at'] ?? '')) ?></td>
            <td><?= e((string)($run['import_type'] ?? '')) ?></td>
            <td><?= e((string)($run['source_file'] ?? '')) ?></td>
            <td><?= e((string)($run['status'] ?? '')) ?></td>
            <td><?= e((string)($run['imported_rows'] ?? 0)) ?> imported / <?= e((string)($run['invalid_rows'] ?? 0)) ?> invalid / <?= e((string)($run['duplicate_rows'] ?? 0)) ?> duplicates</td>
            <td><?= e((string)($run['created_by'] ?? '')) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
