<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php $auditSummary = is_array($audit_summary ?? null) ? $audit_summary : []; ?>

<div class="card">
  <div class="row" style="justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
    <div>
      <h2 style="margin:0">Assembly Plans</h2>
      <div class="muted">Planned and approved assembly workload with execution progress and downstream readiness context.</div>
    </div>
    <div class="row" style="gap:8px">
      <a class="btn ok" href="/manufacturing/demands?demand_type=assembly">Add Assy Plan</a>
      <a class="btn" href="/pre-orders">Pre Orders</a>
      <a class="btn" href="/qc-plans">QC Plans</a>
      <a class="btn" href="/manufacturing/assembly-queue">Assembly Queue</a>
      <a class="btn" href="/manufacturing/stage-board">Stage Board</a>
      <a class="btn" href="/manufacturing/dispatch-ops">Dispatch Workbench</a>
    </div>
  </div>
</div>

<?php if (!empty($flash ?? '')): ?><div class="card" style="border-color:#1d4d2f;background:rgba(0,255,140,.06)"><?= e((string)$flash) ?></div><?php endif; ?>
<?php if (!empty($error ?? '')): ?><div class="card" style="border-color:#5b1d2b;background:rgba(255,0,0,.06)"><?= e((string)$error) ?></div><?php endif; ?>

<div class="card">
  <form method="get" action="/manufacturing/assembly-plans" class="row" style="align-items:end;gap:8px;flex-wrap:wrap">
    <div style="min-width:160px">
      <label class="muted" style="display:block;margin-bottom:6px">Date</label>
      <input type="date" name="date" value="<?= e((string)($date ?? '')) ?>">
    </div>
    <div style="min-width:160px">
      <label class="muted" style="display:block;margin-bottom:6px">Status</label>
      <select name="status">
        <option value="">All</option>
        <?php foreach (['calculated', 'adjusted', 'approved'] as $s): ?>
          <option value="<?= e($s) ?>" <?= ((string)($status ?? '') === $s) ? 'selected' : '' ?>><?= e(ucfirst($s)) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div style="min-width:260px;flex:1">
      <label class="muted" style="display:block;margin-bottom:6px">Part</label>
      <select name="product_id">
        <option value="0">All parts</option>
        <?php foreach (($products ?? []) as $p): ?>
          <option value="<?= (int)$p['id'] ?>" <?= ((int)($product_id ?? 0) === (int)$p['id']) ? 'selected' : '' ?>>
            <?= e((string)$p['parts_name']) ?> (<?= e((string)$p['parts_number']) ?>)
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <label style="display:flex;align-items:center;gap:6px;margin-bottom:8px">
      <input type="checkbox" name="only_open" value="1" <?= !empty($only_open) ? 'checked' : '' ?>>
      <span class="muted">Only open</span>
    </label>
    <div class="row" style="gap:8px">
      <button class="btn" type="submit">Filter</button>
      <a class="btn" href="/manufacturing/assembly-plans">Reset</a>
    </div>
  </form>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Plan Date</th>
          <th>Part</th>
          <th>Source Demand</th>
          <th>System Assembly Demand</th>
          <th>Adjusted Qty</th>
          <th>Approved Qty</th>
          <th>Completed Qty</th>
          <th>Remaining Qty</th>
          <th>Status</th>
          <th>Next Stage</th>
          <th>Dispatch Readiness</th>
          <th>Last Activity</th>
          <th>Notes</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach (($rows ?? []) as $r): ?>
        <?php $summary = $auditSummary[(int)$r['id']] ?? []; ?>
        <tr>
          <td><?= e((string)$r['demand_date']) ?></td>
          <td>
            <?= e((string)$r['parts_name']) ?>
            <span class="muted">(<?= e((string)$r['parts_number']) ?>)</span>
            <?php if (!empty($r['qc_released'])): ?>
              <div style="font-size:.72em;color:#7dd4ff">QC Released</div>
            <?php endif; ?>
          </td>
          <td><?= e((string)$r['source_demand']) ?></td>
          <td><?= e((string)$r['system_qty']) ?></td>
          <td><?= e((string)($r['adjusted_qty'] ?? '')) ?></td>
          <td><?= e((string)($r['approved_qty'] ?? '')) ?></td>
          <td><?= e((string)($r['completed_qty'] ?? '0')) ?></td>
          <td style="font-weight:700;color:<?= (float)($r['remaining_qty'] ?? 0) > 0 ? '#ffd97d' : '#5fffa4' ?>">
            <?= e((string)($r['remaining_qty'] ?? '0')) ?>
          </td>
          <td>
            <span style="font-size:.78em;padding:2px 8px;border-radius:20px;
              <?= match((string)($r['status'] ?? 'calculated')) {
                'approved' => 'background:rgba(0,220,110,.18);color:#5fffa4;border:1px solid rgba(0,220,110,.3)',
                'adjusted' => 'background:rgba(255,200,60,.18);color:#ffd97d;border:1px solid rgba(255,200,60,.3)',
                default => 'background:rgba(160,160,180,.12);color:#b8bcd8;border:1px solid rgba(160,160,180,.25)',
              } ?>">
              <?= e(ucfirst((string)($r['status'] ?? 'calculated'))) ?>
            </span>
          </td>
          <td>
            <?php if (!empty($r['next_stage'])): ?>
              <?= e(ucfirst((string)$r['next_stage'])) ?>
            <?php else: ?>
              <span style="color:#5fffa4">Complete</span>
            <?php endif; ?>
            <?php if (!empty($r['block_reason'])): ?>
              <div style="font-size:.72em;color:#ff8888"><?= e((string)$r['block_reason']) ?></div>
            <?php endif; ?>
          </td>
          <td>
            <span style="font-size:.78em;color:<?= (string)($r['dispatch_stage_status'] ?? '') === 'eligible' ? '#a5c5ff' : 'var(--muted)' ?>">
              <?= e(ucfirst((string)($r['dispatch_stage_status'] ?? 'pending'))) ?>
            </span>
          </td>
          <td>
            <?php if (!empty($summary)): ?>
              <div><?= e((string)($summary['action'] ?? '')) ?></div>
              <div class="muted" style="font-size:.8em"><?= e((string)($summary['actor'] ?? 'System')) ?> @ <?= e((string)($summary['at'] ?? '')) ?></div>
            <?php else: ?>
              <span class="muted">-</span>
            <?php endif; ?>
          </td>
          <td><?= e((string)($r['adjustment_note'] ?? '')) ?></td>
          <td><a class="btn" href="/manufacturing/assembly-plans/detail?id=<?= (int)$r['id'] ?>">Open</a></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($rows ?? [])): ?>
        <tr><td colspan="14" class="muted">No assembly plans found for the current filter.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
