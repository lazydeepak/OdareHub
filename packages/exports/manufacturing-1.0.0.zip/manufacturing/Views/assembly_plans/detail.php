<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$plan = (array)($payload['plan'] ?? []);
$metrics = (array)($payload['metrics'] ?? []);
$entries = (array)($payload['entries'] ?? []);
$dailyOrders = (array)($payload['linked_daily_orders'] ?? []);
$preOrders = (array)($payload['linked_pre_orders'] ?? []);
$stage = (array)($payload['stage_readiness'] ?? []);
$stages = (array)($stage['stages'] ?? []);
$qcStage = (array)($stages['qc'] ?? []);
$asmStage = (array)($stages['assembly'] ?? []);
$dispatchStage = (array)($stages['dispatch'] ?? []);
$workflow = is_array($workflow ?? null) ? $workflow : [];
$workflowState = (string)($workflow['state'] ?? 'draft');
$workflowActions = is_array($workflow['actions'] ?? null) ? $workflow['actions'] : [];
$workflowActionKeys = array_values(array_map(static fn(array $row): string => (string)($row['action'] ?? ''), $workflowActions));
$activityTimeline = is_array($activity_timeline ?? null) ? $activity_timeline : [];
?>

<div class="card">
  <div class="row" style="justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
    <div>
      <h2 style="margin:0">Assembly Plan Detail</h2>
      <div class="muted">
        <?= e((string)($plan['parts_name'] ?? '')) ?>
        <span>(<?= e((string)($plan['parts_number'] ?? '')) ?>)</span>
        for <?= e((string)($plan['demand_date'] ?? '')) ?>
      </div>
    </div>
    <div class="row" style="gap:8px">
      <a class="btn" href="/manufacturing/assembly-plans">Back to Assembly Plans</a>
      <a class="btn" href="/manufacturing/assembly-queue">Assembly Queue</a>
      <a class="btn" href="/manufacturing/dispatch-ops">Dispatch Workbench</a>
    </div>
  </div>
</div>

<?php if (!empty($flash ?? '')): ?><div class="card" style="border-color:#1d4d2f;background:rgba(0,255,140,.06)"><?= e((string)$flash) ?></div><?php endif; ?>
<?php if (!empty($error ?? '')): ?><div class="card" style="border-color:#5b1d2b;background:rgba(255,0,0,.06)"><?= e((string)$error) ?></div><?php endif; ?>
<?php $ownership_title = 'Operational Ownership'; require APP_ROOT . '/public/views/partials/ownership_summary.php'; ?>

<div class="card">
  <div class="row" style="gap:12px;flex-wrap:wrap">
    <div class="card" style="min-width:150px"><div class="muted" style="font-size:.75em">Source Demand</div><div style="font-size:1.05em;font-weight:700"><?= e((string)($metrics['source_demand'] ?? 'Unknown')) ?></div></div>
    <div class="card" style="min-width:150px"><div class="muted" style="font-size:.75em">Approved Assembly Qty</div><div style="font-size:1.2em;font-weight:700"><?= e((string)($metrics['effective_qty'] ?? 0)) ?></div></div>
    <div class="card" style="min-width:150px"><div class="muted" style="font-size:.75em">Completed Qty</div><div style="font-size:1.2em;font-weight:700"><?= e((string)($metrics['completed_qty'] ?? 0)) ?></div></div>
    <div class="card" style="min-width:150px"><div class="muted" style="font-size:.75em">Remaining Qty</div><div style="font-size:1.2em;font-weight:700;color:<?= ((float)($metrics['remaining_qty'] ?? 0) > 0) ? '#ffd97d' : '#5fffa4' ?>"><?= e((string)($metrics['remaining_qty'] ?? 0)) ?></div></div>
  </div>
</div>

<?php if (!empty($activityTimeline)): ?>
<div class="card">
  <h3 style="margin-top:0">Activity Timeline</h3>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>When</th>
          <th>Action</th>
          <th>Type</th>
          <th>State</th>
          <th>Reason / Note</th>
          <th>Changes</th>
          <th>Actor</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($activityTimeline as $event): ?>
        <tr>
          <td><?= e((string)($event['created_at'] ?? '')) ?></td>
          <td><?= e((string)($event['action_name'] ?? '')) ?></td>
          <td><?= e((string)($event['event_type'] ?? '')) ?></td>
          <td><?= e((string)($event['old_state'] ?? '-')) ?> -> <?= e((string)($event['new_state'] ?? '-')) ?></td>
          <td><?= e(trim((string)($event['reason_text'] ?? '')) !== '' ? (string)$event['reason_text'] : (string)($event['note_text'] ?? '')) ?></td>
          <td>
            <?php $diff = is_array($event['diff'] ?? null) ? $event['diff'] : []; ?>
            <?php if (!empty($diff)): ?>
              <?php $items = []; foreach ($diff as $d) { $items[] = (string)($d['field'] ?? '') . ': ' . (string)($d['old'] ?? '-') . ' -> ' . (string)($d['new'] ?? '-'); } ?>
              <?= e(implode(' | ', $items)) ?>
            <?php else: ?>
              -
            <?php endif; ?>
          </td>
          <td><?= e((string)($event['actor_label'] ?? 'System')) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <h3 style="margin-top:0">Stage Readiness Context</h3>
  <div class="row" style="gap:10px;flex-wrap:wrap">
    <div class="muted">QC Status: <strong><?= e((string)($qcStage['status'] ?? 'n/a')) ?></strong></div>
    <div class="muted">Assembly Status: <strong><?= e((string)($asmStage['status'] ?? 'n/a')) ?></strong></div>
    <div class="muted">Dispatch Status: <strong><?= e((string)($dispatchStage['status'] ?? 'n/a')) ?></strong></div>
    <div class="muted">Dispatch readiness effect: <?= e(((string)($asmStage['status'] ?? '') === 'complete' || !empty($asmStage['released_qty'])) ? 'Assembly is ready to feed Dispatch stage.' : 'Complete or release assembly to fully feed Dispatch stage.') ?></div>
  </div>
</div>

<div class="card">
  <h3 style="margin-top:0">Plan Update</h3>
  <div class="muted" style="margin-bottom:8px">Workflow state: <strong><?= e(ucfirst(str_replace('_', ' ', $workflowState))) ?></strong></div>
  <form method="post" action="/manufacturing/assembly-plans/update" class="row" style="align-items:end;gap:8px;flex-wrap:wrap">
    <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
    <input type="hidden" name="id" value="<?= (int)$plan['id'] ?>">
    <div>
      <label class="muted" style="display:block;margin-bottom:6px">Adjusted Qty</label>
      <input type="number" min="0" step="0.01" name="adjusted_qty" value="<?= e((string)($plan['adjusted_qty'] ?? $plan['system_qty'] ?? 0)) ?>">
    </div>
    <div style="min-width:280px;flex:1">
      <label class="muted" style="display:block;margin-bottom:6px">Notes / blockers</label>
      <input type="text" name="adjustment_note" value="<?= e((string)($plan['adjustment_note'] ?? '')) ?>" placeholder="Adjustment reason, blocker, or operational note">
    </div>
    <button class="btn" type="submit">Save Adjustment</button>
  </form>

  <?php if (in_array('approve', $workflowActionKeys, true)): ?>
  <form method="post" action="/manufacturing/assembly-plans/approve" class="row" style="align-items:end;gap:8px;margin-top:10px;flex-wrap:wrap">
    <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
    <input type="hidden" name="id" value="<?= (int)$plan['id'] ?>">
    <div>
      <label class="muted" style="display:block;margin-bottom:6px">Approved Qty (Admin)</label>
      <input type="number" min="0" step="0.01" name="approved_qty" value="<?= e((string)($plan['approved_qty'] ?? $plan['adjusted_qty'] ?? $plan['system_qty'] ?? 0)) ?>">
    </div>
    <div>
      <label class="muted" style="display:block;margin-bottom:6px">Note</label>
      <input type="text" name="note" placeholder="Optional approval note">
    </div>
    <button class="btn ok" type="submit">Admin Approve</button>
  </form>
  <?php endif; ?>

  <?php if (!empty($workflowActions)): ?>
  <form method="post" action="/manufacturing/assembly-plans/transition" class="row" style="align-items:end;gap:8px;margin-top:10px;flex-wrap:wrap">
    <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
    <input type="hidden" name="id" value="<?= (int)$plan['id'] ?>">
    <div>
      <label class="muted" style="display:block;margin-bottom:6px">Workflow Action</label>
      <select name="action" required>
        <?php foreach ($workflowActions as $wa): ?>
          <option value="<?= e((string)($wa['action'] ?? '')) ?>"><?= e((string)($wa['label'] ?? $wa['action'] ?? '')) ?> -> <?= e((string)($wa['to_state'] ?? '')) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div style="min-width:220px;flex:1">
      <label class="muted" style="display:block;margin-bottom:6px">Reason</label>
      <input type="text" name="reason" placeholder="Required for reject/reopen/hold/cancel">
    </div>
    <div style="min-width:220px;flex:1">
      <label class="muted" style="display:block;margin-bottom:6px">Note</label>
      <input type="text" name="note" placeholder="Optional transition note">
    </div>
    <button class="btn" type="submit">Apply Workflow Action</button>
  </form>
  <?php endif; ?>
</div>

<div class="card">
  <h3 style="margin-top:0">Execution Tracking</h3>
  <form method="post" action="/manufacturing/assembly-plans/execution-log" class="row" style="align-items:end;gap:8px;flex-wrap:wrap">
    <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
    <input type="hidden" name="assembly_plan_id" value="<?= (int)$plan['id'] ?>">
    <input type="hidden" name="product_id" value="<?= (int)$plan['product_id'] ?>">
    <input type="hidden" name="assembly_date" value="<?= e((string)($plan['demand_date'] ?? date('Y-m-d'))) ?>">
    <div><label class="muted" style="display:block;margin-bottom:6px">Planned Qty</label><input type="number" min="0" step="0.01" name="planned_qty" value="<?= e((string)($metrics['effective_qty'] ?? 0)) ?>"></div>
    <div><label class="muted" style="display:block;margin-bottom:6px">Completed Qty</label><input type="number" min="0" step="0.01" name="completed_qty" value="0"></div>
    <div><label class="muted" style="display:block;margin-bottom:6px">Rejected Qty</label><input type="number" min="0" step="0.01" name="rejected_qty" value="0"></div>
    <div>
      <label class="muted" style="display:block;margin-bottom:6px">Status</label>
      <select name="status">
        <?php foreach (['draft', 'in_progress', 'completed', 'approved', 'blocked'] as $s): ?>
          <option value="<?= e($s) ?>"><?= e(ucfirst($s)) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div style="min-width:260px;flex:1"><label class="muted" style="display:block;margin-bottom:6px">Note</label><input type="text" name="note" placeholder="Shift note / blocker / handoff"></div>
    <button class="btn ok" type="submit">Log Execution</button>
  </form>

  <div class="table-wrap" style="margin-top:12px">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Date</th>
          <th>Planned</th>
          <th>Completed</th>
          <th>Rejected</th>
          <th>Status</th>
          <th>Completed By</th>
          <th>Approved By</th>
          <th>Note</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($entries as $e): ?>
        <tr>
          <td><?= (int)$e['id'] ?></td>
          <td><?= e((string)$e['assembly_date']) ?></td>
          <td><?= e((string)$e['planned_qty']) ?></td>
          <td><?= e((string)$e['completed_qty']) ?></td>
          <td><?= e((string)$e['rejected_qty']) ?></td>
          <td><?= e((string)$e['status']) ?></td>
          <td><?= e((string)($e['completed_by'] ?? '-')) ?></td>
          <td><?= e((string)($e['approved_by'] ?? '-')) ?></td>
          <td><?= e((string)($e['note'] ?? '')) ?></td>
          <td>
            <?php if ((string)($e['status'] ?? '') !== 'approved'): ?>
              <form method="post" action="/manufacturing/assembly-plans/execution-approve" style="margin:0">
                <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
                <input type="hidden" name="assembly_plan_id" value="<?= (int)$plan['id'] ?>">
                <input type="hidden" name="entry_id" value="<?= (int)$e['id'] ?>">
                <button class="btn" type="submit">Approve</button>
              </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($entries)): ?>
        <tr><td colspan="10" class="muted">No execution entries logged yet.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card">
  <h3 style="margin-top:0">Linked Source Documents</h3>
  <div class="row" style="gap:18px;flex-wrap:wrap">
    <div style="flex:1;min-width:280px">
      <h4 style="margin:0 0 8px 0">Daily Orders</h4>
      <div class="table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Order Date</th><th>Required</th><th>Qty</th><th>Status</th></tr></thead>
          <tbody>
          <?php foreach ($dailyOrders as $d): ?>
            <tr>
              <td><?= (int)$d['id'] ?></td>
              <td><?= e((string)$d['order_date']) ?></td>
              <td><?= e((string)$d['required_date']) ?></td>
              <td><?= e((string)$d['qty']) ?></td>
              <td><?= e((string)$d['status']) ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($dailyOrders)): ?>
            <tr><td colspan="5" class="muted">No linked daily orders for this date.</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div style="flex:1;min-width:280px">
      <h4 style="margin:0 0 8px 0">Pre Orders</h4>
      <div class="table-wrap">
        <table>
          <thead><tr><th>ID</th><th>Required</th><th>Planned</th><th>Balance</th><th>Priority</th></tr></thead>
          <tbody>
          <?php foreach ($preOrders as $p): ?>
            <tr>
              <td><?= (int)$p['id'] ?></td>
              <td><?= e((string)$p['required_date']) ?></td>
              <td><?= e((string)$p['planned_qty']) ?></td>
              <td><?= e((string)$p['balance_qty']) ?></td>
              <td><?= e((string)$p['planning_priority']) ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($preOrders)): ?>
            <tr><td colspan="5" class="muted">No linked pre orders for this date.</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
