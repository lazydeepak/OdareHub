<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$board = is_array($board ?? null) ? $board : [];
$date = (string)($board['date'] ?? date('Y-m-d'));
$today = (string)($board['today'] ?? date('Y-m-d'));
$kpi = is_array($board['kpi'] ?? null) ? $board['kpi'] : [];
$waitingForQc = is_array($board['waiting_for_qc'] ?? null) ? $board['waiting_for_qc'] : [];
$qcPassedNotReleased = is_array($board['qc_passed_not_released'] ?? null) ? $board['qc_passed_not_released'] : [];
$dispatchHoldBlocked = is_array($board['dispatch_hold_blocked'] ?? null) ? $board['dispatch_hold_blocked'] : [];
$agingHandoffs = is_array($board['aging_handoffs'] ?? null) ? $board['aging_handoffs'] : [];
$bottlenecksByRole = is_array($board['bottlenecks_by_role'] ?? null) ? $board['bottlenecks_by_role'] : [];
$highRiskOrders = is_array($board['high_risk_orders'] ?? null) ? $board['high_risk_orders'] : [];
$roleSnapshots = is_array($board['role_snapshots'] ?? null) ? $board['role_snapshots'] : [];
$ownerOptions = is_array($board['owner_options'] ?? null) ? $board['owner_options'] : [];
$ownershipOverview = is_array($board['ownership_overview'] ?? null) ? $board['ownership_overview'] : [];

function crb_sla_badge(string $level): string {
    $v = strtolower(trim($level));
    if ($v === 'breach') {
        return 'crb-badge-high';
    }
    if ($v === 'warning') {
        return 'crb-badge-medium';
    }
    return 'crb-badge-low';
}
?>

<style>
.crb-hero { display:flex; justify-content:space-between; align-items:flex-start; gap:12px; flex-wrap:wrap; }
.crb-title { margin:0; font-size:1.45rem; }
.crb-sub { margin-top:6px; color:var(--muted); font-size:.9rem; max-width:900px; }
.crb-pill { display:inline-flex; align-items:center; gap:6px; padding:4px 10px; border-radius:999px; border:1px solid var(--glass-border); background:rgba(255,255,255,.03); font-size:.78rem; color:var(--muted); }
.crb-kpis { margin-top:12px; display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:10px; }
.crb-kpi { background:linear-gradient(160deg,rgba(255,255,255,.06),rgba(255,255,255,.02)); border:1px solid var(--glass-border); border-radius:12px; padding:10px 12px; }
.crb-kpi-label { font-size:.73rem; color:var(--muted); }
.crb-kpi-value { margin-top:4px; font-size:1.35rem; font-weight:800; }
.crb-jump { margin-top:12px; border:1px solid rgba(255,176,0,.35); background:linear-gradient(160deg,rgba(255,176,0,.15),rgba(255,176,0,.05)); border-radius:12px; padding:10px 12px; display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap; }
.crb-actions { display:flex; gap:8px; flex-wrap:wrap; }
.crb-grid-2 { display:grid; grid-template-columns:1fr; gap:12px; }
.crb-grid-3 { display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:10px; }
.crb-card { background:linear-gradient(160deg,rgba(255,255,255,.05),rgba(255,255,255,.02)); border:1px solid var(--glass-border); border-radius:12px; padding:10px; }
.crb-card h3 { margin:0 0 8px; font-size:.98rem; }
.crb-table-wrap { overflow:auto; border:1px solid var(--glass-border); border-radius:12px; }
.crb-table { width:100%; border-collapse:collapse; min-width:980px; }
.crb-table th, .crb-table td { padding:9px 10px; border-bottom:1px solid rgba(255,255,255,.07); text-align:left; vertical-align:top; font-size:.84rem; }
.crb-table th { background:rgba(255,255,255,.03); color:var(--muted); font-weight:600; }
.crb-empty { color:var(--muted); font-size:.86rem; }
.crb-badge { border-radius:999px; padding:2px 8px; font-size:.72rem; border:1px solid; white-space:nowrap; }
.crb-badge-high { color:#ff8b8b; border-color:rgba(255,102,102,.4); background:rgba(255,80,80,.14); }
.crb-badge-medium { color:#ffd483; border-color:rgba(255,194,72,.4); background:rgba(255,188,71,.15); }
.crb-badge-low { color:#9fe8bf; border-color:rgba(90,210,130,.4); background:rgba(90,210,130,.14); }
.crb-alert { border:1px solid rgba(255,80,80,.35); background:rgba(255,80,80,.09); color:#ffb5b5; border-radius:10px; padding:9px 11px; font-size:.83rem; }
.crb-owner-note { display:block; color:var(--muted); font-size:.74rem; margin-top:3px; }
.crb-row-actions { display:flex; gap:6px; flex-wrap:wrap; margin-top:5px; }
.crb-inline-form { display:flex; gap:6px; align-items:center; flex-wrap:wrap; margin-top:4px; }
.crb-inline-form select, .crb-inline-form input { min-width:130px; }
</style>

<section class="card">
  <div class="crb-hero">
    <div>
      <h2 class="crb-title"><?= e(t('ops.cross_role_handoff.title')) ?></h2>
      <div class="crb-sub"><?= e(t('ops.cross_role_handoff.subtitle')) ?></div>
      <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <span class="crb-pill"><?= e(t('common.date')) ?>: <?= e($date) ?><?= $date === $today ? ' (' . e(t('ops.cross_role_handoff.today')) . ')' : '' ?></span>
        <a class="btn" href="/manufacturing/production-workboard"><?= e(t('nav.machine_leader')) ?></a>
        <a class="btn" href="/manufacturing/qc-workboard"><?= e(t('nav.qc_leader')) ?></a>
        <a class="btn" href="/manufacturing/dispatch-ops"><?= e(t('nav.dispatch_leader')) ?></a>
      </div>
    </div>
    <form method="get" action="/apps/manufacturing/handoffs" style="display:flex;gap:6px;align-items:flex-end;flex-wrap:wrap">
      <div>
        <label class="muted" style="display:block;margin-bottom:4px;font-size:.8rem"><?= e(t('common.date')) ?></label>
        <input type="date" name="date" value="<?= e($date) ?>">
      </div>
      <button class="btn" type="submit"><?= e(t('common.filter')) ?></button>
      <a class="btn" href="/apps/manufacturing/handoffs"><?= e(t('common.reset')) ?></a>
    </form>
  </div>

  <div class="crb-jump">
    <div>
      <strong><?= e(t('ops.cross_role_handoff.sla_watch')) ?>:</strong>
      <?= e(t('ops.supervisor_cockpit.warning')) ?> <?= (int)($kpi['sla_warning_items'] ?? 0) ?>,
      <?= e(t('ops.supervisor_cockpit.breach')) ?> <?= (int)($kpi['sla_breach_items'] ?? 0) ?>,
      <?= e(t('ops.cross_role_handoff.explicit_owners')) ?> <?= (int)($kpi['explicit_owner_items'] ?? 0) ?>
    </div>
    <div class="crb-actions">
      <a class="btn" href="#waiting-qc"><?= e(t('ops.cross_role_handoff.waiting_for_qc')) ?></a>
      <a class="btn" href="#qc-release"><?= e(t('ops.cross_role_handoff.qc_passed_not_released')) ?></a>
      <a class="btn" href="#dispatch-hold"><?= e(t('ops.cross_role_handoff.dispatch_hold_blocked')) ?></a>
      <a class="btn" href="#aging"><?= e(t('ops.cross_role_handoff.aging_handoffs')) ?></a>
      <a class="btn" href="#bottlenecks-role"><?= e(t('ops.supervisor_cockpit.bottlenecks_by_role')) ?></a>
      <a class="btn" href="#high-risk"><?= e(t('ops.supervisor_cockpit.kpi_high_risk_orders')) ?></a>
    </div>
  </div>

  <div class="crb-kpis">
    <div class="crb-kpi"><div class="crb-kpi-label"><?= e(t('ops.cross_role_handoff.waiting_for_qc')) ?></div><div class="crb-kpi-value"><?= (int)($kpi['waiting_for_qc'] ?? 0) ?></div></div>
    <div class="crb-kpi"><div class="crb-kpi-label"><?= e(t('ops.cross_role_handoff.qc_passed_not_released')) ?></div><div class="crb-kpi-value"><?= (int)($kpi['qc_passed_not_released'] ?? 0) ?></div></div>
    <div class="crb-kpi"><div class="crb-kpi-label"><?= e(t('ops.cross_role_handoff.dispatch_hold_blocked')) ?></div><div class="crb-kpi-value" style="color:#ff9999"><?= (int)($kpi['dispatch_hold_blocked'] ?? 0) ?></div></div>
    <div class="crb-kpi"><div class="crb-kpi-label"><?= e(t('ops.cross_role_handoff.aging_in_handoff')) ?></div><div class="crb-kpi-value" style="color:#ffd483"><?= (int)($kpi['aging_handoffs'] ?? 0) ?></div></div>
    <div class="crb-kpi"><div class="crb-kpi-label"><?= e(t('ops.cross_role_handoff.high_risk_orders_parts')) ?></div><div class="crb-kpi-value" style="color:#ffb3b3"><?= (int)($kpi['high_risk_orders'] ?? 0) ?></div></div>
  </div>
</section>

<section class="card">
  <h2 style="margin-top:0"><?= e(t('ops.cross_role_handoff.role_snapshot')) ?></h2>
  <div class="crb-grid-3">
    <div class="crb-card">
      <h3><?= e(t('ops.cross_role_handoff.machine_role_pressure')) ?></h3>
      <div><?= e(t('ops.machine_leader.run_now')) ?>: <strong><?= (int)($roleSnapshots['machine']['run_now'] ?? 0) ?></strong></div>
      <div><?= e(t('ops.machine_leader.waiting_for_qc')) ?>: <strong><?= (int)($roleSnapshots['machine']['waiting_qc'] ?? 0) ?></strong></div>
      <div><?= e(t('ops.machine_leader.kpi_delayed_jobs')) ?>: <strong><?= (int)($roleSnapshots['machine']['delayed'] ?? 0) ?></strong></div>
    </div>
    <div class="crb-card">
      <h3><?= e(t('ops.cross_role_handoff.assembly_role_pressure')) ?></h3>
      <div><?= e(t('ops.ownership.waiting_for_me')) ?>: <strong><?= (int)($roleSnapshots['assembly']['waiting_for_me'] ?? 0) ?></strong></div>
      <div><?= e(t('common.overdue')) ?>: <strong><?= (int)($roleSnapshots['assembly']['overdue'] ?? 0) ?></strong></div>
      <div><?= e(t('common.blocked')) ?>: <strong><?= (int)($roleSnapshots['assembly']['blocked'] ?? 0) ?></strong></div>
    </div>
    <div class="crb-card">
      <h3><?= e(t('ops.cross_role_handoff.qc_role_pressure')) ?></h3>
      <div><?= e(t('ops.qc_leader.run_now')) ?>: <strong><?= (int)($roleSnapshots['qc']['run_now'] ?? 0) ?></strong></div>
      <div><?= e(t('ops.qc_leader.pending_qc')) ?>: <strong><?= (int)($roleSnapshots['qc']['pending_qc'] ?? 0) ?></strong></div>
      <div><?= e(t('ops.qc_leader.kpi_ready_for_dispatch')) ?>: <strong><?= (int)($roleSnapshots['qc']['ready_dispatch'] ?? 0) ?></strong></div>
    </div>
    <div class="crb-card">
      <h3><?= e(t('ops.cross_role_handoff.dispatch_role_pressure')) ?></h3>
      <div><?= e(t('ops.dispatch_leader.ready_now')) ?>: <strong><?= (int)($roleSnapshots['dispatch']['ready_now'] ?? 0) ?></strong></div>
      <div><?= e(t('ops.dispatch_leader.blocked_hold')) ?>: <strong><?= (int)($roleSnapshots['dispatch']['blocked_hold'] ?? 0) ?></strong></div>
      <div><?= e(t('ops.dispatch_leader.aging_overdue')) ?>: <strong><?= (int)($roleSnapshots['dispatch']['aging'] ?? 0) ?></strong></div>
    </div>
  </div>
</section>

<section class="card" id="ownership-overview">
  <h2 style="margin-top:0"><?= e(t('ops.cross_role_handoff.ownership_overview')) ?></h2>
  <?php if (empty($ownershipOverview)): ?>
    <div class="crb-empty"><?= e(t('ops.cross_role_handoff.no_ownership_items')) ?></div>
  <?php else: ?>
    <div class="crb-table-wrap">
      <table class="crb-table" style="min-width:980px">
        <thead>
          <tr>
            <th><?= e(t('common.item')) ?></th>
            <th><?= e(t('common.stage')) ?></th>
            <th><?= e(t('common.owner')) ?></th>
            <th><?= e(t('common.state')) ?></th>
            <th><?= e(t('common.age')) ?></th>
            <th><?= e(t('common.sla')) ?></th>
            <th><?= e(t('common.next_owner')) ?></th>
            <th><?= e(t('common.actions')) ?></th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($ownershipOverview as $row): ?>
          <tr>
            <td><?= e((string)($row['item_ref'] ?? '')) ?></td>
            <td><?= e((string)($row['stage_label'] ?? '')) ?></td>
            <td><?= e((string)($row['current_owner_label'] ?? '')) ?></td>
            <td><?= e((string)($row['ownership_state_label'] ?? '')) ?></td>
            <td><?= e(number_format((float)($row['age_hours'] ?? 0), 2, '.', ',')) ?>h</td>
            <td><span class="crb-badge <?= crb_sla_badge((string)($row['sla_level'] ?? 'ok')) ?>"><?= e((string)($row['sla_label'] ?? t('ops.cross_role_handoff.within_sla'))) ?></span></td>
            <td><?= e((string)($row['next_owner_role'] ?? '-')) ?></td>
            <td><a class="btn" href="<?= e((string)($row['detail_url'] ?? '#')) ?>"><?= e(t('common.open')) ?></a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<?php
$renderSection = static function(string $id, string $title, array $rows) use ($ownerOptions): void {
?>
<section class="card" id="<?= e($id) ?>">
  <h2 style="margin-top:0"><?= e($title) ?></h2>
  <?php if (empty($rows)): ?>
    <div class="crb-empty"><?= e(t('ops.cross_role_handoff.no_items_currently')) ?></div>
  <?php else: ?>
    <div class="crb-table-wrap">
      <table class="crb-table">
        <thead>
          <tr>
            <th><?= e(t('ops.cross_role_handoff.item')) ?></th>
            <th><?= e(t('common.part')) ?></th>
            <th><?= e(t('common.qty')) ?></th>
            <th><?= e(t('ops.cross_role_handoff.stage_age')) ?></th>
            <th><?= e(t('ops.cross_role_handoff.sla')) ?></th>
            <th><?= e(t('ops.cross_role_handoff.owner')) ?></th>
            <th><?= e(t('ops.cross_role_handoff.escalation')) ?></th>
            <th><?= e(t('ops.supervisor_cockpit.action')) ?></th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $row): ?>
          <tr>
            <td>
              <?= e((string)($row['entity_type'] ?? '')) ?>-<?= (int)($row['entity_id'] ?? 0) ?>
              <span class="crb-owner-note"><?= e((string)($row['handoff_stage'] ?? '')) ?></span>
            </td>
            <td><?= e((string)($row['parts_name'] ?? '')) ?> <span class="muted"><?= e((string)($row['parts_number'] ?? '')) ?></span></td>
            <td><?= e(number_format((float)($row['pending_qc_qty'] ?? ($row['releasable_qty'] ?? ($row['dispatchable_qty'] ?? 0))), 2, '.', ',')) ?></td>
            <td>
              <?= e(number_format((float)($row['age_hours'] ?? 0), 2, '.', ',')) ?>h
              <span class="crb-owner-note"><?= e(t('ops.cross_role_handoff.since')) ?> <?= e((string)($row['stage_since_at'] ?? '-')) ?></span>
            </td>
            <td><span class="crb-badge <?= crb_sla_badge((string)($row['sla_level'] ?? 'ok')) ?>"><?= e((string)($row['sla_label'] ?? t('ops.cross_role_handoff.within_sla'))) ?></span></td>
            <td>
              <?= e((string)($row['owner'] ?? '')) ?>
              <span class="crb-owner-note"><?= (bool)($row['owner_explicit'] ?? false) ? e(t('ops.cross_role_handoff.explicit_owner')) : e(t('ops.cross_role_handoff.inferred_owner')) ?></span>
            </td>
            <td><?= e((string)($row['escalation_state_text'] ?? t('ops.cross_role_handoff.not_escalated'))) ?></td>
            <td>
              <a class="btn" href="<?= e((string)($row['next_action'] ?? '#')) ?>"><?= e((string)($row['action_label'] ?? t('common.open'))) ?></a>
              <a class="btn" href="<?= e((string)($row['escalate_action'] ?? '#')) ?>"><?= e((string)($row['escalate_label'] ?? t('ops.cross_role_handoff.open_board'))) ?></a>

              <form method="post" action="/apps/manufacturing/handoffs/assign-owner" class="crb-inline-form">
                <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
                <input type="hidden" name="entity_type" value="<?= e((string)($row['entity_type'] ?? '')) ?>">
                <input type="hidden" name="entity_id" value="<?= (int)($row['entity_id'] ?? 0) ?>">
                <input type="hidden" name="stage" value="<?= e((string)($row['stage_key'] ?? '')) ?>">
                <input type="hidden" name="redirect" value="/apps/manufacturing/handoffs?date=<?= urlencode((string)($_GET['date'] ?? '')) ?>#<?= e($id) ?>">
                <select name="owner_role">
                  <?php foreach ($ownerOptions as $k => $v): ?>
                    <option value="<?= e((string)$k) ?>" <?= (string)($row['owner'] ?? '') === (string)$k ? 'selected' : '' ?>><?= e((string)$v) ?></option>
                  <?php endforeach; ?>
                </select>
                <input type="text" name="owner_display" placeholder="<?= e(t('ops.cross_role_handoff.optional_assignee_label')) ?>">
                <button class="btn" type="submit"><?= e(t('ops.cross_role_handoff.assign')) ?></button>
              </form>

              <form method="post" action="/apps/manufacturing/handoffs/escalate" class="crb-inline-form">
                <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
                <input type="hidden" name="entity_type" value="<?= e((string)($row['entity_type'] ?? '')) ?>">
                <input type="hidden" name="entity_id" value="<?= (int)($row['entity_id'] ?? 0) ?>">
                <input type="hidden" name="stage" value="<?= e((string)($row['stage_key'] ?? '')) ?>">
                <input type="hidden" name="redirect" value="/apps/manufacturing/handoffs?date=<?= urlencode((string)($_GET['date'] ?? '')) ?>#<?= e($id) ?>">
                <select name="escalation_level">
                  <option value="L1"><?= e(t('ops.cross_role_handoff.escalation_l1')) ?></option>
                  <option value="L2"><?= e(t('ops.cross_role_handoff.escalation_l2')) ?></option>
                  <option value="L3"><?= e(t('ops.cross_role_handoff.escalation_l3')) ?></option>
                </select>
                <button class="btn" type="submit"><?= e(t('ops.qc_leader.escalate')) ?></button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>
<?php
};

$renderSection('waiting-qc', t('ops.cross_role_handoff.waiting_for_qc'), $waitingForQc);
$renderSection('qc-release', t('ops.cross_role_handoff.qc_passed_not_released'), $qcPassedNotReleased);
$renderSection('dispatch-hold', t('ops.cross_role_handoff.dispatch_hold_blocked'), $dispatchHoldBlocked);
?>

<section class="card" id="aging">
  <h2 style="margin-top:0"><?= e(t('ops.cross_role_handoff.aging_work_in_handoff')) ?></h2>
  <?php if (empty($agingHandoffs)): ?>
    <div class="crb-empty"><?= e(t('ops.cross_role_handoff.no_aging_handoff_items')) ?></div>
  <?php else: ?>
    <div class="crb-alert" style="margin-bottom:10px"><?= e(t('ops.cross_role_handoff.prioritized_by_sla_then_age')) ?></div>
    <div class="crb-table-wrap">
      <table class="crb-table" style="min-width:780px">
        <thead>
          <tr>
            <th><?= e(t('ops.cross_role_handoff.stage')) ?></th>
            <th><?= e(t('ops.cross_role_handoff.item')) ?></th>
            <th><?= e(t('common.part')) ?></th>
            <th><?= e(t('ops.cross_role_handoff.age')) ?></th>
            <th><?= e(t('ops.cross_role_handoff.sla')) ?></th>
            <th><?= e(t('ops.cross_role_handoff.owner')) ?></th>
            <th><?= e(t('ops.cross_role_handoff.escalation')) ?></th>
            <th><?= e(t('ops.supervisor_cockpit.action')) ?></th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($agingHandoffs as $row): ?>
          <tr>
            <td><?= e((string)$row['stage']) ?></td>
            <td><?= e((string)$row['item_ref']) ?></td>
            <td><?= e((string)$row['parts_name']) ?> <span class="muted"><?= e((string)$row['parts_number']) ?></span></td>
            <td><?= e(number_format((float)$row['age_hours'], 2, '.', ',')) ?>h</td>
            <td><span class="crb-badge <?= crb_sla_badge((string)$row['sla_level']) ?>"><?= e((string)$row['sla_label']) ?></span></td>
            <td><?= e((string)$row['owner']) ?> <span class="crb-owner-note"><?= (bool)($row['owner_explicit'] ?? false) ? e(t('ops.cross_role_handoff.explicit')) : e(t('ops.cross_role_handoff.inferred')) ?></span></td>
            <td><?= e((string)$row['escalation_state_text']) ?></td>
            <td><a class="btn" href="<?= e((string)$row['next_action']) ?>"><?= e((string)$row['action_label']) ?></a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<section class="crb-grid-2" id="bottlenecks-role">
  <div class="card">
    <h2 style="margin-top:0"><?= e(t('ops.supervisor_cockpit.bottlenecks_by_role')) ?></h2>
    <?php if (empty($bottlenecksByRole)): ?>
      <div class="crb-empty"><?= e(t('ops.cross_role_handoff.no_role_bottleneck_summary')) ?></div>
    <?php else: ?>
      <div class="crb-table-wrap">
        <table class="crb-table" style="min-width:620px">
          <thead>
            <tr>
              <th><?= e(t('ops.cross_role_handoff.owner')) ?></th>
              <th><?= e(t('ops.cross_role_handoff.blocked_items')) ?></th>
              <th><?= e(t('ops.cross_role_handoff.blocked_qty')) ?></th>
              <th><?= e(t('ops.cross_role_handoff.explicit_owned')) ?></th>
              <th><?= e(t('ops.cross_role_handoff.high_risk_orders')) ?></th>
              <th><?= e(t('ops.supervisor_cockpit.action')) ?></th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($bottlenecksByRole as $row): ?>
            <tr>
              <td><?= e((string)$row['owner']) ?></td>
              <td><?= (int)$row['blocked_items'] ?></td>
              <td><?= e(number_format((float)$row['blocked_qty'], 2, '.', ',')) ?></td>
              <td><?= (int)($row['explicit_owned_items'] ?? 0) ?></td>
              <td><?= (int)$row['high_risk_orders'] ?></td>
              <td><a class="btn" href="<?= e((string)$row['next_action']) ?>"><?= e(t('ops.cross_role_handoff.open_owner_board')) ?></a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <div class="card" id="high-risk">
    <h2 style="margin-top:0"><?= e(t('ops.cross_role_handoff.high_risk_orders_parts')) ?></h2>
    <?php if (empty($highRiskOrders)): ?>
      <div class="crb-empty"><?= e(t('ops.cross_role_handoff.no_high_risk_orders_now')) ?></div>
    <?php else: ?>
      <div class="crb-table-wrap">
        <table class="crb-table" style="min-width:760px">
          <thead>
            <tr>
              <th><?= e(t('ops.supervisor_cockpit.order')) ?></th>
              <th><?= e(t('common.part')) ?></th>
              <th><?= e(t('common.coverage')) ?></th>
              <th><?= e(t('common.shortage')) ?></th>
              <th><?= e(t('ops.cross_role_handoff.owner')) ?></th>
              <th><?= e(t('ops.cross_role_handoff.sla')) ?></th>
              <th><?= e(t('ops.cross_role_handoff.escalation')) ?></th>
              <th><?= e(t('ops.supervisor_cockpit.action')) ?></th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($highRiskOrders as $row): ?>
            <tr>
              <td>#<?= (int)$row['daily_order_id'] ?></td>
              <td><?= e((string)$row['parts_name']) ?> <span class="muted"><?= e((string)$row['parts_number']) ?></span></td>
              <td><?= e(number_format((float)$row['coverage_pct'], 2, '.', ',')) ?>%</td>
              <td><?= e(number_format((float)$row['shortage_qty'], 2, '.', ',')) ?></td>
              <td><?= e((string)$row['owner']) ?> <span class="crb-owner-note"><?= (bool)($row['owner_explicit'] ?? false) ? e(t('ops.cross_role_handoff.explicit')) : e(t('ops.cross_role_handoff.inferred')) ?></span></td>
              <td><span class="crb-badge <?= crb_sla_badge((string)$row['sla_level']) ?>"><?= e((string)$row['sla_label']) ?></span></td>
              <td><?= e((string)$row['escalation_state_text']) ?></td>
              <td>
                <a class="btn" href="<?= e((string)$row['next_action']) ?>"><?= e((string)$row['action_label']) ?></a>
                <a class="btn" href="/daily-orders/360?id=<?= (int)$row['daily_order_id'] ?>"><?= e(t('ops.cross_role_handoff.open_order_360')) ?></a>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
