<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>

<div class="card">
  <div class="row" style="justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
    <div>
      <h2 style="margin:0">QC Queue</h2>
      <div class="muted">QC execution queue — upstream release status, open workload, and downstream release actions.</div>
    </div>
    <div class="row" style="gap:8px">
      <a class="btn" href="/manufacturing/stage-board">Stage Board</a>
      <a class="btn" href="/manufacturing/assembly-plans">Assembly Plans</a>
      <a class="btn" href="/qc-plans">QC Plans</a>
      <a class="btn" href="/qc-entries">QC Entries</a>
      <a class="btn" href="/manufacturing/demands">Demand Engine</a>
    </div>
  </div>
</div>

<div class="card">
  <form method="get" action="/manufacturing/qc-queue" class="row" style="align-items:end;gap:8px">
    <div><label class="muted" style="display:block;margin-bottom:6px">From</label><input type="date" name="from_date" value="<?= e((string)($from_date ?? '')) ?>"></div>
    <div><label class="muted" style="display:block;margin-bottom:6px">To</label><input type="date" name="to_date" value="<?= e((string)($to_date ?? '')) ?>"></div>
    <div class="row"><button class="btn" type="submit">Filter</button><a class="btn" href="/manufacturing/qc-queue">Reset</a></div>
  </form>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Date</th>
          <th>Part</th>
          <th>Prod Released</th>
          <th>System QC</th>
          <th>Effective QC</th>
          <th>Open Workload</th>
          <th>Checked</th>
          <th>Pass Qty</th>
          <th>Fail Qty</th>
          <th>QC Status</th>
          <th>Next Stage</th>
          <th>Downstream Release</th>
          <th>Flags</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach (($rows ?? []) as $r):
        $prodReleased = !empty($r['production_released']);
        $qcReleased   = !empty($r['qc_explicitly_released']);
        $nextStage    = (string)($r['next_stage'] ?? 'dispatch');
        $demandDate   = (string)$r['demand_date'];
        $productId    = (int)$r['product_id'];
        $openWl       = (float)$r['open_qc_workload'];
        $effectiveQty = (float)$r['effective_qty'];
      ?>
        <tr>
          <td><?= e($demandDate) ?></td>
          <td>
            <?= e((string)$r['parts_name']) ?>
            <span class="muted">(<?= e((string)$r['parts_number']) ?>)</span>
          </td>

          <!-- Production released to QC? -->
          <td style="text-align:center">
            <?php if ($prodReleased): ?>
              <span style="font-size:.75em;padding:2px 7px;border-radius:20px;background:rgba(80,180,255,.18);color:#7dd4ff;border:1px solid rgba(80,180,255,.3)">Released</span>
            <?php else: ?>
              <span style="font-size:.75em;color:var(--muted)">Auto</span>
            <?php endif; ?>
          </td>

          <td><?= e((string)$r['system_qty']) ?></td>
          <td><?= e((string)$r['effective_qty']) ?></td>
          <td style="color:<?= $openWl > 0 ? '#ffd97d' : '#5fffa4' ?>;font-weight:<?= $openWl > 0 ? '700' : '400' ?>">
            <?= e((string)$r['open_qc_workload']) ?>
          </td>
          <td><?= e((string)$r['checked_qty']) ?></td>
          <td style="color:<?= (float)$r['pass_qty'] >= $effectiveQty * 0.95 && $effectiveQty > 0 ? '#5fffa4' : 'inherit' ?>">
            <?= e((string)$r['pass_qty']) ?>
          </td>
          <td style="color:<?= (float)($r['fail_qty'] ?? 0) > 0 ? '#ff8888' : 'var(--muted)' ?>">
            <?= e((string)($r['fail_qty'] ?? 0)) ?>
          </td>
          <td>
            <span style="font-size:.78em;padding:2px 8px;border-radius:20px;
              <?= match((string)$r['status']) {
                'approved'  => 'background:rgba(0,220,110,.18);color:#5fffa4;border:1px solid rgba(0,220,110,.3)',
                'adjusted'  => 'background:rgba(255,200,60,.18);color:#ffd97d;border:1px solid rgba(255,200,60,.3)',
                default     => 'background:rgba(160,160,180,.12);color:#b8bcd8;border:1px solid rgba(160,160,180,.25)',
              } ?>">
              <?= e(ucfirst((string)$r['status'])) ?>
            </span>
          </td>

          <!-- Next downstream stage -->
          <td style="font-size:.82em">
            <?= e(ucfirst($nextStage)) ?>
            <?php if ($qcReleased): ?>
              <div style="font-size:.75em;color:#7dd4ff">Already released</div>
            <?php endif; ?>
            <?php if (!empty($r['downstream_stage_status'])): ?>
              <div style="font-size:.75em;color:var(--muted)">State: <?= e((string)$r['downstream_stage_status']) ?></div>
            <?php endif; ?>
            <?php if (isset($r['downstream_releasable_qty'])): ?>
              <div style="font-size:.75em;color:var(--muted)">Releasable Qty: <?= e(number_format((float)$r['downstream_releasable_qty'], 2, '.', '')) ?></div>
            <?php endif; ?>
            <?php if (!empty($r['workflow_note'])): ?>
              <div style="font-size:.75em;color:<?= str_contains((string)$r['workflow_note'], 'Blocked') ? '#ff8888' : '#a5c5ff' ?>"><?= e((string)$r['workflow_note']) ?></div>
            <?php endif; ?>
          </td>

          <!-- Release to next downstream stage -->
          <td>
            <?php
            $canRelease = !$qcReleased && !empty($r['downstream_can_release']);
            if ($canRelease):
            ?>
              <form method="post" action="/manufacturing/stage-release"
                    style="display:inline-flex;gap:4px;align-items:center">
                <input type="hidden" name="csrf"       value="<?= e(\App\Core\Auth::csrfToken()) ?>">
                <input type="hidden" name="product_id" value="<?= $productId ?>">
                <input type="hidden" name="ref_date"   value="<?= e($demandDate) ?>">
                <input type="hidden" name="stage"      value="<?= e($nextStage) ?>">
                <input type="hidden" name="redirect"
                       value="/manufacturing/qc-queue?from_date=<?= urlencode((string)($from_date ?? '')) ?>&to_date=<?= urlencode((string)($to_date ?? '')) ?>">
                <input type="number" name="qty" min="0" step="0.01"
                       value="<?= round((float)($r['downstream_releasable_qty'] ?? $r['pass_qty']), 2) ?>"
                       style="width:60px;font-size:.78em;padding:3px 5px">
                <button class="btn ok" type="submit" style="font-size:.75em;padding:3px 9px">
                  → <?= e(ucfirst($nextStage)) ?>
                </button>
              </form>
            <?php elseif ($qcReleased): ?>
              <span style="font-size:.75em;color:#7dd4ff">✓ Released</span>
            <?php else: ?>
              <span style="font-size:.75em;color:var(--muted)">
                <?= !empty($r['downstream_block_reason']) ? e((string)$r['downstream_block_reason']) : 'Awaiting stage release conditions' ?>
              </span>
            <?php endif; ?>
          </td>

          <!-- Flags -->
          <td>
            <?php if ((string)($r['supply_mode'] ?? '') === 'third_party'): ?>
              <div class="muted" style="font-size:.75em">Third-party source</div>
            <?php endif; ?>
            <?php if (!empty($r['block_reason'])): ?>
              <div style="font-size:.75em;color:#ff8888">Blocked: <?= e((string)$r['block_reason']) ?></div>
            <?php endif; ?>
            <?php if ((int)($r['dispatch_as_is'] ?? 0) === 1): ?>
              <div class="muted" style="font-size:.75em">Dispatch-as-is</div>
            <?php endif; ?>
            <?php if ((int)($r['is_passive'] ?? 0) === 1): ?>
              <div style="font-size:.75em;color:#ff9a9a">Passive part</div>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($rows ?? [])): ?>
        <tr><td colspan="13" class="muted">No QC demand rows for current filter.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
