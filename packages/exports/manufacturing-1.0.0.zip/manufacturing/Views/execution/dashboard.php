<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>

<?php
$summary = is_array($summary ?? null) ? $summary : [];
$prod = (array)($summary['production'] ?? []);
$qc = (array)($summary['qc'] ?? []);
$assembly = (array)($summary['assembly'] ?? []);
$stageStats = is_array($stage_stats ?? null) ? $stage_stats : [];
$qcTopRows = is_array($qc_top_rows ?? null) ? $qc_top_rows : [];
$assemblyTopRows = is_array($assembly_top_rows ?? null) ? $assembly_top_rows : [];
$roleToken = (string)($role_token ?? 'ops');
$roleLabel = (string)($role_label ?? 'Operations');

$totalDemand = (float)($prod['approved_qty'] ?? 0) + (float)($qc['approved_qty'] ?? 0) + (float)($assembly['approved_qty'] ?? 0);
$readyDispatch = (float)($summary['dispatch_ready_qty'] ?? 0);
$blockedDispatch = (float)($summary['dispatch_blocked_qty'] ?? 0);
$thirdParty = (float)($summary['third_party_flow_qty'] ?? 0);
$dispatchHealth = $readyDispatch + $blockedDispatch > 0 ? round(($readyDispatch / ($readyDispatch + $blockedDispatch)) * 100, 1) : 0;

$pendingDemandApproval = (int)($prod['pending_rows'] ?? 0) + (int)($qc['pending_rows'] ?? 0) + (int)($assembly['pending_rows'] ?? 0);
$qcWaiting = (int)($qc['pending_rows'] ?? 0);
$assemblyWaiting = (int)($assembly['pending_rows'] ?? 0);
$productionNotPlanned = (int)($prod['pending_rows'] ?? 0);

$roleGuide = [
  'production_leader' => ['focus' => 'Production throughput and release readiness'],
  'assembly_leader' => ['focus' => 'Assembly completion and downstream release'],
  'qc_leader' => ['focus' => 'QC workload, pass/fail health, and release flow'],
  'dispatch_leader' => ['focus' => 'Dispatch preparation and completion flow'],
];
$roleMeta = $roleGuide[$roleToken] ?? ['focus' => 'Cross-stage operational visibility'];

$barWidth = static function (float $value, float $max): string {
  if ($max <= 0) {
    return '0%';
  }
  return max(4, min(100, (int)round(($value / $max) * 100))) . '%';
};

$chartMax = max(
  1.0,
  (float)($prod['approved_qty'] ?? 0),
  (float)($qc['approved_qty'] ?? 0),
  (float)($assembly['approved_qty'] ?? 0),
  $readyDispatch,
  $blockedDispatch,
  $thirdParty
);

$laneRows = [
  [
    'stage' => 'Production',
    'system' => (float)($prod['system_qty'] ?? 0),
    'adjusted' => (float)($prod['adjusted_qty'] ?? 0),
    'approved' => (float)($prod['approved_qty'] ?? 0),
    'approved_rows' => (int)($prod['approved_rows'] ?? 0),
    'pending_rows' => (int)($prod['pending_rows'] ?? 0),
    'action_label' => 'Open Production Queue',
    'action_url' => '/manufacturing/production-queue',
  ],
  [
    'stage' => 'QC',
    'system' => (float)($qc['system_qty'] ?? 0),
    'adjusted' => (float)($qc['adjusted_qty'] ?? 0),
    'approved' => (float)($qc['approved_qty'] ?? 0),
    'approved_rows' => (int)($qc['approved_rows'] ?? 0),
    'pending_rows' => (int)($qc['pending_rows'] ?? 0),
    'action_label' => 'Open QC Queue',
    'action_url' => '/manufacturing/qc-queue',
  ],
  [
    'stage' => 'Assembly',
    'system' => (float)($assembly['system_qty'] ?? 0),
    'adjusted' => (float)($assembly['adjusted_qty'] ?? 0),
    'approved' => (float)($assembly['approved_qty'] ?? 0),
    'approved_rows' => (int)($assembly['approved_rows'] ?? 0),
    'pending_rows' => (int)($assembly['pending_rows'] ?? 0),
    'action_label' => 'Open Assembly Queue',
    'action_url' => '/manufacturing/assembly-queue',
  ],
];
?>

<style>
  /* === Global tile CSS === */
  .mfg-alert-grid {
    display: flex;
    flex-direction: column;
    gap: 16px;
  }
  
  .mfg-alert {
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    gap: 16px;
    padding: 16px;
    border-radius: 8px;
    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.2);
  }
  
  .mfg-alert-title {
    display: inline;
    font-size: 0.875rem;
    font-weight: 600;
    color: rgba(255, 255, 255, 0.9);
  }
  
  .mfg-alert-value {
    display: inline;
    font-size: 1rem;
    font-weight: 700;
    color: rgba(255, 255, 255, 0.95);
    margin-left: 4px;
  }
  
  .mfg-alert-badge {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 0.75rem;
    font-weight: 600;
    background: rgba(255, 255, 255, 0.1);
    color: rgba(255, 255, 255, 0.8);
    margin-left: auto;
    margin-right: 12px;
  }
  
  .mfg-alert .btn {
    padding: 6px 12px;
    border-radius: 6px;
    border: 1px solid rgba(255, 255, 255, 0.3);
    background: rgba(255, 255, 255, 0.15);
    color: rgba(255, 255, 255, 0.95);
    font-size: 0.875rem;
    font-weight: 600;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s ease;
  }
  
  .mfg-alert .btn:hover {
    background: rgba(255, 255, 255, 0.25);
    border-color: rgba(255, 255, 255, 0.5);
  }

  /* === Stat cards tile layout === */
  .stat-row {
    display: flex;
    flex-direction: column;
    gap: 16px;
  }
  
  .stat-box {
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: 16px;
    padding: 16px;
    border-radius: 8px;
    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.2);
  }
  
  .mfg-state-card {
    display: contents;
  }
  
  .stat-box-label {
    font-size: 0.875rem;
    font-weight: 600;
    color: rgba(255, 255, 255, 0.9);
    flex: 1;
  }
  
  .stat-box-value {
    font-size: 1rem;
    font-weight: 700;
    color: rgba(255, 255, 255, 0.95);
    margin-right: auto;
    padding: 0 8px;
  }
  
  .stat-box .btn {
    padding: 6px 12px;
    border-radius: 6px;
    border: 1px solid rgba(255, 255, 255, 0.3);
    background: rgba(255, 255, 255, 0.15);
    color: rgba(255, 255, 255, 0.95);
    font-size: 0.875rem;
    font-weight: 600;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s ease;
    margin-top: 0;
  }
  
  .stat-box .btn:hover {
    background: rgba(255, 255, 255, 0.25);
    border-color: rgba(255, 255, 255, 0.5);
  }
</style>

<div class="card mfg-portal-card">
  <div class="mfg-portal-hero">
    <div>
      <h2 style="margin:0">Manufacturing Portal</h2>
      <div class="mfg-portal-subtitle">Cross-stage command center for demand, production, QC, assembly, and dispatch</div>
      <div class="mfg-portal-meta">
        <span class="mfg-meta-chip">Operational Scope: Cross-stage visibility</span>
        <span class="mfg-meta-chip">Current Role Lens: <?= e($roleLabel) ?></span>
      </div>
    </div>
    <div class="mfg-portal-actions">
      <a class="btn mfg-primary-action" href="/manufacturing/stage-board">Open Stage Board</a>
      <a class="btn mfg-primary-action" href="/manufacturing/demands">Open Demand Workspace</a>
      <a class="btn mfg-primary-action" href="/manufacturing/dispatch-ops">Open Order Processing</a>
      <a class="btn mfg-secondary-action" href="/products">Parts Master</a>
      <a class="btn mfg-secondary-action" href="/manufacturing/coverage">Coverage Dashboard</a>
    </div>
  </div>
</div>

<div class="card mfg-portal-card">
  <form method="get" action="/apps/manufacturing" class="row" style="align-items:end;gap:8px">
    <div><label class="muted" style="display:block;margin-bottom:6px">From</label><input type="date" name="from_date" value="<?= e((string)($from_date ?? '')) ?>"></div>
    <div><label class="muted" style="display:block;margin-bottom:6px">To</label><input type="date" name="to_date" value="<?= e((string)($to_date ?? '')) ?>"></div>
    <div class="row"><button class="btn" type="submit">Filter</button><a class="btn" href="/apps/manufacturing">Reset</a></div>
  </form>
</div>

<div class="card mfg-portal-card mfg-ios-atmosphere">
  <div class="section-head"><h2>Needs Attention Now</h2></div>
  <div class="mfg-alert-grid">
    <div class="mfg-alert <?= $blockedDispatch > 0 ? 'mfg-alert-critical' : 'mfg-alert-ok' ?>">
      <div class="mfg-alert-title">Dispatch Blocked</div>
      <div class="mfg-alert-value"><?= number_format($blockedDispatch, 0) ?></div>
      <span class="mfg-alert-badge <?= $blockedDispatch > 0 ? 'mfg-alert-badge-critical' : 'mfg-alert-badge-ok' ?>"><?= $blockedDispatch > 0 ? 'Immediate Action' : 'Stable' ?></span>
      <a class="btn" href="/manufacturing/dispatch-ops" style="margin-top:8px">Resolve in Dispatch Ops</a>
    </div>
    <div class="mfg-alert <?= $pendingDemandApproval > 0 ? 'mfg-alert-warn' : 'mfg-alert-ok' ?>">
      <div class="mfg-alert-title">Pending Demand Approval</div>
      <div class="mfg-alert-value"><?= number_format($pendingDemandApproval, 0) ?></div>
      <span class="mfg-alert-badge <?= $pendingDemandApproval > 0 ? 'mfg-alert-badge-warn' : 'mfg-alert-badge-ok' ?>"><?= $pendingDemandApproval > 0 ? 'Needs Review' : 'Clear' ?></span>
      <a class="btn" href="/manufacturing/demands" style="margin-top:8px">Review Demand Workspace</a>
    </div>
    <div class="mfg-alert <?= $qcWaiting > 0 ? 'mfg-alert-warn' : 'mfg-alert-ok' ?>">
      <div class="mfg-alert-title">QC Waiting</div>
      <div class="mfg-alert-value"><?= number_format($qcWaiting, 0) ?></div>
      <span class="mfg-alert-badge <?= $qcWaiting > 0 ? 'mfg-alert-badge-warn' : 'mfg-alert-badge-ok' ?>"><?= $qcWaiting > 0 ? 'Queue Building' : 'Flowing' ?></span>
      <a class="btn" href="/manufacturing/qc-queue" style="margin-top:8px">Open QC Queue</a>
    </div>
    <div class="mfg-alert <?= $assemblyWaiting > 0 ? 'mfg-alert-warn' : 'mfg-alert-ok' ?>">
      <div class="mfg-alert-title">Assembly Waiting</div>
      <div class="mfg-alert-value"><?= number_format($assemblyWaiting, 0) ?></div>
      <span class="mfg-alert-badge <?= $assemblyWaiting > 0 ? 'mfg-alert-badge-warn' : 'mfg-alert-badge-ok' ?>"><?= $assemblyWaiting > 0 ? 'Queue Building' : 'Flowing' ?></span>
      <a class="btn" href="/manufacturing/assembly-queue" style="margin-top:8px">Open Assembly Queue</a>
    </div>
    <div class="mfg-alert <?= $productionNotPlanned > 0 ? 'mfg-alert-warn' : 'mfg-alert-ok' ?>">
      <div class="mfg-alert-title">Production Not Planned</div>
      <div class="mfg-alert-value"><?= number_format($productionNotPlanned, 0) ?></div>
      <span class="mfg-alert-badge <?= $productionNotPlanned > 0 ? 'mfg-alert-badge-warn' : 'mfg-alert-badge-ok' ?>"><?= $productionNotPlanned > 0 ? 'Plan Gap' : 'Planned' ?></span>
      <a class="btn" href="/manufacturing/production-queue" style="margin-top:8px">Open Production Queue</a>
    </div>
  </div>
</div>

<div class="card mfg-portal-card">
  <div class="section-head"><h2>Today's Operational State</h2></div>
  <div class="stat-row">
    <div class="stat-box mfg-state-card">
      <div class="stat-box-label">Approved Demand (All Lanes)</div>
      <div class="stat-box-value"><?= number_format($totalDemand, 0) ?></div>
      <a class="btn" style="margin-top:8px" href="/manufacturing/demands">Review Demand</a>
    </div>
    <div class="stat-box mfg-state-card">
      <div class="stat-box-label">Dispatch Ready Qty</div>
      <div class="stat-box-value" style="color:#7dd4ff"><?= number_format($readyDispatch, 0) ?></div>
      <a class="btn" style="margin-top:8px" href="/manufacturing/dispatch-ops">Open Dispatch</a>
    </div>
    <div class="stat-box mfg-state-card">
      <div class="stat-box-label">Dispatch Blocked Qty</div>
      <div class="stat-box-value" style="color:<?= $blockedDispatch > 0 ? '#ff8888' : '#5fffa4' ?>"><?= number_format($blockedDispatch, 0) ?></div>
      <a class="btn" style="margin-top:8px" href="/manufacturing/dispatch-ops">Resolve Blockers</a>
    </div>
    <div class="stat-box mfg-state-card">
      <div class="stat-box-label">Dispatch Health</div>
      <div class="stat-box-value" style="color:<?= $dispatchHealth >= 70 ? '#5fffa4' : ($dispatchHealth >= 45 ? '#ffd97d' : '#ff8888') ?>"><?= number_format($dispatchHealth, 1) ?>%</div>
      <a class="btn" style="margin-top:8px" href="/manufacturing/stage-board">Open Stage Board</a>
    </div>
    <div class="stat-box mfg-state-card">
      <div class="stat-box-label">Tracked Parts (Today)</div>
      <div class="stat-box-value"><?= (int)($stageStats['tracked'] ?? 0) ?></div>
      <a class="btn" style="margin-top:8px" href="/manufacturing/stage-board">View Tracking</a>
    </div>
    <div class="stat-box mfg-state-card">
      <div class="stat-box-label">Blocked Parts (Today)</div>
      <div class="stat-box-value" style="color:<?= (int)($stageStats['blocked'] ?? 0) > 0 ? '#ff8888' : '#5fffa4' ?>"><?= (int)($stageStats['blocked'] ?? 0) ?></div>
      <a class="btn" style="margin-top:8px" href="/manufacturing/stage-board">Inspect Blocks</a>
    </div>
  </div>
</div>

<div class="card mfg-portal-card">
  <div class="section-head"><h2>Lane Pressure</h2></div>
  <div style="display:grid;gap:10px">
    <?php
      $bars = [
        ['label' => 'Production Approved', 'value' => (float)($prod['approved_qty'] ?? 0), 'tone' => '#89c8ff'],
        ['label' => 'QC Approved', 'value' => (float)($qc['approved_qty'] ?? 0), 'tone' => '#ffd97d'],
        ['label' => 'Assembly Approved', 'value' => (float)($assembly['approved_qty'] ?? 0), 'tone' => '#b0f7d0'],
        ['label' => 'Dispatch Ready', 'value' => $readyDispatch, 'tone' => '#7dd4ff'],
        ['label' => 'Dispatch Blocked', 'value' => $blockedDispatch, 'tone' => '#ff8b96'],
        ['label' => 'Third-Party Flow', 'value' => $thirdParty, 'tone' => '#c4b5fd'],
      ];
    ?>
    <?php foreach ($bars as $bar): ?>
      <div>
        <div class="row" style="justify-content:space-between;align-items:center;gap:10px;margin-bottom:4px">
          <div class="muted" style="font-size:12px"><?= e((string)$bar['label']) ?></div>
          <div style="font-size:12px;font-weight:700"><?= number_format((float)$bar['value'], 0) ?></div>
        </div>
        <div class="progress-bar-wrap" style="height:10px">
          <div class="progress-bar-fill" style="width:<?= e($barWidth((float)$bar['value'], $chartMax)) ?>;background:linear-gradient(90deg,<?= e((string)$bar['tone']) ?>,rgba(255,255,255,.12))"></div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<div class="card mfg-portal-card">
  <div class="section-head"><h2>Workboards &amp; Queues</h2></div>
  <div class="mfg-lane-groups">
    <div class="mfg-lane-group">
      <h3>Workboards</h3>
      <div class="mfg-lane-links">
        <a class="btn" href="/manufacturing/production-queue">Production Queue</a>
        <a class="btn" href="/manufacturing/stage-board">Stage Board</a>
        <a class="btn" href="/manufacturing/dispatch-ops">Dispatch Ops</a>
      </div>
    </div>
    <div class="mfg-lane-group">
      <h3>Queues</h3>
      <div class="mfg-lane-links">
        <a class="btn" href="/manufacturing/assembly-queue">Assembly Queue</a>
        <a class="btn" href="/manufacturing/qc-queue">QC Queue</a>
      </div>
    </div>
    <div class="mfg-lane-group">
      <h3>Planning / Analysis</h3>
      <div class="mfg-lane-links">
        <a class="btn" href="/manufacturing/demands">Demand Workspace</a>
        <a class="btn" href="/products">Parts Master</a>
        <a class="btn" href="/manufacturing/coverage">Coverage Dashboard</a>
        <a class="btn" href="/manufacturing/dispatch-ops/preparation">Order Prep Form</a>
      </div>
    </div>
  </div>
</div>

<div class="card mfg-portal-card">
  <h3 style="margin-top:0">Demand Pressure by Lane</h3>
  <div class="table-wrap">
    <table class="mfg-lane-table">
      <thead><tr><th>Stage</th><th>System</th><th>Adjusted</th><th>Approved</th><th>Approved Rows</th><th>Pending Approval Rows</th><th>Action</th></tr></thead>
      <tbody>
        <?php foreach ($laneRows as $lane): ?>
        <tr>
          <td><?= e((string)$lane['stage']) ?></td>
          <td><?= number_format((float)$lane['system'], 0) ?></td>
          <td><?= number_format((float)$lane['adjusted'], 0) ?></td>
          <td><strong><?= number_format((float)$lane['approved'], 0) ?></strong></td>
          <td><?= (int)$lane['approved_rows'] ?></td>
          <td style="color:<?= (int)$lane['pending_rows'] > 0 ? '#b45309' : '#15803d' ?>"><?= (int)$lane['pending_rows'] ?></td>
          <td><a class="btn" href="<?= e((string)$lane['action_url']) ?>"><?= e((string)$lane['action_label']) ?></a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card mfg-portal-card">
  <div class="section-head"><h2>Today's Stage Flow</h2></div>
  <div class="mfg-flow">
    <div class="mfg-flow-step"><div class="mfg-flow-title">Production</div><div class="mfg-flow-value"><?= (int)($prod['approved_rows'] ?? 0) ?></div></div>
    <div class="mfg-flow-step"><div class="mfg-flow-title">QC</div><div class="mfg-flow-value"><?= (int)($stageStats['ready_for_qc'] ?? 0) ?></div></div>
    <div class="mfg-flow-step"><div class="mfg-flow-title">Assembly</div><div class="mfg-flow-value"><?= (int)($stageStats['ready_for_assembly'] ?? 0) ?></div></div>
    <div class="mfg-flow-step"><div class="mfg-flow-title">Packaging</div><div class="mfg-flow-value"><?= (int)($stageStats['ready_for_packaging'] ?? 0) ?></div></div>
    <div class="mfg-flow-step"><div class="mfg-flow-title">Dispatch</div><div class="mfg-flow-value"><?= (int)($stageStats['ready_for_dispatch'] ?? 0) ?></div></div>
  </div>
</div>

<div class="card mfg-portal-card mfg-secondary-card">
  <div class="section-head"><h2>My Ownership Lane</h2></div>
  <div class="mfg-secondary-title" style="margin-bottom:8px">Secondary detail: ownership and handoff context.</div>
  <?php $ownership_board = is_array($ownership_board ?? null) ? $ownership_board : []; $ownership_board_title = 'Assembly Ownership Workboard'; require APP_ROOT . '/public/views/partials/ownership_workboard.php'; ?>
</div>

<div class="card mfg-portal-card mfg-secondary-card">
  <div class="section-head"><h2>Today's Queue Priorities</h2></div>
  <div class="mfg-secondary-title">Secondary operational detail for queue triage.</div>
</div>

<div class="card mfg-portal-card">
  <div class="section-head"><h2>QC Queue Priorities (Today)</h2></div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Part</th><th>Effective Qty</th><th>Pass Qty</th><th>Open QC Workload</th><th>Next Stage</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach ($qcTopRows as $row): ?>
        <tr>
          <td><?= e((string)($row['parts_name'] ?? '')) ?> <span class="muted">(<?= e((string)($row['parts_number'] ?? '')) ?>)</span></td>
          <td><?= number_format((float)($row['effective_qty'] ?? 0), 0) ?></td>
          <td><?= number_format((float)($row['pass_qty'] ?? 0), 0) ?></td>
          <td style="color:<?= (float)($row['open_qc_workload'] ?? 0) > 0 ? '#ffd97d' : '#5fffa4' ?>"><?= number_format((float)($row['open_qc_workload'] ?? 0), 0) ?></td>
          <td><?= e(ucfirst((string)($row['next_stage'] ?? 'dispatch'))) ?></td>
          <td><a class="btn" href="/manufacturing/qc-queue">Open Queue</a></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($qcTopRows)): ?><tr><td colspan="6" class="muted">No QC workload rows for today.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card mfg-portal-card">
  <div class="section-head"><h2>Assembly Queue Priorities (Today)</h2></div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Part</th><th>Effective Qty</th><th>Completed Qty</th><th>Open Assembly Workload</th><th>Release State</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach ($assemblyTopRows as $row): ?>
        <tr>
          <td><?= e((string)($row['parts_name'] ?? '')) ?> <span class="muted">(<?= e((string)($row['parts_number'] ?? '')) ?>)</span></td>
          <td><?= number_format((float)($row['effective_qty'] ?? 0), 0) ?></td>
          <td><?= number_format((float)($row['effective_completed_qty'] ?? 0), 0) ?></td>
          <td style="color:<?= (float)($row['open_assembly_workload'] ?? 0) > 0 ? '#ffd97d' : '#5fffa4' ?>"><?= number_format((float)($row['open_assembly_workload'] ?? 0), 0) ?></td>
          <td><?= !empty($row['asm_explicitly_released']) ? 'Released' : 'Pending' ?></td>
          <td><a class="btn" href="/manufacturing/assembly-queue">Open Queue</a></td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($assemblyTopRows)): ?><tr><td colspan="6" class="muted">No Assembly workload rows for today.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
