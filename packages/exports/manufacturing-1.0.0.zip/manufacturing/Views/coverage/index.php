<?php
declare(strict_types=1);

$summary = is_array($summary ?? null) ? $summary : [];
$rows = is_array($rows ?? null) ? $rows : [];

usort($rows, static function (array $a, array $b): int {
  $shortageA = (float)($a['net_shortage_qty'] ?? 0);
  $shortageB = (float)($b['net_shortage_qty'] ?? 0);
  if ($shortageA !== $shortageB) {
    return $shortageA < $shortageB ? 1 : -1;
  }

  $requiredA = trim((string)($a['required_date'] ?? ''));
  $requiredB = trim((string)($b['required_date'] ?? ''));
  $sortA = $requiredA !== '' ? $requiredA : '9999-12-31';
  $sortB = $requiredB !== '' ? $requiredB : '9999-12-31';
  if ($sortA !== $sortB) {
    return strcmp($sortA, $sortB);
  }

  return (int)($a['id'] ?? 0) <=> (int)($b['id'] ?? 0);
});

require APP_ROOT . '/public/views/layouts/header.php';
?>

<style>
  .coverage-pill { display:inline-flex; align-items:center; padding:2px 8px; border-radius:999px; font-size:.78rem; font-weight:700; letter-spacing:.02em; }
  .coverage-pill-critical { background:#ffe2e2; color:#8d1717; }
  .coverage-pill-low { background:#fff2d6; color:#7a5100; }
  .coverage-pill-balanced { background:#eef1f4; color:#334155; }
  .coverage-pill-high { background:#dff6e6; color:#166534; }
  .coverage-pill-supply-only { background:#e6f1ff; color:#1d4f91; }
  .coverage-pill-no-data { background:#f2f2f2; color:#5a5a5a; }
  .coverage-actions { display:flex; flex-wrap:wrap; gap:6px; }
  .coverage-actions a { font-size:.78rem; }
  .coverage-window-filter-group { display:flex; flex-wrap:wrap; gap:8px; margin-top:8px; }
  .coverage-window-chip { border:1px solid #d8dee5; background:#f7f9fc; color:#334155; border-radius:999px; padding:5px 10px; font-size:.8rem; cursor:pointer; }
  .coverage-window-chip.is-active { border-color:#1d4f91; background:#e6f1ff; color:#16396a; }
  .coverage-window-note { font-size:.8rem; color:#64748b; margin-top:8px; }
  .coverage-row-priority-critical { background:#fff5f5; }
  .coverage-row-priority-low { background:#fffaf1; }
  .coverage-shortage-cell { font-weight:700; color:#9f1239; background:rgba(254, 226, 226, 0.5); }
  .coverage-empty-state { padding:16px; border:1px dashed #cbd5e1; border-radius:10px; background:#f8fafc; margin-top:10px; }
  .coverage-empty-state strong { color:#1f2937; }
</style>

<section class="card">
  <div class="section-head">
    <h2>Coverage Dashboard</h2>
    <div class="muted">Analysis workspace for demand coverage and shortage risk.</div>
  </div>
  <div class="coverage-kpi-grid">
    <div class="coverage-kpi">
      <div class="muted">Open Orders</div>
      <div class="coverage-kpi-value"><?= (int)($summary['open_orders'] ?? 0) ?></div>
    </div>
    <div class="coverage-kpi">
      <div class="muted">Demand Qty</div>
      <div class="coverage-kpi-value"><?= e(number_format((float)($summary['demand_qty'] ?? 0), 2, '.', ',')) ?></div>
    </div>
    <div class="coverage-kpi">
      <div class="muted">Covered Qty</div>
      <div class="coverage-kpi-value"><?= e(number_format((float)($summary['covered_qty'] ?? 0), 2, '.', ',')) ?></div>
    </div>
    <div class="coverage-kpi">
      <div class="muted">Shortage Qty</div>
      <div class="coverage-kpi-value"><?= e(number_format((float)($summary['shortage_qty'] ?? 0), 2, '.', ',')) ?></div>
    </div>
    <div class="coverage-kpi coverage-kpi-accent">
      <div class="muted">Average Coverage %</div>
      <div class="coverage-kpi-value"><?= e(number_format((float)($summary['coverage_pct'] ?? 0), 2, '.', ',')) ?>%</div>
    </div>
    <div class="coverage-kpi">
      <div class="muted">Critical Orders Count</div>
      <div class="coverage-kpi-value"><?= (int)($summary['critical_orders_count'] ?? 0) ?></div>
    </div>
    <div class="coverage-kpi">
      <div class="muted">Low Coverage Orders Count</div>
      <div class="coverage-kpi-value"><?= (int)($summary['low_coverage_orders_count'] ?? 0) ?></div>
    </div>
    <div class="coverage-kpi">
      <div class="muted">Fully Covered Orders Count</div>
      <div class="coverage-kpi-value"><?= (int)($summary['fully_covered_orders_count'] ?? 0) ?></div>
    </div>
    <div class="coverage-kpi">
      <div class="muted">Coverage Window</div>
      <div class="coverage-window-filter-group" role="group" aria-label="Coverage Window Filter">
        <button type="button" class="coverage-window-chip" data-window="today">Today: <strong><?= (int)($summary['window_today_count'] ?? 0) ?></strong></button>
        <button type="button" class="coverage-window-chip" data-window="3d">3-day: <strong><?= (int)($summary['window_3day_count'] ?? 0) ?></strong></button>
        <button type="button" class="coverage-window-chip is-active" data-window="7d">7-day: <strong><?= (int)($summary['window_7day_count'] ?? 0) ?></strong></button>
        <button type="button" class="coverage-window-chip" data-window="all">All</button>
      </div>
      <div class="coverage-window-note">UI filter only. Data source remains unchanged.</div>
    </div>
  </div>
</section>

<section class="card">
  <div class="section-head">
    <h2>Shortage Priorities</h2>
    <div class="muted">Top open orders by current shortage quantity.</div>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Order</th>
          <th>Order Date</th>
          <th>Required Date</th>
          <th>Customer</th>
          <th>Part</th>
          <th>Demand Qty</th>
          <th>Available Stock</th>
          <th>Planned Supply</th>
          <th>Net Coverage</th>
          <th>Net Shortage</th>
          <th>Coverage %</th>
          <th>Coverage Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="coverage-table-body">
        <?php foreach ($rows as $row): ?>
        <?php $orderId = (int)($row['id'] ?? 0); ?>
        <?php
          $requiredDate = trim((string)($row['required_date'] ?? ''));
          $orderDate = trim((string)($row['order_date'] ?? ''));
          $classification = strtolower(str_replace(' ', '-', trim((string)($row['coverage_classification'] ?? 'No Data'))));
          $classificationClass = 'coverage-pill-no-data';
          $rowClass = '';
          if ($classification === 'critical') {
            $classificationClass = 'coverage-pill-critical';
            $rowClass = 'coverage-row-priority-critical';
          } elseif ($classification === 'low') {
            $classificationClass = 'coverage-pill-low';
            $rowClass = 'coverage-row-priority-low';
          } elseif ($classification === 'balanced') {
            $classificationClass = 'coverage-pill-balanced';
          } elseif ($classification === 'high') {
            $classificationClass = 'coverage-pill-high';
          } elseif ($classification === 'supply-only') {
            $classificationClass = 'coverage-pill-supply-only';
          }
        ?>
        <tr class="<?= e($rowClass) ?>" data-row="coverage" data-required-date="<?= e($requiredDate) ?>" data-order-date="<?= e($orderDate) ?>">
          <td><a href="/daily-orders/360?id=<?= $orderId ?>">#<?= $orderId ?></a></td>
          <td><?= e((string)($row['order_date'] ?? '')) ?></td>
          <td><?= e((string)($row['required_date'] ?? '')) ?></td>
          <td><?= e((string)($row['customer_name'] ?? '')) ?></td>
          <td>
            <?= e((string)($row['parts_name'] ?? '')) ?>
            <span class="muted"><?= e((string)($row['parts_number'] ?? '')) ?></span>
          </td>
          <td><?= e(number_format((float)($row['qty'] ?? 0), 2, '.', ',')) ?></td>
          <td><?= e(number_format((float)($row['available_stock_qty'] ?? 0), 2, '.', ',')) ?></td>
          <td><?= e(number_format((float)($row['planned_supply_qty'] ?? 0), 2, '.', ',')) ?></td>
          <td><?= e(number_format((float)($row['net_coverage_qty'] ?? 0), 2, '.', ',')) ?></td>
          <td class="coverage-shortage-cell"><?= e(number_format((float)($row['net_shortage_qty'] ?? 0), 2, '.', ',')) ?></td>
          <td><?= e(number_format((float)($row['coverage_pct'] ?? 0), 2, '.', ',')) ?>%</td>
          <td>
            <span class="coverage-pill <?= e($classificationClass) ?>"><?= e((string)($row['coverage_classification'] ?? 'No Data')) ?></span>
            <div class="muted" style="margin-top:4px"><?= e((string)($row['coverage_status'] ?? '')) ?></div>
          </td>
          <td>
            <div class="coverage-actions">
              <?php foreach ((array)($row['action_links'] ?? []) as $link): ?>
                <?php $url = (string)($link['url'] ?? ''); ?>
                <?php $label = (string)($link['label'] ?? 'Open'); ?>
                <?php if ($url !== ''): ?>
                  <a class="btn" href="<?= e($url) ?>"><?= e($label) ?></a>
                <?php endif; ?>
              <?php endforeach; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($rows)): ?>
        <tr><td colspan="13">
          <div class="coverage-empty-state">
            <div><strong>No active shortages or uncovered demand for the selected window.</strong></div>
            <div class="muted" style="margin-top:4px">System is fully covered.</div>
          </div>
        </td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <div id="coverage-empty-filtered" class="coverage-empty-state" style="display:none">
    <div><strong>No active shortages or uncovered demand for the selected window.</strong></div>
    <div class="muted" style="margin-top:4px">System is fully covered.</div>
  </div>
</section>

<script>
  (function () {
    var tableBody = document.getElementById('coverage-table-body');
    if (!tableBody) return;

    var rows = Array.prototype.slice.call(tableBody.querySelectorAll('tr[data-row="coverage"]'));
    var chips = Array.prototype.slice.call(document.querySelectorAll('.coverage-window-chip[data-window]'));
    var emptyFiltered = document.getElementById('coverage-empty-filtered');
    if (rows.length === 0 || chips.length === 0) return;

    function parseDate(raw) {
      if (!raw) return null;
      var d = new Date(raw + 'T00:00:00');
      return isNaN(d.getTime()) ? null : d;
    }

    function matchWindow(row, windowKey) {
      if (windowKey === 'all') return true;

      var requiredDate = parseDate(row.getAttribute('data-required-date') || '');
      var orderDate = parseDate(row.getAttribute('data-order-date') || '');
      var baseDate = requiredDate || orderDate;
      if (!baseDate) return true;

      var today = new Date();
      today.setHours(0, 0, 0, 0);
      var diffDays = Math.floor((baseDate.getTime() - today.getTime()) / 86400000);

      if (windowKey === 'today') return diffDays <= 0;
      if (windowKey === '3d') return diffDays <= 3;
      if (windowKey === '7d') return diffDays <= 7;
      return true;
    }

    function applyWindow(windowKey) {
      var visibleCount = 0;
      rows.forEach(function (row) {
        var show = matchWindow(row, windowKey);
        row.style.display = show ? '' : 'none';
        if (show) visibleCount += 1;
      });
      if (emptyFiltered) {
        emptyFiltered.style.display = visibleCount === 0 ? '' : 'none';
      }
    }

    chips.forEach(function (chip) {
      chip.addEventListener('click', function () {
        var windowKey = chip.getAttribute('data-window') || '7d';
        chips.forEach(function (item) { item.classList.remove('is-active'); });
        chip.classList.add('is-active');
        applyWindow(windowKey);
      });
    });

    applyWindow('7d');
  })();
</script>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
