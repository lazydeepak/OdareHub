<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$pipeline = is_array($pipeline ?? null) ? $pipeline : [];
$columns = is_array($pipeline['columns'] ?? null) ? $pipeline['columns'] : [];
$totals = is_array($pipeline['totals'] ?? null) ? $pipeline['totals'] : ['items' => 0, 'overdue' => 0, 'blocked' => 0, 'at_risk' => 0];
$date = (string)($date ?? date('Y-m-d'));
$today = (string)($today ?? date('Y-m-d'));
$isToday = ($date === $today);

$priorityTone = static function (string $priority): string {
  return match ($priority) {
    'critical' => 'background:rgba(255,80,80,.18);color:#ff9a9a;border:1px solid rgba(255,80,80,.35)',
    'high' => 'background:rgba(255,176,32,.18);color:#ffd27d;border:1px solid rgba(255,176,32,.35)',
    'elevated' => 'background:rgba(119,167,255,.18);color:#b7d0ff;border:1px solid rgba(119,167,255,.35)',
    default => 'background:rgba(160,160,180,.12);color:#c6c9de;border:1px solid rgba(160,160,180,.25)',
  };
};

$slaTone = static function (string $tone): string {
  return match ($tone) {
    'overdue' => 'background:rgba(255,80,80,.18);color:#ff9a9a;border:1px solid rgba(255,80,80,.35)',
    'at_risk' => 'background:rgba(255,176,32,.18);color:#ffd27d;border:1px solid rgba(255,176,32,.35)',
    'on_track' => 'background:rgba(0,220,110,.18);color:#8ef2b5;border:1px solid rgba(0,220,110,.35)',
    default => 'background:rgba(160,160,180,.12);color:#c6c9de;border:1px solid rgba(160,160,180,.25)',
  };
};
?>

<style>
.pipeline-grid { display:grid; grid-template-columns:repeat(6, minmax(290px, 1fr)); gap:12px; overflow:auto; padding-bottom:8px; }
.pipeline-col { border:1px solid var(--glass-border); border-radius:12px; background:linear-gradient(160deg,rgba(255,255,255,.05),rgba(255,255,255,.02)); min-height:280px; }
.pipeline-col-head { padding:12px; border-bottom:1px solid var(--glass-border); }
.pipeline-col-title { font-size:.9em; font-weight:700; margin:0 0 6px 0; }
.pipeline-col-meta { display:flex; gap:6px; flex-wrap:wrap; font-size:.74em; color:var(--muted); }
.pipeline-col-body { padding:10px; display:flex; flex-direction:column; gap:10px; }
.pipeline-item { border:1px solid rgba(255,255,255,.12); border-radius:10px; padding:10px; background:rgba(255,255,255,.02); }
.pipeline-item-top { display:flex; justify-content:space-between; gap:8px; align-items:flex-start; }
.pipeline-item-title { font-size:.84em; font-weight:700; margin:0; }
.pipeline-item-code { font-size:.73em; color:var(--muted); }
.pipeline-pill { display:inline-block; font-size:.7em; padding:2px 7px; border-radius:999px; white-space:nowrap; }
.pipeline-item-meta { margin-top:7px; font-size:.75em; color:var(--muted); display:grid; gap:2px; }
.pipeline-item-actions { margin-top:8px; display:flex; flex-wrap:wrap; gap:6px; }
.pipeline-empty { font-size:.8em; color:var(--muted); padding:12px; border:1px dashed rgba(255,255,255,.16); border-radius:8px; }
.summary-row { display:flex; gap:12px; flex-wrap:wrap; margin-bottom:12px; }
.summary-box { flex:1; min-width:130px; background:linear-gradient(160deg,rgba(255,255,255,.07),rgba(255,255,255,.02)); border:1px solid var(--glass-border); border-radius:12px; padding:12px 16px; }
.summary-label { font-size:.75em; color:var(--muted); margin-bottom:4px; }
.summary-value { font-size:1.4em; font-weight:700; }
</style>

<div class="card">
  <div class="row" style="justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
    <div>
      <h2 style="margin:0">Execution Flow Board</h2>
      <div class="muted" style="font-size:.85em;margin-top:2px">
        System pipeline view: Supply/Production → Assembly → QC → Processing → Dispatch
        <?php if ($isToday): ?> · Today <?= e(date('l, d M Y', strtotime($date))) ?><?php else: ?> · <?= e(date('d M Y', strtotime($date))) ?><?php endif; ?>
      </div>
    </div>
    <div class="row" style="gap:8px;flex-wrap:wrap">
      <a class="btn" href="/manufacturing/production-queue?date=<?= urlencode($date) ?>">Production Queue</a>
      <a class="btn" href="/manufacturing/assembly-queue">Assembly Queue</a>
      <a class="btn" href="/manufacturing/qc-queue">QC Queue</a>
      <a class="btn" href="/manufacturing/dispatch-ops/preparation">Processing</a>
      <a class="btn" href="/manufacturing/dispatch-ops">Dispatch Ops</a>
    </div>
  </div>
</div>

<?php if (!empty($flash ?? '')): ?><div class="card" style="border-color:#1d4d2f;background:rgba(0,255,140,.06)"><?= e((string)$flash) ?></div><?php endif; ?>
<?php if (!empty($error ?? '')): ?><div class="card" style="border-color:#5b1d2b;background:rgba(255,0,0,.06)"><?= e((string)$error) ?></div><?php endif; ?>

<div class="card">
  <form method="get" action="/manufacturing/stage-board" class="row" style="align-items:flex-end;gap:8px">
    <div>
      <label class="muted" style="display:block;margin-bottom:6px;font-size:.8em">Date</label>
      <input type="date" name="date" value="<?= e($date) ?>">
    </div>
    <button class="btn" type="submit">View</button>
    <a class="btn" href="/manufacturing/stage-board">Today</a>
    <a class="btn" href="/manufacturing/stage-board?date=<?= urlencode((string)date('Y-m-d', strtotime($date . ' -1 day'))) ?>">&larr;</a>
    <a class="btn" href="/manufacturing/stage-board?date=<?= urlencode((string)date('Y-m-d', strtotime($date . ' +1 day'))) ?>">&rarr;</a>
  </form>
</div>

<div class="summary-row">
  <div class="summary-box"><div class="summary-label">Pipeline Items</div><div class="summary-value"><?= (int)($totals['items'] ?? 0) ?></div></div>
  <div class="summary-box"><div class="summary-label">Overdue SLA</div><div class="summary-value" style="color:#ff9a9a"><?= (int)($totals['overdue'] ?? 0) ?></div></div>
  <div class="summary-box"><div class="summary-label">At Risk SLA</div><div class="summary-value" style="color:#ffd27d"><?= (int)($totals['at_risk'] ?? 0) ?></div></div>
  <div class="summary-box"><div class="summary-label">Blocked</div><div class="summary-value" style="color:#ff9a9a"><?= (int)($totals['blocked'] ?? 0) ?></div></div>
</div>

<div class="card" style="font-size:.8em;color:var(--muted)">
  <strong>View model:</strong> Stage Board is the full system execution flow. My Work stays a personal filtered inbox.
  <a class="btn" style="margin-left:8px" href="/me">Open My Work</a>
</div>

<?php if ((int)($totals['items'] ?? 0) === 0): ?>
  <div class="card" style="text-align:center;color:var(--muted);padding:28px">No flow items for <?= e($date) ?>.</div>
<?php else: ?>
  <div class="pipeline-grid">
    <?php foreach ($columns as $column): ?>
      <?php $items = is_array($column['items'] ?? null) ? $column['items'] : []; ?>
      <section class="pipeline-col">
        <div class="pipeline-col-head">
          <div class="pipeline-col-title"><?= e((string)($column['label'] ?? 'Stage')) ?></div>
          <div class="pipeline-col-meta">
            <span>Total: <?= (int)($column['count'] ?? 0) ?></span>
            <span>Overdue: <?= (int)($column['overdue_count'] ?? 0) ?></span>
            <span>Blocked: <?= (int)($column['blocked_count'] ?? 0) ?></span>
          </div>
        </div>
        <div class="pipeline-col-body">
          <?php if (empty($items)): ?>
            <div class="pipeline-empty">No items in this stage.</div>
          <?php else: ?>
            <?php foreach ($items as $item): ?>
              <article class="pipeline-item">
                <div class="pipeline-item-top">
                  <div>
                    <div class="pipeline-item-title"><?= e((string)($item['part_name'] ?? '')) ?></div>
                    <div class="pipeline-item-code"><?= e((string)($item['part_code'] ?? '')) ?></div>
                  </div>
                  <span class="pipeline-pill" style="<?= e($priorityTone((string)($item['priority'] ?? 'normal'))) ?>"><?= e(ucfirst((string)($item['priority'] ?? 'normal'))) ?></span>
                </div>

                <div class="pipeline-item-meta">
                  <div><?= e((string)($item['demand_ref'] ?? 'Daily Order -')) ?></div>
                  <div>Current Stage: <?= e((string)($item['current_stage'] ?? '-')) ?></div>
                  <div>Age: <?= (int)($item['age_days'] ?? 0) ?> day(s)</div>
                  <div>
                    <span class="pipeline-pill" style="<?= e($slaTone((string)($item['sla_tone'] ?? 'neutral'))) ?>"><?= e((string)($item['sla_label'] ?? 'No SLA')) ?></span>
                  </div>
                  <?php if (!empty($item['blocked'])): ?>
                    <div style="color:#ff9a9a">Blocked: <?= e((string)($item['block_reason'] ?? 'Workflow block')) ?></div>
                  <?php endif; ?>
                </div>

                <div class="pipeline-item-actions">
                  <a class="btn" href="<?= e((string)($item['open_url'] ?? '/manufacturing/stage-board')) ?>">Open</a>
                  <?php if (!empty($item['links']['order_360'])): ?><a class="btn" href="<?= e((string)$item['links']['order_360']) ?>">Order 360</a><?php endif; ?>
                  <?php if (!empty($item['links']['production_plan'])): ?><a class="btn" href="<?= e((string)$item['links']['production_plan']) ?>">Production Plan</a><?php endif; ?>
                  <?php if (!empty($item['links']['qc_entry'])): ?><a class="btn" href="<?= e((string)$item['links']['qc_entry']) ?>">QC Entry</a><?php endif; ?>
                  <?php if (!empty($item['links']['dispatch_entry'])): ?><a class="btn" href="<?= e((string)$item['links']['dispatch_entry']) ?>">Dispatch Entry</a><?php endif; ?>
                </div>
              </article>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </section>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
