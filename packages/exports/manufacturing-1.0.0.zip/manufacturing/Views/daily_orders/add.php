<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<div class="card"><div class="row" style="justify-content:space-between;align-items:center"><h2 style="margin:0"><?= e(t('add_daily_order')) ?></h2><a class="btn" href="/daily-orders"><?= e(t('back_to_list')) ?></a></div></div>
<?php if (!empty($error ?? '')): ?><div class="card" style="border-color:#5b1d2b;background:rgba(255,0,0,.06)"><?= e((string)$error) ?></div><?php endif; ?>
<div class="card">
<form method="post" action="/daily-orders/add" class="row">
<input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
<div style="flex:1;min-width:170px"><label class="muted" style="display:block;margin-bottom:6px">Order Date *</label><input type="date" name="order_date" required value="<?= e((string)($old['order_date'] ?? '')) ?>"></div>
<div style="flex:1;min-width:170px"><label class="muted" style="display:block;margin-bottom:6px">Required Date</label><input type="date" name="required_date" value="<?= e((string)($old['required_date'] ?? '')) ?>"></div>
<div style="flex:2;min-width:220px"><label class="muted" style="display:block;margin-bottom:6px">Customer *</label><input name="customer_name" required value="<?= e((string)($old['customer_name'] ?? '')) ?>"></div>
<div style="flex:2;min-width:260px"><label class="muted" style="display:block;margin-bottom:6px"><?= e(t('part')) ?> *</label><select name="product_id" required><option value=""><?= e(t('select_part')) ?></option><?php foreach ($products as $p): ?><option value="<?= (int)$p['id'] ?>" <?= ((int)($old['product_id'] ?? 0) === (int)$p['id']) ? 'selected' : '' ?>><?= e((string)$p['parts_name']) ?> (<?= e((string)$p['parts_number']) ?>)</option><?php endforeach; ?></select></div>
<div style="flex:1;min-width:140px"><label class="muted" style="display:block;margin-bottom:6px">Qty *</label><input type="number" step="0.01" name="qty" required value="<?= e((string)($old['qty'] ?? '')) ?>"></div>
<div style="flex:1;min-width:180px"><label class="muted" style="display:block;margin-bottom:6px">Dispatch Deadline</label><input type="datetime-local" name="dispatch_deadline" value="<?= e((string)($old['dispatch_deadline'] ?? '')) ?>"></div>
<div style="flex:1;min-width:160px"><label class="muted" style="display:block;margin-bottom:6px"><?= e(t('status')) ?></label><input name="status" value="<?= e((string)($old['status'] ?? 'Open')) ?>"></div>
<div style="flex:1 1 100%"><label class="muted" style="display:block;margin-bottom:6px"><?= e(t('notes')) ?></label><textarea name="notes"><?= e((string)($old['notes'] ?? '')) ?></textarea></div>
<div style="flex:1 1 100%" class="muted">Coverage, shortage, and supply pipeline are computed automatically after save.</div>
<div class="row" style="width:100%"><button class="btn ok" type="submit"><?= e(t('save_daily_order')) ?></button><a class="btn" href="/daily-orders"><?= e(t('cancel')) ?></a></div>
</form></div>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
