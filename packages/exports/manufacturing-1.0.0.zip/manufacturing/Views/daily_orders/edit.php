<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php $activityTimeline = is_array($activity_timeline ?? null) ? $activity_timeline : []; ?>
<div class="card"><div class="row" style="justify-content:space-between;align-items:center"><h2 style="margin:0"><?= e(t('edit')) ?> Daily Order #<?= (int)$row['id'] ?></h2><div class="row"><a class="btn" href="/daily-orders/360?id=<?= (int)$row['id'] ?>">Order 360</a><a class="btn" href="/daily-orders"><?= e(t('back_to_list')) ?></a></div></div></div>
<?php if (!empty($error ?? '')): ?><div class="card" style="border-color:#5b1d2b;background:rgba(255,0,0,.06)"><?= e((string)$error) ?></div><?php endif; ?>
<?php $ownership_title = 'Operational Ownership'; require APP_ROOT . '/public/views/partials/ownership_summary.php'; ?>
<div class="card">
	<h3 style="margin-top:0">Coverage Snapshot</h3>
	<div class="row">
		<div style="min-width:220px"><div class="muted">Order Demand</div><div><strong><?= e(number_format((float)($row['qty'] ?? 0), 2, '.', '')) ?></strong></div></div>
		<div style="min-width:220px"><div class="muted">Open Demand (Product)</div><div><strong><?= e(number_format((float)($row['open_demand_qty'] ?? 0), 2, '.', '')) ?></strong></div></div>
		<div style="min-width:220px"><div class="muted">Usable Supply</div><div><strong><?= e(number_format((float)($row['usable_supply_qty'] ?? 0), 2, '.', '')) ?></strong></div></div>
		<div style="min-width:220px"><div class="muted">Coverage</div><div><strong><?= e(number_format((float)($row['coverage_pct'] ?? 0), 2, '.', '')) ?>%</strong> (<?= e((string)($row['coverage_status'] ?? 'Low')) ?>)</div></div>
		<div style="min-width:220px"><div class="muted">Shortage</div><div><strong><?= e(number_format((float)($row['shortage_qty'] ?? 0), 2, '.', '')) ?></strong></div></div>
		<div style="min-width:280px"><div class="muted">Last Recalculated</div><div><strong><?= e((string)($row['coverage_last_recalculated_at'] ?? 'Not yet')) ?></strong></div></div>
	</div>
	<hr>
	<div class="row">
		<div style="min-width:220px"><div class="muted">From Ledger Stock</div><div><?= e(number_format((float)($row['usable_stock_qty'] ?? 0), 2, '.', '')) ?></div></div>
		<div style="min-width:220px"><div class="muted">From Valid Production Plans</div><div><?= e(number_format((float)($row['planned_supply_qty'] ?? 0), 2, '.', '')) ?></div></div>
		<div style="min-width:220px"><div class="muted">From QC Passed</div><div><?= e(number_format((float)($row['qc_pass_qty'] ?? 0), 2, '.', '')) ?></div></div>
		<div style="min-width:220px"><div class="muted">Minus Dispatched</div><div><?= e(number_format((float)($row['dispatched_qty'] ?? 0), 2, '.', '')) ?></div></div>
		<div style="min-width:260px"><div class="muted">Pre-order Forecast Pressure</div><div><?= e(number_format((float)($row['forecast_pressure_qty'] ?? 0), 2, '.', '')) ?></div></div>
	</div>
</div>
<div class="card">
<form method="post" action="/daily-orders/edit" class="row">
<input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>"><input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
<div style="flex:1;min-width:170px"><label class="muted" style="display:block;margin-bottom:6px">Order Date *</label><input type="date" name="order_date" required value="<?= e((string)$row['order_date']) ?>"></div>
<div style="flex:1;min-width:170px"><label class="muted" style="display:block;margin-bottom:6px">Required Date</label><input type="date" name="required_date" value="<?= e((string)($row['required_date'] ?? '')) ?>"></div>
<div style="flex:2;min-width:220px"><label class="muted" style="display:block;margin-bottom:6px">Customer *</label><input name="customer_name" required value="<?= e((string)$row['customer_name']) ?>"></div>
<div style="flex:2;min-width:260px"><label class="muted" style="display:block;margin-bottom:6px"><?= e(t('part')) ?> *</label><select name="product_id" required><?php foreach ($products as $p): ?><option value="<?= (int)$p['id'] ?>" <?= ((int)$row['product_id'] === (int)$p['id']) ? 'selected' : '' ?>><?= e((string)$p['parts_name']) ?> (<?= e((string)$p['parts_number']) ?>)</option><?php endforeach; ?></select></div>
<div style="flex:1;min-width:140px"><label class="muted" style="display:block;margin-bottom:6px">Qty *</label><input type="number" step="0.01" name="qty" required value="<?= e((string)$row['qty']) ?>"></div>
<div style="flex:1;min-width:180px"><label class="muted" style="display:block;margin-bottom:6px">Dispatch Deadline</label><input type="datetime-local" name="dispatch_deadline" value="<?= e((string)($row['dispatch_deadline'] ?? '')) ?>"></div>
<div style="flex:1;min-width:160px"><label class="muted" style="display:block;margin-bottom:6px"><?= e(t('status')) ?></label><input name="status" value="<?= e((string)$row['status']) ?>"></div>
<div style="flex:1 1 100%"><label class="muted" style="display:block;margin-bottom:6px"><?= e(t('notes')) ?></label><textarea name="notes"><?= e((string)($row['notes'] ?? '')) ?></textarea></div>
<div class="row" style="width:100%"><button class="btn ok" type="submit"><?= e(t('update_daily_order')) ?></button><a class="btn" href="/daily-orders"><?= e(t('cancel')) ?></a></div>
</form></div>
<div class="card">
<h3 style="margin-top:0">Activity Timeline</h3>
<div class="table-wrap"><table><thead><tr><th>When</th><th>Actor</th><th>Event</th><th>Action</th><th>Note</th></tr></thead><tbody>
<?php if (empty($activityTimeline)): ?>
<tr><td colspan="5" class="muted">No activity yet.</td></tr>
<?php else: foreach ($activityTimeline as $entry): ?>
<tr>
<td><?= e((string)($entry['created_at'] ?? '')) ?></td>
<td><?= e((string)($entry['actor_label'] ?? 'System')) ?></td>
<td><?= e((string)($entry['event_type'] ?? '')) ?></td>
<td><?= e((string)($entry['action_name'] ?? '')) ?></td>
<td><?= e(trim((string)($entry['note_text'] ?? '')) !== '' ? (string)($entry['note_text'] ?? '') : (string)($entry['reason_text'] ?? '')) ?></td>
</tr>
<?php endforeach; endif; ?>
</tbody></table></div>
</div>
<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
