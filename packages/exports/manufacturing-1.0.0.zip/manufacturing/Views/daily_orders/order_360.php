<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$payload = is_array($payload ?? null) ? $payload : [];
$order = is_array($payload['order'] ?? null) ? $payload['order'] : [];
$due = is_array($payload['due'] ?? null) ? $payload['due'] : [];
$coverage = is_array($payload['coverage'] ?? null) ? $payload['coverage'] : [];
$productionPlans = is_array($payload['production_plans'] ?? null) ? $payload['production_plans'] : [];
$productionEntries = is_array($payload['production_entries'] ?? null) ? $payload['production_entries'] : [];
$qcPlans = is_array($payload['qc_plans'] ?? null) ? $payload['qc_plans'] : [];
$qcEntries = is_array($payload['qc_entries'] ?? null) ? $payload['qc_entries'] : [];
$dispatchEntries = is_array($payload['dispatch_entries'] ?? null) ? $payload['dispatch_entries'] : [];
$handoff = is_array($payload['handoff'] ?? null) ? $payload['handoff'] : [];
$current = is_array($handoff['current'] ?? null) ? $handoff['current'] : null;
$activeHandoffs = is_array($handoff['active'] ?? null) ? $handoff['active'] : [];
$notifications = is_array($payload['notifications'] ?? null) ? $payload['notifications'] : [];
$workflowState = is_array($payload['workflow_state'] ?? null) ? $payload['workflow_state'] : [];
$recommendedActions = is_array($payload['recommended_actions'] ?? null) ? $payload['recommended_actions'] : [];
$timeline = is_array($payload['timeline'] ?? null) ? $payload['timeline'] : [];
$relatedSummary = is_array($payload['related_summary'] ?? null) ? $payload['related_summary'] : [];
$currentRole = strtolower(trim((string)($current_role ?? '')));
$ownership_summary = $handoff;

$slaClass = static function (string $level): string {
    $v = strtolower(trim($level));
    if ($v === 'breach') {
        return 'o360-badge-high';
    }
    if ($v === 'warning') {
        return 'o360-badge-medium';
    }
    return 'o360-badge-low';
};

$roleToken = static function (string $role): string {
  $role = strtolower(trim($role));
  if ($role === '' || $role === 'all') {
    return 'all';
  }
  if (str_contains($role, 'dispatch')) {
    return 'dispatch';
  }
  if (str_contains($role, 'qc')) {
    return 'qc';
  }
  if (str_contains($role, 'machine')) {
    return 'machine';
  }
  if (str_contains($role, 'plan')) {
    return 'planning';
  }
  if (str_contains($role, 'admin')) {
    return 'admin';
  }
  return 'all';
};

$roleGroup = $roleToken($currentRole);
$actionVisible = static function (array $action, string $roleGroup): bool {
  $roles = array_map(static fn ($v): string => strtolower(trim((string)$v)), (array)($action['roles'] ?? ['all']));
  if (in_array('all', $roles, true) || in_array($roleGroup, $roles, true)) {
    return true;
  }
  return $roleGroup === 'admin';
};
?>

<style>
.o360-grid { display:grid; gap:12px; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); }
.o360-card { border:1px solid var(--glass-border); border-radius:12px; background:linear-gradient(160deg,rgba(255,255,255,.05),rgba(255,255,255,.02)); padding:10px 12px; }
.o360-kpi { font-size:1.26rem; font-weight:800; margin-top:4px; }
.o360-muted { color:var(--muted); font-size:.82rem; }
.o360-hero { display:flex; justify-content:space-between; gap:12px; flex-wrap:wrap; align-items:flex-start; }
.o360-title { margin:0; font-size:1.38rem; }
.o360-sub { margin-top:6px; color:var(--muted); font-size:.9rem; max-width:920px; }
.o360-actions { display:flex; gap:8px; flex-wrap:wrap; }
.o360-table-wrap { overflow:auto; border:1px solid var(--glass-border); border-radius:12px; }
.o360-table { width:100%; border-collapse:collapse; min-width:920px; }
.o360-table th, .o360-table td { padding:8px 10px; border-bottom:1px solid rgba(255,255,255,.07); text-align:left; vertical-align:top; font-size:.82rem; }
.o360-table th { color:var(--muted); background:rgba(255,255,255,.03); font-weight:600; }
.o360-badge { border-radius:999px; border:1px solid; padding:2px 8px; font-size:.7rem; white-space:nowrap; }
.o360-badge-high { color:#ff9d9d; border-color:rgba(255,102,102,.4); background:rgba(255,80,80,.14); }
.o360-badge-medium { color:#ffd483; border-color:rgba(255,194,72,.4); background:rgba(255,188,71,.15); }
.o360-badge-low { color:#9fe8bf; border-color:rgba(90,210,130,.4); background:rgba(90,210,130,.14); }
.o360-section-title { margin:0 0 8px; font-size:1rem; }
.o360-empty { color:var(--muted); font-size:.84rem; }
</style>

<section class="card">
  <div class="o360-hero">
    <div>
      <h2 class="o360-title">Order 360 - Daily Order #<?= (int)($order['id'] ?? 0) ?></h2>
      <div class="o360-sub">Single-order operational truth: demand to dispatch journey with ownership, SLA, and event trail.</div>
      <div style="margin-top:8px" class="o360-muted">
        Customer: <strong><?= e((string)($order['customer_name'] ?? '-')) ?></strong> |
        Part: <strong><?= e((string)($order['parts_name'] ?? '-')) ?> (<?= e((string)($order['parts_number'] ?? '')) ?>)</strong> |
        Status: <strong><?= e((string)($order['status'] ?? '-')) ?></strong> |
        Coverage: <strong><?= e((string)($coverage['coverage_status'] ?? '-')) ?></strong>
      </div>
      <div style="margin-top:4px" class="o360-muted">
        Order Date: <?= e((string)($order['order_date'] ?? '-')) ?> |
        Required: <?= e((string)($order['required_date'] ?? '-')) ?> |
        Dispatch Deadline: <?= e((string)($order['dispatch_deadline'] ?? '-')) ?> |
        Due State: <strong><?= e((string)($due['label'] ?? '-')) ?></strong>
      </div>
      <div style="margin-top:4px" class="o360-muted">
        Supply Mode: <strong><?= e((string)($order['supply_mode'] ?? 'in_house')) ?></strong> |
        Fulfillment Mode: <strong><?= e((string)($order['fulfillment_mode'] ?? 'via_ipm')) ?></strong> |
        Requires IPM QC: <strong><?= ((int)($order['requires_ipm_qc'] ?? 1) === 1) ? 'Yes' : 'No' ?></strong>
      </div>
    </div>
    <div class="o360-actions">
      <a class="btn" href="/daily-orders">Back to Orders</a>
      <a class="btn" href="/products/360?id=<?= (int)($order['product_id'] ?? 0) ?>">Part 360</a>
      <a class="btn" href="/daily-orders/edit?id=<?= (int)($order['id'] ?? 0) ?>">Edit Order</a>
      <a class="btn" href="/apps/manufacturing/handoffs">Handoff Board</a>
      <a class="btn" href="/ops/notifications">Notifications</a>
    </div>
  </div>
</section>

<section class="card">
  <h3 class="o360-section-title">Current Workflow State</h3>
  <div class="o360-grid">
    <div class="o360-card"><div class="o360-muted">Operational Stage</div><div class="o360-kpi" style="font-size:1rem"><?= e((string)($workflowState['stage_label'] ?? '-')) ?></div></div>
    <div class="o360-card"><div class="o360-muted">Planning Needed</div><div class="o360-kpi" style="font-size:1rem"><?= !empty($workflowState['planning_needed']) ? 'Yes' : 'No' ?></div></div>
    <div class="o360-card"><div class="o360-muted">Awaiting QC</div><div class="o360-kpi" style="font-size:1rem"><?= !empty($workflowState['awaiting_qc']) ? 'Yes' : 'No' ?></div></div>
    <div class="o360-card"><div class="o360-muted">Ready for Dispatch</div><div class="o360-kpi" style="font-size:1rem"><?= !empty($workflowState['dispatch_ready']) ? 'Yes' : 'No' ?></div></div>
    <div class="o360-card"><div class="o360-muted">Partially Released</div><div class="o360-kpi" style="font-size:1rem"><?= !empty($workflowState['partially_released']) ? 'Yes' : 'No' ?></div></div>
    <div class="o360-card"><div class="o360-muted">Supply Blocked</div><div class="o360-kpi" style="font-size:1rem"><?= !empty($workflowState['supply_blocked']) ? 'Yes' : 'No' ?></div></div>
    <div class="o360-card"><div class="o360-muted">Planned / Produced</div><div class="o360-kpi" style="font-size:1rem"><?= e(number_format((float)($workflowState['planned_qty'] ?? 0), 2, '.', ',')) ?> / <?= e(number_format((float)($workflowState['produced_qty'] ?? 0), 2, '.', ',')) ?></div></div>
    <div class="o360-card"><div class="o360-muted">QC Pass / Released / Remaining</div><div class="o360-kpi" style="font-size:1rem"><?= e(number_format((float)($workflowState['qc_pass_qty'] ?? 0), 2, '.', ',')) ?> / <?= e(number_format((float)($workflowState['released_qty'] ?? 0), 2, '.', ',')) ?> / <?= e(number_format((float)($workflowState['remaining_qty'] ?? 0), 2, '.', ',')) ?></div></div>
  </div>
</section>

<section class="card">
  <h3 class="o360-section-title">Coverage Composition and Why</h3>
  <div class="o360-grid">
    <div class="o360-card"><div class="o360-muted">Demand Qty</div><div class="o360-kpi"><?= e(number_format((float)($coverage['demand_qty'] ?? 0), 2, '.', ',')) ?></div></div>
    <div class="o360-card"><div class="o360-muted">Covered Qty</div><div class="o360-kpi"><?= e(number_format((float)($coverage['covered_qty'] ?? 0), 2, '.', ',')) ?></div></div>
    <div class="o360-card"><div class="o360-muted">Shortage Qty</div><div class="o360-kpi" style="color:#ffb3b3"><?= e(number_format((float)($coverage['shortage_qty'] ?? 0), 2, '.', ',')) ?></div></div>
    <div class="o360-card"><div class="o360-muted">Coverage</div><div class="o360-kpi"><?= e(number_format((float)($coverage['coverage_pct'] ?? 0), 2, '.', ',')) ?>% (<?= e((string)($coverage['coverage_status'] ?? '-')) ?>)</div></div>
    <div class="o360-card"><div class="o360-muted">Stock Contribution</div><div class="o360-kpi"><?= e(number_format((float)($coverage['stock_qty'] ?? 0), 2, '.', ',')) ?></div></div>
    <div class="o360-card"><div class="o360-muted">Planned Supply Contribution</div><div class="o360-kpi"><?= e(number_format((float)($coverage['plan_qty'] ?? 0), 2, '.', ',')) ?></div></div>
    <div class="o360-card"><div class="o360-muted">QC Contribution</div><div class="o360-kpi"><?= e(number_format((float)($coverage['qc_qty'] ?? 0), 2, '.', ',')) ?></div></div>
    <div class="o360-card"><div class="o360-muted">Dispatch Contribution</div><div class="o360-kpi"><?= e(number_format((float)($coverage['dispatched_qty'] ?? 0), 2, '.', ',')) ?></div></div>
    <div class="o360-card"><div class="o360-muted">Net Usable Supply</div><div class="o360-kpi"><?= e(number_format((float)($coverage['net_supply_qty'] ?? 0), 2, '.', ',')) ?></div></div>
    <div class="o360-card"><div class="o360-muted">Open Demand (Product)</div><div class="o360-kpi"><?= e(number_format((float)($coverage['open_demand_qty'] ?? 0), 2, '.', ',')) ?></div></div>
    <div class="o360-card"><div class="o360-muted">Forecast Pressure</div><div class="o360-kpi"><?= e(number_format((float)($coverage['forecast_pressure_qty'] ?? 0), 2, '.', ',')) ?></div></div>
    <div class="o360-card"><div class="o360-muted">Last Recalculated</div><div class="o360-kpi" style="font-size:1rem"><?= e((string)($coverage['last_recalculated_at'] ?? '-')) ?></div></div>
  </div>
  <div style="margin-top:10px" class="o360-card">
    <div class="o360-muted">Coverage Explanation</div>
    <div><?= e((string)($coverage['reason'] ?? '-')) ?></div>
    <div class="o360-muted" style="margin-top:6px">Formula: Net Supply = Usable Stock + Planned Supply + QC Pass - Dispatched; Covered = min(Demand, Net Supply); Shortage = Demand - Covered.</div>
  </div>
</section>

<?php if (!empty($recommendedActions)): ?>
<section class="card">
  <h3 class="o360-section-title">Recommended Next Actions</h3>
  <div class="o360-grid">
    <?php foreach ($recommendedActions as $action): ?>
      <?php if (!$actionVisible((array)$action, $roleGroup)) { continue; } ?>
      <div class="o360-card">
        <div style="font-weight:700"><?= e((string)($action['label'] ?? 'Action')) ?></div>
        <div class="o360-muted" style="margin-top:4px"><?= e((string)($action['intent'] ?? '')) ?></div>
        <div style="margin-top:8px">
          <?php if ((string)($action['method'] ?? 'link') === 'post'): ?>
            <form method="post" action="<?= e((string)($action['url'] ?? '#')) ?>" style="margin:0;display:flex;gap:6px;flex-wrap:wrap">
              <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
              <?php foreach ((array)($action['post'] ?? []) as $key => $value): ?>
                <input type="hidden" name="<?= e((string)$key) ?>" value="<?= e((string)$value) ?>">
              <?php endforeach; ?>
              <button class="btn" type="submit"><?= e((string)($action['label'] ?? 'Run')) ?></button>
            </form>
          <?php else: ?>
            <a class="btn" href="<?= e((string)($action['url'] ?? '#')) ?>"><?= e((string)($action['label'] ?? 'Open')) ?></a>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<section>
  <?php
    $ownership_title = 'Active Chain Stage — Most Urgent';
    $ownership_chain_note = 'Showing the highest-risk active handoff stage across this order\'s full production chain (production, QC, dispatch, assembly). For this record\'s own local stage, see the Edit Order view.';
    require APP_ROOT . '/public/views/partials/ownership_summary.php';
  ?>
</section>

<?php if (!empty($timeline)): ?>
<section class="card">
  <h3 class="o360-section-title">Workflow Timeline</h3>
  <div class="o360-table-wrap">
    <table class="o360-table" style="min-width:700px">
      <thead><tr><th>When</th><th>Type</th><th>Event</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach ($timeline as $event): ?>
        <tr>
          <td><?= e((string)($event['when'] ?? '')) ?></td>
          <td><?= e((string)($event['type'] ?? '')) ?></td>
          <td><?= e((string)($event['title'] ?? '')) ?></td>
          <td><?= e((string)($event['status'] ?? '')) ?></td>
          <td><a class="btn" href="<?= e((string)($event['url'] ?? '#')) ?>">Open</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>
<?php endif; ?>

<?php
$renderList = static function(string $title, string $emptyText, array $rows, callable $renderer): void {
?>
<section class="card">
  <h3 class="o360-section-title"><?= e($title) ?></h3>
  <?php if (empty($rows)): ?>
    <div class="o360-empty"><?= e($emptyText) ?></div>
  <?php else: ?>
    <div class="o360-table-wrap">
      <?php $renderer($rows); ?>
    </div>
  <?php endif; ?>
</section>
<?php
};

$renderList('Linked Production Plans', 'No linked production plans in window.', $productionPlans, static function(array $rows): void {
?>
<table class="o360-table">
  <thead><tr><th>ID</th><th>Date</th><th>Machine</th><th>Planned Qty</th><th>Status</th><th>Approval</th><th>Lock</th><th>Action</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td>#<?= (int)($r['id'] ?? 0) ?></td>
      <td><?= e((string)($r['plan_date'] ?? '')) ?></td>
      <td><?= e((string)($r['machine_no'] ?? '')) ?> <?= e((string)($r['machine_name'] ?? '')) ?></td>
      <td><?= e(number_format((float)($r['planned_qty'] ?? 0), 2, '.', ',')) ?></td>
      <td><?= e((string)($r['status'] ?? '')) ?></td>
      <td><?= e((string)($r['approval_status'] ?? 'Draft')) ?></td>
      <td><?= trim((string)($r['locked_at'] ?? '')) !== '' ? 'Locked' : 'Open' ?></td>
      <td><a class="btn" href="/production-plans/edit?id=<?= (int)($r['id'] ?? 0) ?>">Open</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php
});

$renderList('Linked Production Entries', 'No linked production entries in window.', $productionEntries, static function(array $rows): void {
?>
<table class="o360-table">
  <thead><tr><th>ID</th><th>Date</th><th>Machine</th><th>Good Qty</th><th>Status</th><th>Action</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td>#<?= (int)($r['id'] ?? 0) ?></td>
      <td><?= e((string)($r['production_date'] ?? '')) ?></td>
      <td><?= e((string)($r['machine_no'] ?? '')) ?> <?= e((string)($r['machine_name'] ?? '')) ?></td>
      <td><?= e(number_format((float)($r['good_qty'] ?? 0), 2, '.', ',')) ?></td>
      <td><?= e((string)($r['status'] ?? '')) ?></td>
      <td><a class="btn" href="/production-entries/edit?id=<?= (int)($r['id'] ?? 0) ?>">Open</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php
});

$renderList('Linked QC Plans', 'No linked QC plans in window.', $qcPlans, static function(array $rows): void {
?>
<table class="o360-table">
  <thead><tr><th>ID</th><th>Date</th><th>Planned Qty</th><th>Status</th><th>Action</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td>#<?= (int)($r['id'] ?? 0) ?></td>
      <td><?= e((string)($r['plan_date'] ?? '')) ?></td>
      <td><?= e(number_format((float)($r['planned_qty'] ?? 0), 2, '.', ',')) ?></td>
      <td><?= e((string)($r['status'] ?? '')) ?></td>
      <td><a class="btn" href="/qc-plans/edit?id=<?= (int)($r['id'] ?? 0) ?>">Open</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php
});

$renderList('Linked QC Entries', 'No linked QC entries in window.', $qcEntries, static function(array $rows): void {
?>
<table class="o360-table">
  <thead><tr><th>ID</th><th>QC Type</th><th>Checked</th><th>Pass</th><th>Fail</th><th>Status</th><th>Approval</th><th>Lock</th><th>Action</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td>#<?= (int)($r['id'] ?? 0) ?></td>
      <td><?= e((string)($r['qc_type'] ?? '')) ?></td>
      <td><?= e(number_format((float)($r['checked_qty'] ?? 0), 2, '.', ',')) ?></td>
      <td><?= e(number_format((float)($r['pass_qty'] ?? 0), 2, '.', ',')) ?></td>
      <td><?= e(number_format((float)($r['fail_qty'] ?? 0), 2, '.', ',')) ?></td>
      <td><?= e((string)($r['status'] ?? '')) ?></td>
      <td><?= e((string)($r['approval_status'] ?? 'Draft')) ?></td>
      <td><?= trim((string)($r['locked_at'] ?? '')) !== '' ? 'Locked' : 'Open' ?></td>
      <td><a class="btn" href="/qc-entries/edit?id=<?= (int)($r['id'] ?? 0) ?>">Open</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php
});

$renderList('Linked Dispatch Entries', 'No linked dispatch entries in window.', $dispatchEntries, static function(array $rows): void {
?>
<table class="o360-table">
  <thead><tr><th>ID</th><th>Date</th><th>Qty</th><th>Status</th><th>Approval</th><th>Lock</th><th>Destination</th><th>Action</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td>#<?= (int)($r['id'] ?? 0) ?></td>
      <td><?= e((string)($r['dispatch_date'] ?? '')) ?></td>
      <td><?= e(number_format((float)($r['dispatchable_qty'] ?? 0), 2, '.', ',')) ?></td>
      <td><?= e((string)($r['dispatch_status'] ?? '')) ?></td>
      <td><?= e((string)($r['approval_status'] ?? 'Draft')) ?></td>
      <td><?= trim((string)($r['locked_at'] ?? '')) !== '' || strtolower(trim((string)($r['dispatch_status'] ?? ''))) === 'dispatched' ? 'Locked' : 'Open' ?></td>
      <td><?= e((string)($r['destination'] ?? '')) ?></td>
      <td><a class="btn" href="/dispatch-entries/edit?id=<?= (int)($r['id'] ?? 0) ?>">Open</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php
});

$renderList('Recent Notifications / Important Events', 'No recent notifications linked to this order context.', $notifications, static function(array $rows): void {
?>
<table class="o360-table">
  <thead><tr><th>When</th><th>Severity</th><th>Event</th><th>Message</th><th>Entity</th><th>Status</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e((string)($r['created_at'] ?? '')) ?></td>
      <td><?= e((string)($r['severity'] ?? '')) ?></td>
      <td><?= e((string)($r['event_type'] ?? '')) ?></td>
      <td><strong><?= e((string)($r['title'] ?? '')) ?></strong><br><span class="o360-muted"><?= e((string)($r['message'] ?? '')) ?></span></td>
      <td><?= e((string)($r['entity_type'] ?? '')) ?>-<?= (int)($r['entity_id'] ?? 0) ?></td>
      <td><?= e((string)($r['status'] ?? '')) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php
});
?>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
