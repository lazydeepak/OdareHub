<?php
/** @var array<string,mixed> $summary */
/** @var array<int,array<string,mixed>> $risk_rows */
/** @var array<int,array<string,string>> $quick_links */

$summary = is_array($summary ?? null) ? $summary : [];
$riskRows = is_array($risk_rows ?? null) ? $risk_rows : [];
$quickLinks = is_array($quick_links ?? null) ? $quick_links : [];
$roleLabel = (string)($role_label ?? 'Operations');
$suiteRoleTemplateLabels = is_array($suite_role_template_labels ?? null) ? $suite_role_template_labels : [];
$modulePermissionTemplateLabels = is_array($module_permission_template_labels ?? null) ? $module_permission_template_labels : [];

require APP_ROOT . '/public/views/layouts/header.php';
?>

<div class="card">
  <div class="section-head">
    <h2>Demand Dashboard</h2>
    <div class="muted">Demand and order orchestration workspace for planners and supervisors.</div>
  </div>
  <?php if ($suiteRoleTemplateLabels !== [] || $modulePermissionTemplateLabels !== []): ?>
    <div class="row" style="gap:6px;flex-wrap:wrap;margin-top:8px">
      <?php foreach ($suiteRoleTemplateLabels as $label): ?>
        <span class="pill"><?= e((string)$label) ?></span>
      <?php endforeach; ?>
      <?php foreach ($modulePermissionTemplateLabels as $label): ?>
        <span class="pill"><?= e((string)$label) ?></span>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
  <div class="row" style="gap:8px;flex-wrap:wrap;margin-top:10px">
    <a class="btn" href="/daily-orders">Daily Orders</a>
    <a class="btn" href="/apps/manufacturing/imports">Legacy Imports</a>
    <a class="btn" href="/apps/manufacturing/exports">Exports</a>
    <a class="btn" href="/apps/manufacturing/restores">Restores</a>
    <a class="btn" href="/manufacturing/coverage">Coverage Dashboard</a>
    <a class="btn" href="/production-plans">Production Plans</a>
    <a class="btn" href="/manufacturing/demands">Demand Workspace</a>
    <a class="btn" href="/manufacturing/stage-board">Stage Board</a>
    <a class="btn" href="/manufacturing/qc-queue">QC Queue</a>
    <a class="btn" href="/manufacturing/dispatch-ops/preparation">Order Processing</a>
    <a class="btn" href="/manufacturing/dispatch-ops">Dispatch Ops</a>
  </div>
</div>

<div class="card">
  <div class="muted" style="margin-bottom:10px">Role lens: <?= e($roleLabel) ?></div>
  <div class="coverage-kpi-grid">
    <div class="coverage-kpi">
      <div class="muted">Open Orders</div>
      <div class="coverage-kpi-value"><?= number_format((int)($summary['open_orders'] ?? 0)) ?></div>
    </div>
    <div class="coverage-kpi">
      <div class="muted">Due Today</div>
      <div class="coverage-kpi-value"><?= number_format((int)($summary['due_today'] ?? 0)) ?></div>
    </div>
    <div class="coverage-kpi <?= (int)($summary['delayed'] ?? 0) > 0 ? 'coverage-kpi-accent' : '' ?>">
      <div class="muted">Delayed</div>
      <div class="coverage-kpi-value"><?= number_format((int)($summary['delayed'] ?? 0)) ?></div>
    </div>
    <div class="coverage-kpi <?= (float)($summary['shortage_qty'] ?? 0) > 0 ? 'coverage-kpi-accent' : '' ?>">
      <div class="muted">Coverage / Shortage</div>
      <div class="coverage-kpi-value"><?= number_format((float)($summary['coverage_pct'] ?? 0), 1) ?>%</div>
      <div class="muted" style="margin-top:4px">Shortage <?= number_format((float)($summary['shortage_qty'] ?? 0), 0) ?></div>
    </div>
    <div class="coverage-kpi">
      <div class="muted">Production Demand</div>
      <div class="coverage-kpi-value"><?= number_format((int)($summary['production_demand_rows'] ?? 0)) ?></div>
      <div class="muted" style="margin-top:4px">Qty <?= number_format((float)($summary['production_demand_qty'] ?? 0), 0) ?></div>
    </div>
    <div class="coverage-kpi">
      <div class="muted">Procurement Demand</div>
      <div class="coverage-kpi-value"><?= number_format((int)($summary['procurement_demand_rows'] ?? 0)) ?></div>
      <div class="muted" style="margin-top:4px">Qty <?= number_format((float)($summary['procurement_demand_qty'] ?? 0), 0) ?></div>
    </div>
    <div class="coverage-kpi">
      <div class="muted">Pending Plans</div>
      <div class="coverage-kpi-value"><?= number_format((int)($summary['pending_plans'] ?? 0)) ?></div>
    </div>
    <div class="coverage-kpi">
      <div class="muted">Approved Plans Today</div>
      <div class="coverage-kpi-value"><?= number_format((int)($summary['approved_plans_today'] ?? 0)) ?></div>
    </div>
    <div class="coverage-kpi">
      <div class="muted">Critical Orders</div>
      <div class="coverage-kpi-value"><?= number_format((int)($summary['critical_orders'] ?? 0)) ?></div>
    </div>
  </div>
</div>

<div class="card">
  <div class="section-head">
    <h2>Role-Aware Quick Links</h2>
    <div class="muted">Shortcuts tuned for the current role while keeping core demand links visible.</div>
  </div>
  <div class="dashboard-grid" style="margin-top:8px">
    <?php foreach ($quickLinks as $link): ?>
      <a href="<?= e((string)($link['url'] ?? '#')) ?>" class="dashboard-link-card">
        <div class="dashboard-link-top"><strong style="font-size:14px"><?= e((string)($link['label'] ?? 'Open')) ?></strong></div>
        <div class="muted" style="font-size:13px"><?= e((string)($link['hint'] ?? '')) ?></div>
        <div class="dashboard-link-meta">Open &rarr;</div>
      </a>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <div class="section-head">
    <h2>Top Risk Orders</h2>
    <div class="muted">Orders with the highest current shortage pressure.</div>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Order</th>
          <th>Date</th>
          <th>Required</th>
          <th>Customer</th>
          <th>Part</th>
          <th>Qty</th>
          <th>Coverage</th>
          <th>Shortage</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($riskRows as $row): ?>
          <tr>
            <td>#<?= (int)($row['id'] ?? 0) ?></td>
            <td><?= e((string)($row['order_date'] ?? '')) ?></td>
            <td><?= e((string)($row['required_date'] ?? '')) ?></td>
            <td><?= e((string)($row['customer_name'] ?? '')) ?></td>
            <td>
              <?= e((string)($row['parts_name'] ?? '')) ?>
              <span class="muted"><?= e((string)($row['parts_number'] ?? '')) ?></span>
            </td>
            <td><?= number_format((float)($row['qty'] ?? 0), 2) ?></td>
            <td><?= number_format((float)($row['coverage_pct'] ?? 0), 1) ?>%</td>
            <td><?= number_format((float)($row['shortage_qty'] ?? 0), 2) ?></td>
            <td><a class="btn" href="/daily-orders/360?id=<?= (int)($row['id'] ?? 0) ?>">Open 360</a></td>
          </tr>
        <?php endforeach; ?>
        <?php if (empty($riskRows)): ?>
          <tr>
            <td colspan="9" class="muted">No active risk orders right now.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
