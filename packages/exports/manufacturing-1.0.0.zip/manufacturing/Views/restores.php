<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>
<?php
$suite = is_array($suite ?? null) ? $suite : [];
$modules = is_array($modules ?? null) ? $modules : [];
$history = is_array($history ?? null) ? $history : [];
$csrf = (string)($csrf ?? '');
$previewPayload = is_array($preview ?? null) ? $preview : [];
$previewData = is_array($previewPayload['preview'] ?? null) ? $previewPayload['preview'] : [];
$scopes = array_values(array_map('strval', (array)($previewData['available_restore_scopes'] ?? [])));
$selectedScope = in_array('full', $scopes, true) ? 'full' : ($scopes[0] ?? 'package_only');
$targetLabel = strtoupper((string)($previewData['target_type'] ?? 'suite')) . ': ' . (string)($previewData['target_key'] ?? 'manufacturing');
?>

<div class="card">
  <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
    <div>
      <h2 style="margin:0 0 6px">Manufacturing Restore / Import-Back</h2>
      <div class="muted">Preview suite backups, module package restores, data import-back, and full snapshot restores for Manufacturing before any live planning or execution state is replaced.</div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <a class="btn" href="/apps/manufacturing">Back to Manufacturing</a>
      <a class="btn" href="/apps/manufacturing/exports">Exports</a>
      <a class="btn" href="/apps/manufacturing/imports">Legacy Imports</a>
    </div>
  </div>
</div>

<?php if (($flash_ok ?? '') !== ''): ?>
  <div class="card" style="border-color:rgba(0,200,120,.4);color:#7df0b0"><?= e((string)$flash_ok) ?></div>
<?php endif; ?>
<?php if (($flash_err ?? '') !== ''): ?>
  <div class="card" style="border-color:rgba(255,80,80,.45);color:#ffb3b3"><?= e((string)$flash_err) ?></div>
<?php endif; ?>

<div class="card">
  <h3 style="margin:0 0 8px">Restore Targets</h3>
  <div class="muted" style="margin-bottom:10px">Supported restore types: package-only backups, data-only backups, package + data backups, and full backup snapshots. Restore stays separate from setup, demo seeding, and legacy imports.</div>
  <div style="display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(240px,1fr))">
    <div class="card" style="margin:0">
      <strong>Whole Suite</strong>
      <div class="muted" style="margin-top:6px"><?= e((string)($suite['label'] ?? 'Manufacturing')) ?> bundle package, installed child modules, and planning/execution data.</div>
    </div>
    <div class="card" style="margin:0">
      <strong>Module Restore</strong>
      <div class="muted" style="margin-top:6px">Products, Machines, Daily Orders, Pre Orders, Production Plans, QC Entries, Dispatch Entries, and other module exports.</div>
    </div>
    <div class="card" style="margin:0">
      <strong>Data Import-Back</strong>
      <div class="muted" style="margin-top:6px">Check schema gaps, dependency issues, duplicate risk, and overwrite scope before restoring live workflow rows.</div>
    </div>
  </div>
</div>

<div class="card">
  <h3 style="margin:0 0 8px">Preview Restore</h3>
  <div class="muted" style="margin-bottom:10px">Upload a restore artifact first. The preview shows target identity, backup type, package version, schema compatibility, missing dependencies, overwrite risk, and conflict summary before commit.</div>
  <form method="post" action="/apps/manufacturing/restores/preview" enctype="multipart/form-data" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end">
    <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
    <label>
      <div class="muted" style="margin-bottom:6px">Backup file</div>
      <input type="file" name="backup_file" accept=".zip,.json" required>
    </label>
    <button class="btn ok" type="submit">Preview Restore</button>
  </form>
</div>

<?php if ($previewData !== []): ?>
  <div class="card">
    <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start">
      <div>
        <h3 style="margin:0 0 8px">Verification Before Restore</h3>
        <div class="muted">Nothing has been changed yet. This preview shows what will be restored, what may be replaced, what conflicts were found, and what still needs manual follow-up.</div>
      </div>
      <span class="pill"><?= e($targetLabel) ?></span>
    </div>

    <div style="display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));margin-top:12px">
      <div class="card" style="margin:0">
        <div class="muted">Backup Type</div>
        <strong><?= e((string)($previewData['backup_type'] ?? 'unknown')) ?></strong>
      </div>
      <div class="card" style="margin:0">
        <div class="muted">Schema Compatibility</div>
        <strong><?= e((string)($previewData['schema_compatibility'] ?? 'unknown')) ?></strong>
      </div>
      <div class="card" style="margin:0">
        <div class="muted">Warnings / Conflicts</div>
        <strong><?= (int)($previewData['conflict_summary']['warning_count'] ?? 0) ?> / <?= (int)($previewData['conflict_summary']['conflict_count'] ?? 0) ?></strong>
      </div>
      <div class="card" style="margin:0">
        <div class="muted">Duplicate Risk Rows</div>
        <strong><?= (int)($previewData['duplicate_risk_rows'] ?? 0) ?></strong>
      </div>
    </div>

    <div style="display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));margin-top:12px">
      <div class="card" style="margin:0">
        <h4 style="margin:0 0 8px">Restore Identity</h4>
        <div class="muted">Source file: <?= e((string)($previewData['source_backup'] ?? '')) ?></div>
        <div class="muted">Live status: <?= e((string)($previewData['live_state']['status'] ?? 'not_installed')) ?></div>
        <div class="muted">Live version: <?= e((string)($previewData['live_state']['version'] ?? 'n/a')) ?></div>
        <div class="muted">Package payload: <?= !empty($previewData['has_package']) ? 'yes' : 'no' ?></div>
        <div class="muted">Data payload: <?= !empty($previewData['has_data']) ? 'yes' : 'no' ?></div>
      </div>
      <div class="card" style="margin:0">
        <h4 style="margin:0 0 8px">Conflict Summary</h4>
        <?php if (!empty($previewData['conflicts'])): ?>
          <?php foreach ((array)$previewData['conflicts'] as $conflict): ?>
            <div class="muted" style="margin-bottom:6px">• <?= e((string)$conflict) ?></div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="muted">No blocking conflicts detected in the preview.</div>
        <?php endif; ?>
      </div>
    </div>

    <div style="display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));margin-top:12px">
      <div class="card" style="margin:0">
        <h4 style="margin:0 0 8px">Package / Version Info</h4>
        <?php foreach ((array)($previewData['package_info'] ?? []) as $pkg): ?>
          <div style="margin-bottom:8px">
            <strong><?= e((string)($pkg['name'] ?? 'package')) ?></strong>
            <div class="muted">Version: <?= e((string)($pkg['version'] ?? 'n/a')) ?></div>
            <div class="muted">Type: <?= e((string)($pkg['type'] ?? 'package')) ?></div>
          </div>
        <?php endforeach; ?>
        <?php if (empty($previewData['package_info'])): ?>
          <div class="muted">No package archive found in this backup.</div>
        <?php endif; ?>
      </div>
      <div class="card" style="margin:0">
        <h4 style="margin:0 0 8px">Schema / Dependencies</h4>
        <div class="muted">Missing tables: <?= e(implode(', ', array_map('strval', (array)($previewData['schema']['missing_tables'] ?? [])))) ?: 'none' ?></div>
        <div class="muted" style="margin-top:6px">Missing dependencies: <?= e(implode(', ', array_map('strval', (array)($previewData['missing_dependencies'] ?? [])))) ?: 'none' ?></div>
        <div class="muted" style="margin-top:6px">Version mismatches: <?= (int)($previewData['conflict_summary']['version_conflict_count'] ?? 0) ?></div>
      </div>
      <div class="card" style="margin:0">
        <h4 style="margin:0 0 8px">Overwrite / Merge Risk</h4>
        <?php if (!empty($previewData['overwrite_risk'])): ?>
          <?php foreach ((array)$previewData['overwrite_risk'] as $risk): ?>
            <div class="muted" style="margin-bottom:6px">• <?= e((string)$risk) ?></div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="muted">No live rows detected in the restore tables.</div>
        <?php endif; ?>
      </div>
    </div>

    <?php if ($scopes !== []): ?>
      <form method="post" action="/apps/manufacturing/restores/commit" style="margin-top:12px">
        <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
        <input type="hidden" name="preview_token" value="<?= e((string)($previewPayload['preview_token'] ?? '')) ?>">
        <div style="display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));align-items:end">
          <label>
            <div class="muted" style="margin-bottom:6px">Restore scope</div>
            <select name="restore_scope">
              <?php foreach ($scopes as $scope): ?>
                <option value="<?= e($scope) ?>" <?= $scope === $selectedScope ? 'selected' : '' ?>><?= e($scope) ?></option>
              <?php endforeach; ?>
            </select>
          </label>
          <label>
            <div class="muted" style="margin-bottom:6px">Conflict handling</div>
            <select name="conflict_strategy">
              <option value="overwrite">Overwrite live rows</option>
              <option value="merge">Merge where safe</option>
            </select>
          </label>
          <label style="display:flex;gap:8px;align-items:center">
            <input type="checkbox" name="install_missing_dependencies" value="1">
            <span>Install missing dependency first when required</span>
          </label>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
          <button class="btn ok" type="submit">Apply Restore</button>
        </div>
      </form>
    <?php else: ?>
      <div class="card" style="margin-top:12px">
        <strong>Review-only backup</strong>
        <div class="muted" style="margin-top:6px">This artifact contains metadata only, so it cannot restore package files or business data. Use it to confirm compatibility, then upload a package or data backup when you are ready to restore.</div>
      </div>
    <?php endif; ?>

    <form method="post" action="/apps/manufacturing/restores/cancel" style="margin-top:8px">
      <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
      <input type="hidden" name="preview_token" value="<?= e((string)($previewPayload['preview_token'] ?? '')) ?>">
      <button class="btn" type="submit">Cancel Restore Review</button>
    </form>
  </div>
<?php endif; ?>

<div class="card">
  <h3 style="margin:0 0 8px">Module Coverage</h3>
  <div class="muted" style="margin-bottom:10px">Restore previews can target one module export or the full suite. These are the module areas currently expected for Manufacturing.</div>
  <div style="display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(240px,1fr))">
    <?php foreach ($modules as $module): ?>
      <div class="card" style="margin:0">
        <strong><?= e((string)($module['display_name'] ?? '')) ?></strong>
        <div class="muted" style="margin-top:6px">Status: <?= e((string)($module['status'] ?? 'missing')) ?></div>
        <div class="muted" style="margin-top:6px">Tables: <?= e(implode(', ', array_map('strval', (array)($module['required_tables'] ?? [])))) ?></div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <h3 style="margin:0 0 8px">Restore History</h3>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>When</th>
          <th>Target</th>
          <th>Type</th>
          <th>Status</th>
          <th>Rollback</th>
          <th>Warnings / Errors</th>
          <th>User</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($history as $row): ?>
          <tr>
            <td><?= e((string)($row['created_at'] ?? '')) ?></td>
            <td><?= e((string)($row['target_type'] ?? '')) ?>: <?= e((string)($row['target_key'] ?? '')) ?></td>
            <td><?= e((string)($row['restore_type'] ?? '')) ?></td>
            <td><?= e((string)($row['status'] ?? '')) ?></td>
            <td><?= !empty($row['rollback_attempted']) ? 'attempted' : 'no' ?></td>
            <td><?= e(trim((string)($row['warning_text'] ?? '') . ' ' . (string)($row['error_text'] ?? ''))) ?: 'none' ?></td>
            <td><?= e((string)($row['created_by'] ?? '')) ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if ($history === []): ?>
          <tr>
            <td colspan="7" class="muted">No restore activity yet.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
