<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>

<?php
$products = is_array($products ?? null) ? $products : [];
$orders = is_array($orders ?? null) ? $orders : [];
$selectedOrder = is_array($selected_order ?? null) ? $selected_order : null;
$form = is_array($form ?? null) ? $form : [];
$history = is_array($history ?? null) ? $history : [];
$workflowHints = is_array($workflow_hints ?? null) ? $workflow_hints : null;
$dispatchDate = (string)($dispatch_date ?? date('Y-m-d'));
$productId = (int)($product_id ?? 0);
$dailyOrderId = (int)($daily_order_id ?? 0);
?>

<div class="card">
  <div class="row" style="justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
    <div>
      <h2 style="margin:0">Order Preparation Form</h2>
      <div class="muted">Auto-load today's dispatch order by part, adjust qty with note, and log cases/pallets with operator and timestamp.</div>
    </div>
    <div class="row" style="gap:8px;flex-wrap:wrap">
      <a class="btn" href="/manufacturing/dispatch-ops">Dispatch Workbench</a>
      <a class="btn" href="/manufacturing/stage-board">Stage Board</a>
      <a class="btn" href="/manufacturing/assembly-plans">Assembly Plans</a>
    </div>
  </div>
</div>

<?php if (!empty($flash ?? '')): ?><div class="card" style="border-color:#1d4d2f;background:rgba(0,255,140,.06)"><?= e((string)$flash) ?></div><?php endif; ?>
<?php if (!empty($error ?? '')): ?><div class="card" style="border-color:#5b1d2b;background:rgba(255,0,0,.06)"><?= e((string)$error) ?></div><?php endif; ?>

<div class="card">
  <form method="get" action="/manufacturing/dispatch-ops/preparation" class="row" style="align-items:end;gap:8px;flex-wrap:wrap">
    <div style="min-width:170px">
      <label class="muted" style="display:block;margin-bottom:6px">Dispatch Date</label>
      <input type="date" name="dispatch_date" value="<?= e($dispatchDate) ?>">
    </div>
    <div style="min-width:280px;flex:1">
      <label class="muted" style="display:block;margin-bottom:6px">Part</label>
      <select name="product_id">
        <option value="0">Select part</option>
        <?php foreach ($products as $product): ?>
          <option value="<?= (int)$product['id'] ?>" <?= $productId === (int)$product['id'] ? 'selected' : '' ?>>
            <?= e((string)$product['parts_name']) ?> (<?= e((string)$product['parts_number']) ?>)
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="row" style="gap:8px">
      <button class="btn" type="submit">Load Orders</button>
      <a class="btn" href="/manufacturing/dispatch-ops/preparation">Reset</a>
    </div>
  </form>
</div>

<?php if ($productId > 0): ?>
<div class="card">
  <div class="row" style="justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
    <div>
      <strong>Orders for selected part on <?= e($dispatchDate) ?></strong>
      <div class="muted" style="font-size:.85em">Choose the order being prepared for dispatch.</div>
    </div>
    <form method="get" action="/manufacturing/dispatch-ops/preparation" class="row" style="gap:8px;align-items:end;flex-wrap:wrap;margin:0">
      <input type="hidden" name="dispatch_date" value="<?= e($dispatchDate) ?>">
      <input type="hidden" name="product_id" value="<?= $productId ?>">
      <div style="min-width:300px">
        <label class="muted" style="display:block;margin-bottom:6px">Order</label>
        <select name="daily_order_id">
          <option value="0">Select order</option>
          <?php foreach ($orders as $order): ?>
            <option value="<?= (int)$order['id'] ?>" <?= $dailyOrderId === (int)$order['id'] ? 'selected' : '' ?>>
              #<?= (int)$order['id'] ?> <?= e((string)$order['customer_name']) ?> | Qty <?= e((string)$order['qty']) ?> | Outstanding <?= e((string)$order['outstanding_qty']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <button class="btn" type="submit">Load Preparation Form</button>
    </form>
  </div>
  <?php if (empty($orders)): ?>
    <div class="muted" style="margin-top:10px">No open orders found for the selected part/date.</div>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php if ($selectedOrder): ?>
<div class="card">
  <div class="row" style="justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap">
    <div>
      <h3 style="margin:0">Preparation Details</h3>
      <div class="muted" style="margin-top:4px">Order #<?= (int)$selectedOrder['id'] ?> for <?= e((string)$selectedOrder['customer_name']) ?></div>
    </div>
    <div class="muted" style="font-size:.85em">
      Required Date: <strong><?= e((string)($selectedOrder['required_date'] ?? '')) ?></strong><br>
      Outstanding Qty: <strong><?= e((string)($selectedOrder['outstanding_qty'] ?? '0')) ?></strong>
    </div>
  </div>
  <?php if ($workflowHints !== null): ?>
    <div style="margin-top:10px;font-size:.82em;color:var(--muted)">
      Dispatch Status: <strong><?= e((string)($workflowHints['dispatch_status'] ?? 'pending')) ?></strong>
      | Releasable Qty: <strong><?= e(number_format((float)($workflowHints['releasable_qty'] ?? 0), 2, '.', '')) ?></strong>
      <?php if (!empty($workflowHints['upstream_stage'])): ?>
        | Upstream: <strong><?= e((string)$workflowHints['upstream_stage']) ?></strong> (<?= e((string)($workflowHints['upstream_status'] ?? 'pending')) ?>)
      <?php endif; ?>
    </div>
    <?php if (!(bool)($workflowHints['allowed'] ?? false)): ?>
      <div style="margin-top:8px;font-size:.82em;color:#ff8888">Blocked: <?= e((string)($workflowHints['message'] ?? 'Dispatch not allowed by workflow.')) ?></div>
    <?php endif; ?>
  <?php endif; ?>
  <form method="post" action="/manufacturing/dispatch-ops/preparation" class="row" style="margin-top:12px;gap:10px;align-items:end">
    <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
    <input type="hidden" name="dispatch_entry_id" value="<?= (int)($form['dispatch_entry_id'] ?? 0) ?>">
    <input type="hidden" name="daily_order_id" value="<?= (int)($form['daily_order_id'] ?? 0) ?>">
    <input type="hidden" name="product_id" value="<?= (int)($form['product_id'] ?? 0) ?>">
    <div style="flex:1;min-width:170px">
      <label class="muted" style="display:block;margin-bottom:6px">Dispatch Date</label>
      <input type="date" name="dispatch_date" value="<?= e((string)($form['dispatch_date'] ?? $dispatchDate)) ?>" required>
    </div>
    <div style="flex:1;min-width:150px">
      <label class="muted" style="display:block;margin-bottom:6px">Prepared Qty</label>
      <input type="number" step="0.01" min="0" name="dispatchable_qty" value="<?= e((string)($form['dispatchable_qty'] ?? '0')) ?>" required>
    </div>
    <div style="flex:1;min-width:130px">
      <label class="muted" style="display:block;margin-bottom:6px">Cases</label>
      <input type="number" min="0" name="cases_count" value="<?= (int)($form['cases_count'] ?? 0) ?>">
    </div>
    <div style="flex:1;min-width:130px">
      <label class="muted" style="display:block;margin-bottom:6px">Pallets</label>
      <input type="number" min="0" name="pallets_count" value="<?= (int)($form['pallets_count'] ?? 0) ?>">
    </div>
    <div style="flex:2;min-width:220px">
      <label class="muted" style="display:block;margin-bottom:6px">Destination</label>
      <input type="text" name="destination" value="<?= e((string)($form['destination'] ?? '')) ?>">
    </div>
    <div style="flex:1 1 100%">
      <label class="muted" style="display:block;margin-bottom:6px">Preparation Note</label>
      <textarea name="note" placeholder="Manual adjustment note / packing note / dispatch prep note"><?= e((string)($form['note'] ?? '')) ?></textarea>
    </div>
    <div class="row" style="width:100%;gap:8px">
      <button class="btn ok" type="submit" <?= ($workflowHints !== null && !(bool)($workflowHints['allowed'] ?? false)) ? 'disabled' : '' ?>><?= (int)($form['dispatch_entry_id'] ?? 0) > 0 ? 'Update Preparation' : 'Save Preparation' ?></button>
      <a class="btn" href="/manufacturing/dispatch-ops">Back to Dispatch Workbench</a>
    </div>
  </form>
</div>

<div class="card">
  <h3 style="margin-top:0">Auto-loaded Order Context</h3>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Order ID</th>
          <th>Order Date</th>
          <th>Required Date</th>
          <th>Customer</th>
          <th>Part</th>
          <th>Order Qty</th>
          <th>Outstanding Qty</th>
          <th>Dispatch Deadline</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><?= (int)$selectedOrder['id'] ?></td>
          <td><?= e((string)$selectedOrder['order_date']) ?></td>
          <td><?= e((string)$selectedOrder['required_date']) ?></td>
          <td><?= e((string)$selectedOrder['customer_name']) ?></td>
          <td><?= e((string)$selectedOrder['parts_name']) ?> (<?= e((string)$selectedOrder['parts_number']) ?>)</td>
          <td><?= e((string)$selectedOrder['qty']) ?></td>
          <td><?= e((string)$selectedOrder['outstanding_qty']) ?></td>
          <td><?= e((string)($selectedOrder['dispatch_deadline'] ?? '')) ?></td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

<div class="card">
  <h3 style="margin-top:0">Preparation Log</h3>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Prepared At</th>
          <th>User</th>
          <th>Qty</th>
          <th>Cases</th>
          <th>Pallets</th>
          <th>Note</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($history as $item): ?>
          <tr>
            <td><?= e((string)($item['prepared_at'] ?? '')) ?></td>
            <td><?= e((string)($item['prepared_by'] ?? 'system')) ?></td>
            <td><?= e((string)($item['prepared_qty'] ?? '0')) ?></td>
            <td><?= (int)($item['cases_count'] ?? 0) ?></td>
            <td><?= (int)($item['pallets_count'] ?? 0) ?></td>
            <td><?= e((string)($item['note'] ?? '')) ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (empty($history)): ?>
          <tr><td colspan="6" class="muted">No preparation log entries yet.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
