<?php require APP_ROOT . '/public/views/layouts/header.php'; ?>

<div class="card">
  <div class="row" style="justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">
    <div>
      <h2 style="margin:0">Dispatch Operations Workbench</h2>
      <div class="muted">Editor workflow for ready state, cases/pallets preparation, and dispatch completion tracking.</div>
    </div>
    <div class="row" style="gap:8px">
      <a class="btn ok" href="/manufacturing/dispatch-ops/preparation">Order Preparation Form</a>
      <a class="btn" href="/manufacturing/assembly-plans">Assembly Plans</a>
      <a class="btn" href="/manufacturing/stage-board">Stage Board</a>
      <a class="btn" href="/manufacturing/demands">Demand Engine</a>
    </div>
  </div>
</div>

<?php if (!empty($flash ?? '')): ?><div class="card" style="border-color:#1d4d2f;background:rgba(0,255,140,.06)"><?= e((string)$flash) ?></div><?php endif; ?>
<?php if (!empty($error ?? '')): ?><div class="card" style="border-color:#5b1d2b;background:rgba(255,0,0,.06)"><?= e((string)$error) ?></div><?php endif; ?>

<div class="card">
  <form method="get" action="/manufacturing/dispatch-ops" class="row" style="align-items:end;gap:8px">
    <div style="flex:1;min-width:160px"><label class="muted" style="display:block;margin-bottom:6px">From</label><input type="date" name="from_date" value="<?= e((string)($from_date ?? '')) ?>"></div>
    <div style="flex:1;min-width:160px"><label class="muted" style="display:block;margin-bottom:6px">To</label><input type="date" name="to_date" value="<?= e((string)($to_date ?? '')) ?>"></div>
    <div style="flex:2;min-width:220px">
      <label class="muted" style="display:block;margin-bottom:6px">Part</label>
      <select name="product_id">
        <option value="0">All parts</option>
        <?php foreach ($products as $p): ?>
          <option value="<?= (int)$p['id'] ?>" <?= ((int)($product_id ?? 0) === (int)$p['id']) ? 'selected' : '' ?>>
            <?= e((string)$p['parts_name']) ?> (<?= e((string)$p['parts_number']) ?>)
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div style="flex:1;min-width:160px">
      <label class="muted" style="display:block;margin-bottom:6px">Completion Status</label>
      <select name="completion_status">
        <option value="">All</option>
        <?php foreach (['draft', 'ready', 'prepared', 'completed'] as $s): ?>
          <option value="<?= e($s) ?>" <?= ((string)($completion_status ?? '') === $s) ? 'selected' : '' ?>><?= e(ucfirst($s)) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="row"><button class="btn" type="submit">Filter</button><a class="btn" href="/manufacturing/dispatch-ops">Reset</a></div>
  </form>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Date</th>
          <th>Part</th>
          <th>Qty</th>
          <th>Cases</th>
          <th>Pallets</th>
          <th>Source</th>
          <th>Delivery Flow</th>
          <th>Dispatch Mode</th>
          <th>Status</th>
          <th>Stage Eligibility</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($rows as $r):
        $rKey = ((int)$r['product_id']) . '|' . ((string)$r['dispatch_date']) . '|' . ((int)$r['id']);
        $rData = ($readinessMap ?? [])[$rKey] ?? null;
      ?>
        <tr>
          <td><?= (int)$r['id'] ?></td>
          <td><?= e((string)$r['dispatch_date']) ?></td>
          <td><?= e((string)$r['parts_name']) ?> <span class="muted">(<?= e((string)$r['parts_number']) ?>)</span></td>
          <td><?= e((string)$r['dispatchable_qty']) ?></td>
          <td><?= (int)($r['cases_count'] ?? 0) ?></td>
          <td><?= (int)($r['pallets_count'] ?? 0) ?></td>
          <td><?= e((string)$r['source_type']) ?></td>
          <td><?= e((string)$r['delivery_flow']) ?></td>
          <td><?= e((string)$r['dispatch_mode']) ?></td>
          <td>
            <?php
            $cs = strtolower((string)$r['completion_status']);
            $csColor = match($cs) {
                'completed' => '#5fffa4',
                'prepared'  => '#a5c5ff',
                'ready'     => '#7dd4ff',
                default     => 'var(--muted)',
            };
            ?>
            <span style="font-size:.82em;font-weight:600;color:<?= $csColor ?>"><?= e(ucfirst($cs)) ?></span>
          </td>
          <!-- Stage eligibility column -->
          <td style="font-size:.8em">
            <?php if ($rData !== null): ?>
              <?php
              $stagePath   = implode(' → ', array_map('ucfirst', (array)($rData['stage_path'] ?? [])));
              $dispReleased = (bool)($rData['dispatch_released'] ?? false);
              $releasableQty = (float)($rData['releasable_qty'] ?? 0.0);
              $nextAllowedAction = (string)($rData['next_allowed_action'] ?? '');
              ?>
              <div style="color:var(--muted);font-size:.78em;margin-bottom:3px"><?= e($stagePath) ?></div>
              <?php if ($dispReleased): ?>
                <span style="color:#7dd4ff">✓ Dispatch released</span>
              <?php else: ?>
                <?php
                $msg = (string)($rData['message'] ?? 'Upstream pending');
                $msgColor = match ($msg) {
                    'Ready after QC', 'Ready after Assembly', 'Direct dispatch eligible', 'Third-party dispatch eligible' => '#a5c5ff',
                    'Partial ready' => '#ffd97d',
                    'Blocked by QC', 'Blocked by Assembly', 'Blocked upstream' => '#ff8888',
                    default => 'var(--muted)',
                };
                ?>
                <span style="color:<?= $msgColor ?>"><?= e($msg) ?></span>
              <?php endif; ?>
              <div style="color:var(--muted);font-size:.72em;margin-top:2px">Releasable Qty: <?= e(number_format($releasableQty, 2, '.', '')) ?></div>
              <?php if ($nextAllowedAction !== ''): ?>
                <div style="color:var(--muted);font-size:.72em;margin-top:1px">Next Action: <?= e(str_replace('_', ' ', $nextAllowedAction)) ?></div>
              <?php endif; ?>
              <?php if (!empty($rData['detail'])): ?>
                <div style="color:var(--muted);font-size:.72em;margin-top:2px"><?= e((string)$rData['detail']) ?></div>
              <?php endif; ?>
              <?php if (!empty($rData['dispatch_released_by'])): ?>
                <div style="color:var(--muted);font-size:.68em;margin-top:2px">by <?= e((string)$rData['dispatch_released_by']) ?></div>
              <?php endif; ?>
            <?php else: ?>
              <span class="muted">—</span>
            <?php endif; ?>
          </td>
          <td>
            <?php
            $dispatchAllowed = (bool)($rData['allowed'] ?? false);
            ?>
            <div style="margin:0 0 8px 0">
              <a class="btn" href="/manufacturing/dispatch-ops/preparation?dispatch_date=<?= urlencode((string)$r['dispatch_date']) ?>&product_id=<?= (int)$r['product_id'] ?>&daily_order_id=<?= (int)($r['daily_order_id'] ?? 0) ?>">Prep Form</a>
            </div>
            <?php if (!$dispatchAllowed): ?>
              <div style="font-size:.74em;color:#ff8888;margin:0 0 8px 0">Workflow blocked. Resolve upstream stage before ready/prepare/complete.</div>
            <?php endif; ?>
            <form method="post" action="/manufacturing/dispatch-ops/ready" style="display:inline-flex;gap:6px;align-items:center;margin:0 0 8px 0">
              <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="btn" type="submit" <?= $dispatchAllowed ? '' : 'disabled' ?>>Ready</button>
            </form>

            <form method="post" action="/manufacturing/dispatch-ops/prepare" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin:0 0 8px 0">
              <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <input type="number" name="cases_count" min="0" value="<?= (int)($r['cases_count'] ?? 0) ?>" style="width:80px" placeholder="Cases">
              <input type="number" name="pallets_count" min="0" value="<?= (int)($r['pallets_count'] ?? 0) ?>" style="width:80px" placeholder="Pallets">
              <select name="source_type" style="min-width:120px">
                <?php foreach (['in_house', 'third_party'] as $opt): ?>
                  <option value="<?= e($opt) ?>" <?= ((string)$r['source_type'] === $opt) ? 'selected' : '' ?>><?= e($opt) ?></option>
                <?php endforeach; ?>
              </select>
              <select name="delivery_flow" style="min-width:170px">
                <?php foreach (['company_to_destination', 'third_party_to_destination', 'third_party_to_company_to_destination'] as $opt): ?>
                  <option value="<?= e($opt) ?>" <?= ((string)$r['delivery_flow'] === $opt) ? 'selected' : '' ?>><?= e($opt) ?></option>
                <?php endforeach; ?>
              </select>
              <select name="dispatch_mode" style="min-width:190px">
                <?php foreach (['in_house_dispatch', 'third_party_dispatch', 'company_origin_dispatch', 'third_party_direct_dispatch', 'third_party_to_company_then_destination'] as $opt): ?>
                  <option value="<?= e($opt) ?>" <?= ((string)$r['dispatch_mode'] === $opt) ? 'selected' : '' ?>><?= e($opt) ?></option>
                <?php endforeach; ?>
              </select>
              <input type="text" name="third_party_reference" value="<?= e((string)($r['third_party_reference'] ?? '')) ?>" placeholder="Third-party ref" style="min-width:140px">
              <button class="btn" type="submit" <?= $dispatchAllowed ? '' : 'disabled' ?>>Prepare</button>
            </form>

            <form method="post" action="/manufacturing/dispatch-ops/complete" style="display:inline-flex;gap:6px;align-items:center;margin:0">
              <input type="hidden" name="csrf" value="<?= e(\App\Core\Auth::csrfToken()) ?>">
              <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
              <button class="btn ok" type="submit" <?= $dispatchAllowed ? '' : 'disabled' ?>>Complete</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($rows)): ?>
        <tr><td colspan="12" class="muted">No dispatch rows found for current filter.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require APP_ROOT . '/public/views/layouts/footer.php'; ?>
