<?php
declare(strict_types=1);

namespace Apps\Manufacturing\Services;

use App\Core\DB;

final class HostSurfaceContributionService
{
    /**
     * @param array<string,mixed> $request
     * @return array<string,mixed>|array<int,array<string,mixed>>
     */
    public static function contribute(array $request): array
    {
        $surface = trim((string)($request['surface'] ?? ''));
        $region = trim((string)($request['region'] ?? ''));
        $context = is_array($request['context'] ?? null) ? (array)$request['context'] : [];

        return match ($surface . ':' . $region) {
            'me:header_actions' => self::meHeaderActions($context),
            'me:summary_cards' => self::meSummaryCards(),
            'me:quick_links' => self::meQuickLinks($context),
            'me:monitoring_sections' => self::meMonitoringSections(),
            'approval_inbox:header_actions' => self::approvalHeaderActions(),
            'role_inbox:header_actions' => self::roleInboxHeaderActions(),
            'supervisor_cockpit:header_actions' => self::cockpitHeaderActions(),
            default => [],
        };
    }

    /**
     * @param array<string,mixed> $context
     * @return array<int,array<string,mixed>>
     */
    private static function meHeaderActions(array $context): array
    {
        $user = is_array($context['user'] ?? null) ? (array)$context['user'] : [];
        $roleSlug = strtolower(trim((string)($user['role'] ?? '')));
        $roleSlug = str_replace([' ', '-'], '', $roleSlug);

        $actions = [
            [
                'label' => t('nav.manufacturing_portal'),
                'url' => '/apps/manufacturing',
                'weight' => 5,
            ],
        ];

        if (in_array($roleSlug, ['productionleader', 'assemblyleader', 'productionoperations'], true)) {
            $actions[] = ['label' => t('nav.machine_leader'), 'url' => '/manufacturing/production-workboard', 'weight' => 10];
        }
        if (in_array($roleSlug, ['qcleader', 'qcoperations'], true)) {
            $actions[] = ['label' => t('nav.qc_leader'), 'url' => '/manufacturing/qc-workboard', 'weight' => 11];
        }
        if (in_array($roleSlug, ['dispatchleader', 'dispatchoperations'], true)) {
            $actions[] = ['label' => t('nav.dispatch_ops'), 'url' => '/manufacturing/dispatch-ops', 'weight' => 12];
        }

        $actions[] = ['label' => t('nav.coverage_dashboard'), 'url' => '/manufacturing/coverage', 'weight' => 15];
        $actions[] = ['label' => t('nav.demand_workspace'), 'url' => '/manufacturing/demands', 'weight' => 16];

        return $actions;
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function meSummaryCards(): array
    {
        $lowCoverage = self::countOpenOrders("LOWER(COALESCE(coverage_status, '')) IN ('low','partial')");
        $urgentRisk = self::countOpenOrders("COALESCE(shortage_qty, 0) > 0");
        $pendingApprovals = self::pendingApprovalCount();
        $dispatchHold = self::countDispatchHold();

        return [
            [
                'title' => t('nav.coverage_dashboard'),
                'value' => $lowCoverage,
                'meta' => t('ops.supervisor_cockpit.kpi_due_soon_low_coverage'),
                'url' => '/manufacturing/coverage',
                'tone' => 'warn',
                'weight' => 10,
            ],
            [
                'title' => t('ops.supervisor_cockpit.kpi_high_risk_orders'),
                'value' => $urgentRisk,
                'meta' => t('ops.my_work.reason.waiting_upstream'),
                'url' => '/manufacturing/demands',
                'tone' => 'danger',
                'weight' => 11,
            ],
            [
                'title' => t('nav.approval_inbox'),
                'value' => $pendingApprovals,
                'meta' => t('ops.common.awaiting_approval'),
                'url' => '/ops/approval-inbox',
                'tone' => 'info',
                'weight' => 12,
            ],
            [
                'title' => t('nav.dispatch_ops'),
                'value' => $dispatchHold,
                'meta' => t('ops.dispatch_leader.blocked_hold'),
                'url' => '/manufacturing/dispatch-ops',
                'tone' => 'warn',
                'weight' => 13,
            ],
        ];
    }

    /**
     * @param array<string,mixed> $context
     * @return array<int,array<string,mixed>>
     */
    private static function meQuickLinks(array $context): array
    {
        $links = [
            [
                'label' => t('nav.daily_orders'),
                'url' => '/daily-orders',
                'description' => t('ops.my_work.primary_work_area'),
                'weight' => 20,
            ],
            [
                'label' => t('nav.production_plans'),
                'url' => '/production-plans',
                'description' => t('ops.common.primary_work'),
                'weight' => 21,
            ],
            [
                'label' => t('nav.dispatch_entries'),
                'url' => '/dispatch-entries',
                'description' => t('ops.common.cross_functional_work'),
                'weight' => 22,
            ],
        ];

        return $links;
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function meMonitoringSections(): array
    {
        $rows = self::highRiskOrders(6);
        return [[
            'title' => t('ops.supervisor_cockpit.top_risk_orders'),
            'kind' => 'table',
            'columns' => [t('ops.supervisor_cockpit.order'), t('common.part'), t('common.coverage'), t('common.shortage'), t('common.actions')],
            'rows' => array_map(static function (array $row): array {
                return [
                    'order' => '#' . (int)($row['id'] ?? 0),
                    'part' => trim((string)($row['parts_name'] ?? '-')) . ' (' . trim((string)($row['parts_number'] ?? '-')) . ')',
                    'coverage' => number_format((float)($row['coverage_pct'] ?? 0), 2, '.', ',') . '%',
                    'shortage' => number_format((float)($row['shortage_qty'] ?? 0), 2, '.', ','),
                    'url' => '/daily-orders/360?id=' . (int)($row['id'] ?? 0),
                ];
            }, $rows),
            'empty_message' => t('ops.supervisor_cockpit.no_active_risk_orders'),
            'weight' => 30,
        ]];
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function approvalHeaderActions(): array
    {
        return [
            ['label' => t('nav.coverage_dashboard'), 'url' => '/manufacturing/coverage', 'weight' => 10],
            ['label' => t('nav.demand_workspace'), 'url' => '/manufacturing/demands', 'weight' => 11],
        ];
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function roleInboxHeaderActions(): array
    {
        return [
            ['label' => t('nav.manufacturing_portal'), 'url' => '/apps/manufacturing', 'weight' => 10],
            ['label' => t('nav.coverage_dashboard'), 'url' => '/manufacturing/coverage', 'weight' => 11],
        ];
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function cockpitHeaderActions(): array
    {
        return [
            ['label' => t('nav.manufacturing_portal'), 'url' => '/apps/manufacturing', 'weight' => 5],
            ['label' => t('nav.demand_workspace'), 'url' => '/manufacturing/demands', 'weight' => 6],
            ['label' => t('nav.coverage_dashboard'), 'url' => '/manufacturing/coverage', 'weight' => 7],
        ];
    }

    private static function countOpenOrders(string $extraWhere): int
    {
        if (!self::tableExists('daily_orders')) {
            return 0;
        }

        $row = DB::fetchOne(
            "SELECT COUNT(*) AS total
             FROM daily_orders
             WHERE LOWER(COALESCE(status,'')) NOT IN ('closed','completed','cancelled','canceled')
               AND {$extraWhere}"
        );

        return (int)($row['total'] ?? 0);
    }

    private static function pendingApprovalCount(): int
    {
        $tables = ['production_plans', 'qc_entries', 'dispatch_entries'];
        $total = 0;
        foreach ($tables as $table) {
            if (!self::tableExists($table)) {
                continue;
            }
            $row = DB::fetchOne(
                "SELECT COUNT(*) AS total
                 FROM {$table}
                 WHERE LOWER(COALESCE(approval_status,'')) IN ('pending approval','reopened','draft')"
            );
            $total += (int)($row['total'] ?? 0);
        }

        return $total;
    }

    private static function countDispatchHold(): int
    {
        if (!self::tableExists('dispatch_entries')) {
            return 0;
        }
        $row = DB::fetchOne(
            "SELECT COUNT(*) AS total
             FROM dispatch_entries
             WHERE LOWER(COALESCE(dispatch_status,'')) IN ('hold','blocked','pending','ready')"
        );

        return (int)($row['total'] ?? 0);
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private static function highRiskOrders(int $limit): array
    {
        if (!self::tableExists('daily_orders') || !self::tableExists('products')) {
            return [];
        }

        return DB::fetchAll(
            "SELECT d.id, d.coverage_pct, d.shortage_qty, p.parts_name, p.parts_number
             FROM daily_orders d
             LEFT JOIN products p ON p.id = d.product_id
             WHERE LOWER(COALESCE(d.status,'')) NOT IN ('closed','completed','cancelled','canceled')
               AND (COALESCE(d.shortage_qty,0) > 0 OR COALESCE(d.coverage_pct,0) < 80)
             ORDER BY COALESCE(d.shortage_qty,0) DESC, COALESCE(d.coverage_pct,0) ASC, d.id DESC
             LIMIT " . max(1, $limit)
        );
    }

    private static function tableExists(string $table): bool
    {
        try {
            return DB::fetchOne(
                'SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? LIMIT 1',
                [$table]
            ) !== null;
        } catch (\Throwable $e) {
            return false;
        }
    }
}
